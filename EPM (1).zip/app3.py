# app.py
import streamlit as st
import pandas as pd
import base64
import json
import tempfile
import os
import io
import zipfile
from pathlib import Path
import re
from word_doc_final import generate_docx

from docx import Document
from langchain_core.messages import HumanMessage

# ✨ Your modules
from cross_region_model import cross_region_llm
from text_processing_functions import extract_sheet_records_for_llm, to_row_text_all_fields

# ─────────────────────────────────────────────────────────
# Init LLM
# ─────────────────────────────────────────────────────────
llm = cross_region_llm()

# ─────────────────────────────────────────────────────────
# Streamlit page config
# ─────────────────────────────────────────────────────────
st.set_page_config(page_title="Multi‑Sheet Excel + Screenshot Processor", page_icon="📄", layout="centered")


# ─────────────────────────────────────────────────────────
# Utilities
# ─────────────────────────────────────────────────────────
def save_uploaded_excel(uploaded_file) -> str:
    """
    Save uploaded Excel file to a real temporary path and return the file path.
    Uses getbuffer() to avoid consuming the stream position in Streamlit.
    """
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
    tmp.write(uploaded_file.getbuffer())
    tmp.flush()
    return tmp.name

def bytes_to_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("utf-8")

def sanitize_filename(name: str) -> str:
    # Remove characters not allowed on Windows/macOS/Linux filenames
    name = re.sub(r'[\\/*?:"<>|]', "_", name)
    name = name.strip()
    return name or "output"

def extract_json_safely(raw_text: str):
    """
    Try to parse LLM output into JSON:
      - Remove code fences if present
      - Extract substring between first '{' and last '}'
    """
    if not raw_text:
        return {"error": "Empty LLM output"}

    txt = raw_text.strip()

    # Drop Markdown fences ```json ... ```
    if txt.startswith("```"):
        # Find the first fence and last fence
        parts = re.split(r"```(?:json)?", txt, flags=re.IGNORECASE)
        # Heuristic: last chunk may contain the content
        txt = "".join(parts)

    # Extract JSON object by locating outer braces
    start = txt.find("{")
    end = txt.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = txt[start:end+1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    # Last attempt: direct json loads
    try:
        return json.loads(txt)
    except Exception:
        return {"error": "Failed to parse JSON", "raw_llm_output": raw_text}


def extract_json_from_llm(raw_text: str):
    """
    Extracts JSON block from LLM response and returns a Python dict.
    Handles cases like:
      ```json { ... } ```
      { ... }
      ===== Raw Model Output =====
      Mixed text + JSON
    """
    # 1. Remove code fences ```json ``` 
    cleaned = re.sub(r"```(json)?", "", raw_text)
    cleaned = cleaned.replace("```", "")

    # 2. Find the JSON object: everything between the first { and last }
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if not match:
        raise ValueError("No JSON object found in LLM response")

    json_text = match.group(0)

    # 3. Convert to Python dict
    try:
        return json.loads(json_text)
    except json.JSONDecodeError as e:
        print("JSON decode failed. Raw text:")
        print(json_text)
        raise e


# ─────────────────────────────────────────────────────────
# Core per‑sheet processing using your existing extractor
# ─────────────────────────────────────────────────────────
def process_single_sheet(sheet_name: str, tmp_excel_path: str, screenshot_b64: str, mime_type: str = "image/png", base_dir: Path = Path(".")) -> str:
    """
    Runs your full logic for ONE sheet + ONE screenshot and follows your desired flow:
      - parse LLM output to JSON
      - save JSON to base/spec_<sheet>.json
      - call generate_docx(json_path, out_path)
      - return path to generated DOCX

    base_dir: folder that contains spec.json and 'output/' folder (configurable from UI)
    """
    # 1) Extract records using your function (path + sheet_name)
    extract_records_row_wise = extract_sheet_records_for_llm(
        tmp_excel_path,
        sheet_name,
        skip_blanks=True
    )

    # 2) Convert to LLM-friendly row text (your function)
    cleaned_input_for_llm = to_row_text_all_fields(
        extract_records_row_wise,
        always_show_all_keys=True,
        sort_rows_and_cols=True
    )

    cleaned_sheet_data_row_wise = f"""CLEANED_SHEET_DATA:
{cleaned_input_for_llm}
END_CLEANED_SHEET_DATA
"""

    # 3) Build your prompt (kept faithful to your earlier template)
    prompt = f"""
You are a meticulous analyst of SAP BPC/EPM Excel reports. You will be given:
1) A screenshot of the report.
2) A structured list of rows from the worksheet ("CLEANED_SHEET_DATA") where each row lists have:
   - cell address, visible value, EPM formula (if any), Excel formula (if any)
Your job is to derive a concise, auditable specification that answers the requested questions. 
RULES:
- Use only evidence from the provided rows and the screenshot. 
- If something is not explicitly present or safely inferable, answer 'Not found in input.' Do NOT hallucinate.
- When you assert a fact, reference the evidence (cell addresses and/or exact literal strings).
- Prefer what's in the row list over what you think might be true about BPC/EPM in general.
- For EPM functions, list them verbatim and name what they do if possible (e.g., EPMDimensionOverride overrides expansion for a dimension).
- If workbook name is not supplied in metadata, say 'Not provided.'
- Be explicit whether a dimension is displayed as Key (ID), Text (Description), or Key+Text; justify from cell text (e.g., '1090 - Al Futtaim (Pvt) Ltd.' implies Key+Text).
- For sorting, only report it if there is clear evidence (e.g., 'Column X values monotonic'). Otherwise say 'No evidence.'
- For KPI logic, only document what's visible (e.g., local member creation, retrieve data calls, Excel formulas). If the actual numeric formula isn't present, say “Defined as local member; numeric logic not present in input."
- For EPM formulas , You have to carefully check ROW by ROW.You have to consider all the EPM formulas from input text, and dont miss any EPM formula.
- For EPM local members, You have to carefully check ROW by ROW.You have to consider all the EPM local members from input text, and dont miss any EPM local member.
- For each Dimension give each separete dictionary with ,Dimensions,Hierarchies,Display,Business Purpose,Position of Dimension under 'dimension' key.
- For Json file, just include Keys and Sub keys as mentioned in required json format.
- Give only JSON output, Nothing else.

Below is the content of excel file:

{cleaned_sheet_data_row_wise}

Required JSON format:
{{
  "report headers": {{
    "Heading": "",
    "Report Objective": "",
    "User Action": ""
  }},
  "dimensions":{{"Dimensions": "dimensions names","Hierarchies": "hierarchies names","Display":"Display as Key, ID or Both Key +ID","Business Purpose": "Business purpose of the dimension","Position of Dimension":"Row/Column position"}},
  "Calculations/KPIs":{{"Name":"Name of KPI","Description":"Description of the KPI","Formula":"Formula of the KPI / EPM/ Normal Excel"}},
  "Model": "",
  "Environment": "",
  "EPM formulas": [{{"EPM formula":"Actual EPM Formula","EPM Formula Position":"Row/Column","Actula value in excel":"Actual value in excel"}}],
  "EPM Local Members": [{{"EPM Local Member":"Actual EPM Local Member","EPM Local Member Position":"Row/Column","Actula value in excel":"Actual value in excel"}}],
  "Normal Excel formulas": [{{"Excel formula":"Actual Excel Formula","Excel Formula Position":"Row/Column","Actula value in excel":"Actual value in excel"}}],
  "Report Summary": ""
}}
"""

    # 4) Prepare LLM content (text + image b64)
    content = [
        {"type": "text", "text": prompt},
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": mime_type,
                "data": screenshot_b64
            }
        }
    ]

    # 5) Call the model
    response = llm.invoke([HumanMessage(content=content)])
    raw_text = response.content

    # 6) Robust JSON parsing
    parsed_json = extract_json_safely(raw_text)
    # parsed_json = extract_json_from_llm(raw_text)
    # from normalize_json import normalize_llm_json

    # raw = parsed_json
    # parsed_json = normalize_llm_json(raw)

    # 7) Save parsed JSON to base/spec_<sheet>.json
    safe_sheet = sanitize_filename(sheet_name)
    base_dir.mkdir(parents=True, exist_ok=True)
    (base_dir / "output").mkdir(parents=True, exist_ok=True)

    json_path = base_dir / f"spec_{safe_sheet}.json"
    with open(json_path, "w", encoding="utf-8") as jf:
        json.dump(parsed_json, jf, indent=2, ensure_ascii=False)

    # 8) Call your generate_docx(json_path, out_path)
    #    If your function returns the saved path, use it; otherwise use out_path directly.
    out_path = base_dir / "output" / f"{safe_sheet}.docx"

    # Import here to avoid circulars if any
    from word_doc import generate_docx  # <-- update this import path
    # from word_doc_final import generate_docx
    

    try:
        saved_path = generate_docx(str(json_path), str(out_path))
        final_docx_path = saved_path if saved_path else str(out_path)
    except Exception as e:
        # As a fallback, write a simple docx with the JSON so the user gets something
        doc = Document()
        doc.add_heading(f"Sheet: {sheet_name}", level=1)
        doc.add_paragraph("⚠️ generate_docx() failed. Fallback content below.\n")
        doc.add_paragraph(json.dumps(parsed_json, indent=2))
        doc.save(str(out_path))
        final_docx_path = str(out_path)
        # Also surface the error in the UI caller

    return final_docx_path

# ─────────────────────────────────────────────────────────
# Streamlit UI
# ─────────────────────────────────────────────────────────
st.title("📄 Multi‑Sheet Excel Processor (BPC/EPM)")

st.markdown(
    "Upload an Excel file, select sheets, upload a screenshot per sheet, and generate **one Word file per sheet**."
)

# Maintain screenshots across reruns
if "screens" not in st.session_state:
    st.session_state["screens"] = {}  # {sheet: {"bytes": b"...", "mime": ..., "name": ...}}

# 1) Excel upload
excel_file = st.file_uploader("Upload Excel File", type=["xlsx"], key="excel_upload")

if excel_file:
    # Save uploaded Excel to temp file path
    tmp_excel_path = save_uploaded_excel(excel_file)

    # Load sheet names
    try:
        xls = pd.ExcelFile(tmp_excel_path)
        sheet_names = xls.sheet_names
    except Exception as e:
        st.error(f"Failed to read Excel: {e}")
        st.stop()

    # ---- OUTPUT & SPEC SETTINGS (UPDATED FOR DEPLOYMENT) ----
    st.subheader("Output & Spec Settings")

    # Create safe temp directory as default base directory
    default_base = tempfile.mkdtemp(prefix="bpc_epm_output_")

    base_dir_str = st.text_input(
        "Base folder (for SPEC JSONs + generated DOCX files):",
        value=default_base
    )

    base_dir = Path(base_dir_str)

    # Ensure directories exist
    (base_dir / "output").mkdir(parents=True, exist_ok=True)
    # -----------------------------------------------------------

    # 2) Select sheets
    selected_sheets = st.multiselect(
        "Select Sheets to Process",
        sheet_names,
        default=sheet_names
    )

    # 3) Upload screenshots
    if selected_sheets:
        st.subheader("Upload Screenshot for Each Selected Sheet")

        for sheet in selected_sheets:
            col1, col2 = st.columns([0.7, 0.3])

            with col1:
                up = st.file_uploader(
                    f"Screenshot for '{sheet}'",
                    type=["png", "jpg", "jpeg"],
                    key=f"ss_{sheet}"
                )

            with col2:
                if up is not None:
                    st.session_state["screens"][sheet] = {
                        "bytes": up.getvalue(),
                        "mime": up.type or "image/png",
                        "name": up.name
                    }

                if sheet in st.session_state["screens"]:
                    st.caption(f"Attached: {st.session_state['screens'][sheet]['name']}")
                else:
                    st.caption("No screenshot yet")

    # 4) Process button
    if st.button("🚀 Process All Selected Sheets"):
        missing = [s for s in selected_sheets if s not in st.session_state["screens"]]
        if missing:
            st.error(f"Please upload screenshots for: {', '.join(missing)}")
            st.stop()

        output_files = []
        total = len(selected_sheets)
        progress = st.progress(0, text="Starting...")

        for idx, sheet in enumerate(selected_sheets, start=1):
            scr = st.session_state["screens"][sheet]
            ss_b64 = bytes_to_base64(scr["bytes"])
            mime = scr["mime"] if scr["mime"] in ("image/png", "image/jpeg") else "image/png"

            try:
                out_path = process_single_sheet(
                    sheet,
                    tmp_excel_path,
                    ss_b64,
                    mime,
                    base_dir=base_dir   # ⭐ important change
                )
                output_files.append(out_path)
                progress.progress(idx / total, text=f"Processed {idx}/{total}: {sheet}")
            except Exception as e:
                st.error(f"Error processing '{sheet}': {e}")

        st.success("All selected sheets processed!")

        # Download buttons
        for file_path in output_files:
            try:
                with open(file_path, "rb") as f:
                    st.download_button(
                        label=f"⬇ Download {os.path.basename(file_path)}",
                        data=f.read(),
                        file_name=os.path.basename(file_path)
                    )
            except:
                st.warning(f"Could not read {file_path}")

        # ZIP download
        if output_files:
            zip_buf = io.BytesIO()
            with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in output_files:
                    if os.path.exists(p):
                        zf.write(p, arcname=os.path.basename(p))

            st.download_button(
                "📦 Download All as ZIP",
                data=zip_buf.getvalue(),
                file_name="outputs.zip",
                mime="application/zip"
            )

else:
    st.info("Please upload an Excel (.xlsx) to begin.")