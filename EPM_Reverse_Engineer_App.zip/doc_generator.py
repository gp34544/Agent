"""
doc_generator.py
Generates Word (.docx) specification documents from agent output.
Uses docx-js (Node.js) for high-quality document creation.
"""

import json
import subprocess
import os
from typing import Dict, Any


def generate_docx(spec: Dict[str, Any], output_path: str) -> str:
    """Generate a .docx specification document for a single sheet."""

    # Write spec to temp JSON for Node to read
    json_path = "/tmp/spec_data.json"
    with open(json_path, "w") as f:
        json.dump(spec, f, default=str)

    # Generate the Node.js script
    js_script = _build_js_script(json_path, output_path)
    js_path = "/tmp/generate_doc.js"
    with open(js_path, "w") as f:
        f.write(js_script)

    result = subprocess.run(
        ["node", js_path],
        capture_output=True, text=True, timeout=60
    )
    if result.returncode != 0:
        raise RuntimeError(f"docx generation failed: {result.stderr}")

    return output_path


def _build_js_script(json_path: str, output_path: str) -> str:
    return '''
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  PageBreak, LevelFormat, Header, Footer, PageNumber
} = require("docx");

const spec = JSON.parse(fs.readFileSync("''' + json_path + '''", "utf-8"));

// ── Helpers ──
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headerBg = { fill: "2E5090", type: ShadingType.CLEAR };
const altRowBg = { fill: "F2F6FC", type: ShadingType.CLEAR };
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };

function headerCell(text, width) {
  return new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: headerBg, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text, bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })]
  });
}

function dataCell(text, width, shading) {
  const opts = { borders, width: { size: width, type: WidthType.DXA }, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text: String(text || ""), font: "Arial", size: 18 })] })] };
  if (shading) opts.shading = shading;
  return new TableCell(opts);
}

function sectionHeading(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 150 },
    children: [new TextRun({ text, bold: true, font: "Arial", size: 28, color: "2E5090" })] });
}

function subHeading(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_3, spacing: { before: 200, after: 100 },
    children: [new TextRun({ text, bold: true, font: "Arial", size: 24 })] });
}

function bodyText(text) {
  return new Paragraph({ spacing: { after: 100 },
    children: [new TextRun({ text: String(text || ""), font: "Arial", size: 20 })] });
}

function emptyLine() {
  return new Paragraph({ spacing: { after: 80 }, children: [] });
}

// ── Build Document ──
const children = [];

// Title
children.push(new Paragraph({
  heading: HeadingLevel.HEADING_1,
  spacing: { after: 200 },
  children: [new TextRun({ text: "Report Specification", bold: true, font: "Arial", size: 36, color: "2E5090" })]
}));

// Meta info table
const metaCols = [3000, 6360];
children.push(new Table({
  width: { size: 9360, type: WidthType.DXA }, columnWidths: metaCols,
  rows: [
    new TableRow({ children: [headerCell("Field", 3000), headerCell("Value", 6360)] }),
    new TableRow({ children: [dataCell("Workbook Name", 3000), dataCell(spec.workbook_name, 6360)] }),
    new TableRow({ children: [dataCell("Sheet/Report Name", 3000, altRowBg), dataCell(spec.sheet_name, 6360, altRowBg)] }),
    new TableRow({ children: [dataCell("Report Objective", 3000), dataCell(spec.report_objective, 6360)] }),
    new TableRow({ children: [dataCell("User Action", 3000, altRowBg), dataCell(spec.user_action, 6360, altRowBg)] }),
  ]
}));
children.push(emptyLine());

// ── Section 1: Dimensions ──
children.push(sectionHeading("1. Dimensions"));

const dims = spec.dimensions || {};
const dimKeys = Object.keys(dims);

if (dimKeys.length > 0) {
  const dimCols = [1800, 1800, 2000, 1200, 2560];
  const dimRows = [
    new TableRow({ children: [
      headerCell("Dimension", 1800), headerCell("Hierarchies", 1800),
      headerCell("Sample Members", 2000), headerCell("Display", 1200),
      headerCell("Sorting", 2560)
    ] })
  ];

  dimKeys.forEach((key, i) => {
    const d = dims[key];
    const bg = i % 2 === 1 ? altRowBg : undefined;
    dimRows.push(new TableRow({ children: [
      dataCell(d.name, 1800, bg),
      dataCell((d.hierarchies || []).join(", "), 1800, bg),
      dataCell((d.members || []).slice(0, 5).join(", "), 2000, bg),
      dataCell(d.display_mode, 1200, bg),
      dataCell(d.sorting, 2560, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: dimCols, rows: dimRows }));
} else {
  children.push(bodyText("No BPC dimensions detected in this sheet."));
}
children.push(emptyLine());

// ── Section 2: Measures/KPIs ──
children.push(sectionHeading("2. Measures / KPIs"));

const measures = spec.measures || [];
if (measures.length > 0) {
  const mCols = [1500, 2000, 3500, 2360];
  const mRows = [
    new TableRow({ children: [
      headerCell("Name", 1500), headerCell("Type", 2000),
      headerCell("Description / Formula", 3500), headerCell("Cell", 2360)
    ] })
  ];

  measures.slice(0, 30).forEach((m, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    const desc = m.description || m.formula || m.check_formula || "";
    mRows.push(new TableRow({ children: [
      dataCell(m.name, 1500, bg), dataCell(m.type, 2000, bg),
      dataCell(String(desc).substring(0, 150), 3500, bg), dataCell(m.cell || "", 2360, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: mCols, rows: mRows }));
} else {
  children.push(bodyText("No measures or KPIs detected in this sheet."));
}
children.push(emptyLine());

// ── Section 3: Validation / Business Rules ──
children.push(sectionHeading("3. Business Rules / Validations"));

const vals = spec.validations || [];
if (vals.length > 0) {
  const vCols = [1200, 2800, 1500, 1500, 2360];
  const vRows = [
    new TableRow({ children: [
      headerCell("Rule ID", 1200), headerCell("Description", 2800),
      headerCell("Rule Type", 1500), headerCell("FS Item", 1500),
      headerCell("Validation Logic", 2360)
    ] })
  ];

  vals.forEach((v, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    vRows.push(new TableRow({ children: [
      dataCell(v.id, 1200, bg), dataCell(v.description, 2800, bg),
      dataCell(v.rule_type, 1500, bg),
      dataCell(v.fs_item ? String(v.fs_item).substring(0, 80) : "", 1500, bg),
      dataCell(v.validation_formula ? String(v.validation_formula).substring(0, 100) : "", 2360, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: vCols, rows: vRows }));
} else {
  children.push(bodyText("No validation rules detected in this sheet."));
}
children.push(emptyLine());

// ── Section 4: EPM Functions ──
children.push(sectionHeading("4. EPM Functions Used"));

const epmFuncs = spec.epm_functions || {};
const epmKeys = Object.keys(epmFuncs);

if (epmKeys.length > 0) {
  const eCols = [3000, 3800, 1000, 1560];
  const eRows = [
    new TableRow({ children: [
      headerCell("Function", 3000), headerCell("Description", 3800),
      headerCell("Count", 1000), headerCell("Sample Cell", 1560)
    ] })
  ];

  epmKeys.forEach((key, i) => {
    const e = epmFuncs[key];
    const bg = i % 2 === 1 ? altRowBg : undefined;
    eRows.push(new TableRow({ children: [
      dataCell(e.function, 3000, bg), dataCell(e.description, 3800, bg),
      dataCell(String(e.usage_count), 1000, bg),
      dataCell((e.sample_cells || []).join(", "), 1560, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: eCols, rows: eRows }));
} else {
  children.push(bodyText("No EPM functions detected in this sheet."));
}
children.push(emptyLine());

// ── Section 5: Local Members ──
children.push(sectionHeading("5. EPM Local Members (Calculated Members)"));

const localMembers = spec.local_members || [];
if (localMembers.length > 0) {
  const lCols = [2200, 1000, 4000, 2160];
  const lRows = [
    new TableRow({ children: [
      headerCell("Member Name", 2200), headerCell("ID", 1000),
      headerCell("Formula Context", 4000), headerCell("Cell", 2160)
    ] })
  ];

  localMembers.forEach((lm, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    lRows.push(new TableRow({ children: [
      dataCell(lm.name, 2200, bg), dataCell(lm.id, 1000, bg),
      dataCell(String(lm.full_formula || "").substring(0, 150), 4000, bg),
      dataCell(lm.cell, 2160, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: lCols, rows: lRows }));
} else {
  children.push(bodyText("No EPM Local Members detected in this sheet."));
}
children.push(emptyLine());

// ── Section 6: Custom Formulas ──
children.push(sectionHeading("6. Custom Excel Formulas"));

const customFormulas = spec.custom_formulas || [];
if (customFormulas.length > 0) {
  const fCols = [1200, 1800, 6360];
  const fRows = [
    new TableRow({ children: [
      headerCell("Cell", 1200), headerCell("Type", 1800), headerCell("Formula", 6360)
    ] })
  ];

  customFormulas.slice(0, 25).forEach((cf, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    fRows.push(new TableRow({ children: [
      dataCell(cf.cell, 1200, bg), dataCell(cf.type, 1800, bg),
      dataCell(String(cf.formula).substring(0, 200), 6360, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: fCols, rows: fRows }));
} else {
  children.push(bodyText("No significant custom Excel formulas detected."));
}
children.push(emptyLine());

// ── Section 7: Cross-Sheet References ──
children.push(sectionHeading("7. Cross-Sheet References"));

const crossRefs = spec.cross_sheet_references || [];
if (crossRefs.length > 0) {
  const crCols = [1500, 2200, 5660];
  const crRows = [
    new TableRow({ children: [
      headerCell("From Cell", 1500), headerCell("Target Sheet", 2200), headerCell("Formula", 5660)
    ] })
  ];

  crossRefs.slice(0, 15).forEach((cr, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    crRows.push(new TableRow({ children: [
      dataCell(cr.from_cell, 1500, bg), dataCell(cr.target_sheet, 2200, bg),
      dataCell(String(cr.formula).substring(0, 180), 5660, bg),
    ] }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: crCols, rows: crRows }));
} else {
  children.push(bodyText("No cross-sheet references detected."));
}
children.push(emptyLine());

// ── Section 8: Formatting ──
children.push(sectionHeading("8. Formatting & Layout"));

const fmt = spec.formatting || {};
if (fmt.is_formatting_sheet) {
  children.push(bodyText("This is an EPM Formatting Sheet controlling visual presentation."));
  const rules = fmt.rules || [];
  if (rules.length > 0) {
    rules.forEach(r => {
      children.push(bodyText("  " + r.type + " (" + r.section + ")" + (r.detail ? " - " + r.detail : "")));
    });
  }
} else {
  children.push(bodyText("Formatting sheet: No (this is a data/report sheet)"));
}

const merged = fmt.merged_cells || [];
if (merged.length > 0) {
  children.push(bodyText("Merged cell ranges: " + merged.slice(0, 10).join(", ") + (merged.length > 10 ? " ..." : "")));
}

// ── SAC Migration Notes ──
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(sectionHeading("9. SAC Planning Migration Notes"));
children.push(bodyText("This section provides recommendations for rebuilding this report in SAC Planning."));
children.push(emptyLine());

// Auto-generate migration notes based on findings
const notes = [];

if (dimKeys.length > 0) {
  notes.push("DIMENSIONS: Map the following BPC dimensions to SAC model dimensions: " + dimKeys.join(", ") + ".");
}

if (localMembers.length > 0) {
  const lmNames = localMembers.map(lm => lm.name).filter(n => n).join(", ");
  notes.push("LOCAL MEMBERS: The following EPM Local Members need to be recreated as SAC Calculated/Restricted Members or Account-based formulas: " + lmNames + ".");
}

if (vals.length > 0) {
  notes.push("VALIDATIONS: " + vals.length + " validation rules need to be migrated. Consider using SAC Data Actions or Allocations for business rule execution.");
}

if (epmKeys.length > 0) {
  notes.push("EPM FUNCTIONS: " + epmKeys.length + " unique EPM functions are used. EPMOlapMemberO members become SAC dimension members. EPMContextMember calls become SAC page filter selections. EPMLocalMember definitions become SAC calculated members.");
}

if (customFormulas.length > 0) {
  notes.push("CUSTOM FORMULAS: " + customFormulas.length + " Excel formulas need to be reviewed. SUMIF/COUNTIF logic may need SAC Data Actions. VLOOKUP logic may need SAC lookup dimensions or data actions.");
}

if (crossRefs.length > 0) {
  notes.push("CROSS-REFERENCES: This sheet references other sheets. In SAC, consider using multi-model stories or linked planning models.");
}

if (fmt.is_formatting_sheet) {
  notes.push("FORMATTING: This EPM formatting sheet controls visual display. In SAC, use table formatting, conditional formatting, and CSS styling in the story/application designer.");
}

notes.forEach(n => {
  children.push(bodyText(n));
  children.push(emptyLine());
});

// ── Build Doc ──
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 240, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 200, after: 150 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Arial" },
        paragraph: { spacing: { before: 160, after: 100 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "SAP EPM to SAC Migration - Report Specification", italics: true, font: "Arial", size: 16, color: "888888" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", font: "Arial", size: 16 }),
            new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 16 }),
          ]
        })]
      })
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("''' + output_path + '''", buffer);
  console.log("OK:" + "''' + output_path + '''");
}).catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
'''


def generate_all_specs(all_specs: Dict[str, Dict], output_dir: str) -> Dict[str, str]:
    """Generate a Word doc for each sheet specification."""
    os.makedirs(output_dir, exist_ok=True)
    generated = {}

    for sheet_name, spec in all_specs.items():
        safe_name = sheet_name.replace(" ", "_").replace("%", "Pct").replace("/", "_")
        output_path = os.path.join(output_dir, f"Spec_{safe_name}.docx")
        try:
            generate_docx(spec, output_path)
            generated[sheet_name] = output_path
        except Exception as e:
            generated[sheet_name] = f"ERROR: {e}"

    return generated
