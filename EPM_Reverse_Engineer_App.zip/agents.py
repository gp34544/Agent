"""
agents.py
Agent-based architecture for reverse engineering SAP BPC/EPM reports.
Each agent is a specialist that extracts one aspect of the report specification.

Architecture mirrors Google ADK pattern:
  - Each agent has a name, description, and run() method
  - Orchestrator coordinates agents and assembles results
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from excel_parser import WorkbookData, SheetData, CellInfo


# ─────────────────────────────────────────────
# Base Agent
# ─────────────────────────────────────────────

@dataclass
class AgentResult:
    agent_name: str
    sheet_name: str
    data: Dict[str, Any] = field(default_factory=dict)


class BaseAgent:
    """Base class for all agents. Mirrors Google ADK Agent interface."""
    name: str = "BaseAgent"
    description: str = "Base agent"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        raise NotImplementedError


# ─────────────────────────────────────────────
# Agent 1: Dimension Agent
# ─────────────────────────────────────────────

class DimensionAgent(BaseAgent):
    """Extracts dimensions, hierarchies, display modes (Key/Text), and sorting."""
    name = "DimensionAgent"
    description = "Extracts BPC dimensions, hierarchies, and display settings"

    # Known BPC/EPM dimension patterns
    KNOWN_DIMENSIONS = [
        "ENTITY", "ACCOUNT", "CATEGORY", "TIME", "TPARTNER",
        "BFLOW", "FLOW", "MODEL", "DATASRC", "CURRENCY",
        "MEASURES", "INTCO", "AUDIT_TRAIL",
    ]

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        dimensions = {}

        # Pattern 1: EPMOlapMemberO functions contain dimension info
        olap_pattern = re.compile(
            r'EPMOlapMemberO\(\s*"?\[(\w+)\]\.\[(\w+)\]\.\[([^\]]+)\]"?'
        )
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in olap_pattern.finditer(val):
                dim_name = match.group(1)
                hierarchy = match.group(2)
                member = match.group(3)
                if dim_name not in dimensions:
                    dimensions[dim_name] = {
                        "name": dim_name,
                        "hierarchies": set(),
                        "members": [],
                        "display_mode": "Key ID",
                        "sorting": "Not specified",
                        "cell_references": [],
                    }
                dimensions[dim_name]["hierarchies"].add(hierarchy)
                dimensions[dim_name]["members"].append(member)
                dimensions[dim_name]["cell_references"].append(cell.address)

        # Pattern 2: EPMContextMember calls
        ctx_pattern = re.compile(r'EPMContextMember\(\s*"?(\$?\w+\$?\w*)"?,\s*(\w+)\)')
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in ctx_pattern.finditer(val):
                dim_name = match.group(2)
                if dim_name not in dimensions:
                    dimensions[dim_name] = {
                        "name": dim_name,
                        "hierarchies": set(),
                        "members": [],
                        "display_mode": "Key ID",
                        "sorting": "Not specified",
                        "cell_references": [],
                    }
                dimensions[dim_name]["cell_references"].append(cell.address)

        # Pattern 3: Explicit dimension labels in cells (e.g., C3=MODEL, C5=ENTITY)
        for cell in sheet.cells:
            val = str(cell.value).strip().upper()
            if val in self.KNOWN_DIMENSIONS and val not in dimensions:
                dimensions[val] = {
                    "name": val,
                    "hierarchies": set(),
                    "members": [],
                    "display_mode": "Key ID",
                    "sorting": "Not specified",
                    "cell_references": [cell.address],
                }

        # Check for EPMMemberDesc (indicates Text display)
        for cell in sheet.epm_cells:
            val = str(cell.value)
            if "EPMMemberDesc" in val:
                for dim_name in dimensions:
                    if dim_name.lower() in val.lower():
                        dimensions[dim_name]["display_mode"] = "Text (Description)"
                # Generic description usage
                desc_match = re.findall(r'EPMMemberDesc\(([^)]+)\)', val)
                if desc_match:
                    for d in dimensions.values():
                        if any(ref in val for ref in d.get("cell_references", [])):
                            d["display_mode"] = "Key ID + Text"

        # Convert sets to lists for serialization
        for d in dimensions.values():
            d["hierarchies"] = sorted(d["hierarchies"])
            d["members"] = list(dict.fromkeys(d["members"]))[:20]  # dedupe, limit

        result.data["dimensions"] = dimensions
        return result


# ─────────────────────────────────────────────
# Agent 2: Measure/KPI Agent
# ─────────────────────────────────────────────

class MeasureAgent(BaseAgent):
    """Extracts measures, KPIs, and their calculation logic."""
    name = "MeasureAgent"
    description = "Extracts measures, KPIs, and calculated members"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        measures = []

        # Pattern 1: EPMOlapMemberO for MEASURES dimension
        for cell in sheet.epm_cells:
            val = str(cell.value)
            if "[MEASURES]" in val:
                measure_match = re.search(r'\[MEASURES\]\.\[\]\.\[(\w+)\]', val)
                if measure_match:
                    measures.append({
                        "name": measure_match.group(1),
                        "type": "OLAP Measure",
                        "cell": cell.address,
                        "formula": val,
                    })

        # Pattern 2: EPMRetrieveData calls
        for cell in sheet.epm_cells:
            val = str(cell.value)
            if "EPMRetrieveData" in val:
                measures.append({
                    "name": f"Retrieved Data at {cell.address}",
                    "type": "EPM Data Retrieval",
                    "cell": cell.address,
                    "formula": val,
                })

        # Pattern 3: Validation descriptions (D column typically holds KPI names)
        for cell in sheet.cells:
            val = str(cell.value)
            # Match validation IDs like V11001, V110010
            if re.match(r'^V\d{4,6}$', val):
                # Find the description in adjacent cell
                row_num = int(re.search(r'\d+', cell.address).group())
                desc_cell = self._find_cell(sheet, f"D{row_num}")
                check_cell = self._find_cell(sheet, f"E{row_num}")
                formula_cell = self._find_cell(sheet, f"F{row_num}")

                measure = {
                    "name": val,
                    "type": "Validation KPI",
                    "cell": cell.address,
                    "description": desc_cell.value if desc_cell else "",
                    "check_formula": str(check_cell.value) if check_cell else "",
                    "validation_formula": str(formula_cell.value) if formula_cell else "",
                }
                measures.append(measure)

        # Pattern 4: Column headers that look like measures
        measure_keywords = ["net sales", "cost of goods", "margin", "revenue",
                           "closing", "opening", "balance", "total", "ytd"]
        for cell in sheet.cells:
            val = str(cell.value).lower()
            if any(kw in val for kw in measure_keywords):
                row_num = int(re.search(r'\d+', cell.address).group())
                if row_num <= 30:  # Header rows typically
                    measures.append({
                        "name": str(cell.value),
                        "type": "Report Column/Measure",
                        "cell": cell.address,
                    })

        result.data["measures"] = measures
        return result

    def _find_cell(self, sheet: SheetData, address: str) -> Optional[CellInfo]:
        for c in sheet.cells:
            if c.address == address:
                return c
        return None


# ─────────────────────────────────────────────
# Agent 3: Formula Agent
# ─────────────────────────────────────────────

class FormulaAgent(BaseAgent):
    """Extracts EPM formulas, local members, and custom calculations."""
    name = "FormulaAgent"
    description = "Extracts EPM functions, local members, and Excel formulas"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)

        # 1. EPM Functions catalog
        epm_functions = {}
        epm_pattern = re.compile(r'(_xll\.[\w.]+)')
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in epm_pattern.finditer(val):
                func_name = match.group(1)
                if func_name not in epm_functions:
                    epm_functions[func_name] = {
                        "function": func_name,
                        "description": self._describe_epm_function(func_name),
                        "usage_count": 0,
                        "sample_cells": [],
                        "sample_formulas": [],
                    }
                epm_functions[func_name]["usage_count"] += 1
                if len(epm_functions[func_name]["sample_cells"]) < 3:
                    epm_functions[func_name]["sample_cells"].append(cell.address)
                    epm_functions[func_name]["sample_formulas"].append(val[:200])

        # 2. EPM Local Members
        local_members = []
        lm_pattern = re.compile(
            r'EPMLocalMember\(\s*"([^"]*)",\s*"(\d+)",\s*"(\d+)"\s*\)'
        )
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in lm_pattern.finditer(val):
                local_members.append({
                    "name": match.group(1),
                    "id": match.group(2),
                    "connection": match.group(3),
                    "cell": cell.address,
                    "full_formula": val[:200],
                })

        # 3. Custom Excel formulas (non-EPM)
        custom_formulas = []
        for cell in sheet.formula_cells:
            val = str(cell.value)
            if "_xll." not in val and val.startswith("="):
                # Only capture significant formulas
                if any(f in val.upper() for f in [
                    "SUMIF", "VLOOKUP", "COUNTIF", "IF(", "IFERROR",
                    "SUM(", "ABS(", "INDEX", "MATCH"
                ]):
                    custom_formulas.append({
                        "cell": cell.address,
                        "formula": val[:300],
                        "type": self._classify_formula(val),
                    })

        # 4. Cross-sheet references
        cross_refs = []
        for cell in sheet.formula_cells:
            val = str(cell.value)
            if "!" in val and "'" in val:
                sheet_ref = re.findall(r"'([^']+)'!", val)
                for ref in sheet_ref:
                    cross_refs.append({
                        "from_cell": cell.address,
                        "target_sheet": ref,
                        "formula": val[:200],
                    })

        result.data["epm_functions"] = epm_functions
        result.data["local_members"] = local_members
        result.data["custom_formulas"] = custom_formulas[:50]  # Limit
        result.data["cross_sheet_references"] = cross_refs
        return result

    def _describe_epm_function(self, func: str) -> str:
        descriptions = {
            "_xll.EPMOlapMemberO": "Retrieves OLAP member from BPC model with hierarchy placement",
            "_xll.EPMContextMember": "Gets current context member for a dimension",
            "_xll.EPMMemberDesc": "Returns the text description of a member ID",
            "_xll.EPMMemberProperty": "Retrieves a property value of a member",
            "_xll.EPMDimensionOverride": "Overrides dimension selection for specific report area",
            "_xll.EPMModelCubeID": "Returns the model/cube identifier",
            "_xll.EPMRetrieveData": "Retrieves data values from BPC model",
            "_xll.EPMReadOnlyData": "Marks data range as read-only",
            "_xll.FPMXLClient.TechnicalCategory.EPMLocalMember": "Defines a local calculated member",
        }
        return descriptions.get(func, "EPM add-in function")

    def _classify_formula(self, formula: str) -> str:
        f = formula.upper()
        if "SUMIF" in f or "COUNTIF" in f:
            return "Conditional Aggregation"
        if "VLOOKUP" in f or "INDEX" in f:
            return "Lookup"
        if "IF(" in f:
            return "Conditional Logic"
        if "SUM(" in f:
            return "Aggregation"
        return "Calculation"


# ─────────────────────────────────────────────
# Agent 4: Formatting Agent
# ─────────────────────────────────────────────

class FormattingAgent(BaseAgent):
    """Extracts EPM formatting rules and conditional formatting."""
    name = "FormattingAgent"
    description = "Extracts hierarchy formatting, conditional formatting, and display rules"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)

        is_formatting_sheet = "format" in sheet.name.lower() or "frmt" in sheet.name.lower()
        formatting_rules = []

        if is_formatting_sheet:
            # Parse formatting sheet structure
            current_section = None
            for cell in sheet.cells:
                val = str(cell.value)
                if "Row" == val.strip():
                    current_section = "Row"
                elif "Column" == val.strip():
                    current_section = "Column"
                elif "Member" in val and "Format" in val:
                    current_section = "Member Specific"
                elif "Default Format" in val:
                    formatting_rules.append({
                        "type": "Default Format",
                        "section": current_section or "General",
                        "cell": cell.address,
                    })
                elif "Base Level" in val:
                    formatting_rules.append({
                        "type": "Base Level Format",
                        "section": current_section or "General",
                        "cell": cell.address,
                    })
                elif "Level" in val and ("Format" in val or "Lowest" in val):
                    formatting_rules.append({
                        "type": f"Level-Specific Format",
                        "section": current_section or "General",
                        "cell": cell.address,
                        "detail": val[:100],
                    })

            # Extract member-specific formatting
            member_formats = []
            for cell in sheet.cells:
                val = str(cell.value)
                if any(keyword in val for keyword in [
                    "EPMFormat", "FontBold", "FontSize", "BackColor",
                    "ForeColor", "NumberFormat"
                ]):
                    member_formats.append({
                        "cell": cell.address,
                        "rule": val[:200],
                    })

            result.data["formatting_rules"] = formatting_rules
            result.data["member_formats"] = member_formats
            result.data["is_formatting_sheet"] = True
        else:
            result.data["formatting_rules"] = []
            result.data["member_formats"] = []
            result.data["is_formatting_sheet"] = False

        # Merged cells as layout info
        result.data["merged_cells"] = sheet.merged_ranges
        return result


# ─────────────────────────────────────────────
# Agent 5: Validation/Business Rule Agent
# ─────────────────────────────────────────────

class ValidationAgent(BaseAgent):
    """Extracts business validation rules and their logic."""
    name = "ValidationAgent"
    description = "Extracts validation rules, business logic, and data quality checks"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        validations = []
        exceptions = []

        for cell in sheet.cells:
            val = str(cell.value)
            # Match validation IDs
            if re.match(r'^V\d{4,6}$', val):
                row_num = int(re.search(r'\d+', cell.address).group())
                validation = {
                    "id": val,
                    "description": "",
                    "check_formula": "",
                    "validation_formula": "",
                    "fs_item": "",
                    "flow": "",
                    "tpartner": "",
                    "threshold": "",
                    "rule_type": "Restrictive",
                }

                # Collect data from same row
                for c in sheet.cells:
                    c_row = int(re.search(r'\d+', c.address).group())
                    if c_row != row_num:
                        continue
                    col_letter = re.match(r'[A-Z]+', c.address).group()

                    if col_letter == "D":
                        validation["description"] = str(c.value)
                    elif col_letter == "E":
                        validation["check_formula"] = str(c.value)[:200]
                    elif col_letter == "F":
                        validation["validation_formula"] = str(c.value)[:200]
                        # Extract threshold
                        thresh = re.findall(r'>(\d+)|<(-?\d+)', str(c.value))
                        if thresh:
                            validation["threshold"] = str(thresh)
                    elif col_letter == "G":
                        validation["fs_item"] = str(c.value)[:100]
                    elif col_letter == "H":
                        validation["flow"] = str(c.value)[:100]
                    elif col_letter == "I":
                        validation["tpartner"] = str(c.value)[:100]

                validations.append(validation)

            # Detect exception sections
            if "exception" in val.lower() or "error" in val.lower():
                if cell.address.startswith("C") or cell.address.startswith("D"):
                    exceptions.append({
                        "cell": cell.address,
                        "label": val,
                    })

        # Classify validations
        for v in validations:
            desc = v["description"].lower()
            if "missing" in desc:
                v["rule_type"] = "Exception/Warning"
            elif "reverse" in desc or "negative" in desc:
                v["rule_type"] = "Data Quality Check"
            elif "=" in desc and ("asset" in desc or "balance" in desc or "net income" in desc):
                v["rule_type"] = "Balance Validation"
            elif "movement" in desc or "not equals" in desc:
                v["rule_type"] = "Movement Reconciliation"

        result.data["validations"] = validations
        result.data["exceptions"] = exceptions
        result.data["report_objective"] = self._find_objective(sheet)
        result.data["user_action"] = self._find_user_action(sheet)
        return result

    def _find_objective(self, sheet: SheetData) -> str:
        for cell in sheet.cells:
            if str(cell.value).strip().lower() == "report objective":
                row = int(re.search(r'\d+', cell.address).group())
                for c in sheet.cells:
                    c_row = int(re.search(r'\d+', c.address).group())
                    if c_row == row and c.address != cell.address:
                        return str(c.value)
        return "Not specified"

    def _find_user_action(self, sheet: SheetData) -> str:
        for cell in sheet.cells:
            if str(cell.value).strip().lower() == "user action":
                row = int(re.search(r'\d+', cell.address).group())
                for c in sheet.cells:
                    c_row = int(re.search(r'\d+', c.address).group())
                    if c_row == row and c.address != cell.address:
                        return str(c.value)
        return "Not specified"


# ─────────────────────────────────────────────
# Agent 6: Summary/Specification Agent
# ─────────────────────────────────────────────

class SpecificationAgent(BaseAgent):
    """Assembles all agent outputs into a structured specification."""
    name = "SpecificationAgent"
    description = "Assembles all findings into a SAC Planning report specification"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        """This agent is called after all others and receives their results."""
        # Placeholder - real assembly happens in orchestrator
        return AgentResult(agent_name=self.name, sheet_name=sheet.name)

    def assemble(
        self,
        sheet_name: str,
        workbook_name: str,
        dim_result: AgentResult,
        measure_result: AgentResult,
        formula_result: AgentResult,
        format_result: AgentResult,
        validation_result: AgentResult,
    ) -> Dict[str, Any]:
        """Assemble all agent results into a unified specification."""
        spec = {
            "workbook_name": workbook_name,
            "sheet_name": sheet_name,
            "report_objective": validation_result.data.get("report_objective", "N/A"),
            "user_action": validation_result.data.get("user_action", "N/A"),
            "dimensions": dim_result.data.get("dimensions", {}),
            "measures": measure_result.data.get("measures", []),
            "epm_functions": formula_result.data.get("epm_functions", {}),
            "local_members": formula_result.data.get("local_members", []),
            "custom_formulas": formula_result.data.get("custom_formulas", []),
            "cross_sheet_references": formula_result.data.get("cross_sheet_references", []),
            "formatting": {
                "is_formatting_sheet": format_result.data.get("is_formatting_sheet", False),
                "rules": format_result.data.get("formatting_rules", []),
                "member_formats": format_result.data.get("member_formats", []),
                "merged_cells": format_result.data.get("merged_cells", []),
            },
            "validations": validation_result.data.get("validations", []),
            "exceptions": validation_result.data.get("exceptions", []),
        }
        return spec


# ─────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────

class Orchestrator:
    """Coordinates all agents and produces specifications per sheet."""

    def __init__(self):
        self.dim_agent = DimensionAgent()
        self.measure_agent = MeasureAgent()
        self.formula_agent = FormulaAgent()
        self.format_agent = FormattingAgent()
        self.validation_agent = ValidationAgent()
        self.spec_agent = SpecificationAgent()
        self.agents = [
            self.dim_agent, self.measure_agent, self.formula_agent,
            self.format_agent, self.validation_agent,
        ]

    def process_workbook(self, workbook: WorkbookData) -> Dict[str, Dict]:
        """Run all agents on every sheet and return specifications."""
        all_specs = {}

        for sheet_name, sheet in workbook.sheets.items():
            # Run each specialist agent
            dim_result = self.dim_agent.run(sheet, workbook)
            measure_result = self.measure_agent.run(sheet, workbook)
            formula_result = self.formula_agent.run(sheet, workbook)
            format_result = self.format_agent.run(sheet, workbook)
            validation_result = self.validation_agent.run(sheet, workbook)

            # Assemble into specification
            spec = self.spec_agent.assemble(
                sheet_name=sheet_name,
                workbook_name=workbook.filename,
                dim_result=dim_result,
                measure_result=measure_result,
                formula_result=formula_result,
                format_result=format_result,
                validation_result=validation_result,
            )
            all_specs[sheet_name] = spec

        return all_specs
