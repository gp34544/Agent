"""
app.py
Streamlit frontend for SAP EPM Report Reverse Engineering Tool.
Upload an EPM Excel workbook → get Word specification documents per sheet.
"""

import streamlit as st
import os
import sys
import zipfile
import tempfile
from pathlib import Path

# Add project to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from excel_parser import parse_workbook, get_epm_functions
from agents import Orchestrator
from doc_generator import generate_all_specs, generate_docx


# ── Page Config ──
st.set_page_config(
    page_title="SAP EPM → SAC Report Spec Generator",
    page_icon="📊",
    layout="wide",
)

# ── Custom CSS ──
st.markdown("""
<style>
    .main-header {
        font-size: 2rem;
        font-weight: 700;
        color: #2E5090;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1rem;
        color: #666;
        margin-bottom: 2rem;
    }
    .agent-card {
        background: #f8f9fa;
        border-left: 4px solid #2E5090;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0 8px 8px 0;
    }
    .metric-box {
        background: linear-gradient(135deg, #2E5090, #4A90D9);
        color: white;
        padding: 1.2rem;
        border-radius: 10px;
        text-align: center;
    }
    .metric-box h3 { color: white; margin: 0; font-size: 2rem; }
    .metric-box p { color: #ddd; margin: 0; font-size: 0.85rem; }
    .stDownloadButton > button {
        background-color: #2E5090;
        color: white;
        border: none;
        padding: 0.5rem 2rem;
    }
</style>
""", unsafe_allow_html=True)


# ── Header ──
st.markdown('<div class="main-header">📊 SAP EPM → SAC Report Specification Generator</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Reverse-engineer SAP BPC/EPM Excel reports into structured specifications for SAC Planning migration</div>', unsafe_allow_html=True)

# ── Sidebar ──
with st.sidebar:
    st.header("⚙️ How It Works")
    st.markdown("""
    **6 Specialized Agents** analyze your EPM workbook:

    1. **DimensionAgent** — Extracts BPC dimensions, hierarchies, display modes
    2. **MeasureAgent** — Identifies KPIs, measures, and calculations
    3. **FormulaAgent** — Catalogs EPM functions, local members, Excel formulas
    4. **FormattingAgent** — Reads EPM formatting rules and layout
    5. **ValidationAgent** — Extracts business rules and data quality checks
    6. **SpecificationAgent** — Assembles everything into a Word document
    """)

    st.divider()
    st.markdown("**Supported Inputs:** `.xlsx` EPM workbooks")
    st.markdown("**Output:** One `.docx` specification per sheet")

# ── File Upload ──
st.markdown("### 📁 Upload EPM Workbook")
uploaded_file = st.file_uploader(
    "Drop your SAP BPC/EPM Excel file here",
    type=["xlsx", "xlsm"],
    help="Upload the EPM report workbook you want to reverse-engineer"
)

if uploaded_file is not None:
    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    # ── Step 1: Parse ──
    with st.spinner("🔍 Parsing workbook..."):
        workbook_data = parse_workbook(tmp_path)

    # ── Overview Metrics ──
    st.markdown("---")
    st.markdown("### 📈 Workbook Overview")

    total_formulas = sum(len(s.formula_cells) for s in workbook_data.sheets.values())
    total_epm = sum(len(s.epm_cells) for s in workbook_data.sheets.values())
    epm_funcs = get_epm_functions(workbook_data)
    unique_funcs = set()
    for funcs in epm_funcs.values():
        unique_funcs.update(funcs)

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(f'<div class="metric-box"><h3>{len(workbook_data.sheet_names)}</h3><p>Sheets</p></div>', unsafe_allow_html=True)
    with col2:
        st.markdown(f'<div class="metric-box"><h3>{total_formulas}</h3><p>Formulas</p></div>', unsafe_allow_html=True)
    with col3:
        st.markdown(f'<div class="metric-box"><h3>{total_epm}</h3><p>EPM Cells</p></div>', unsafe_allow_html=True)
    with col4:
        st.markdown(f'<div class="metric-box"><h3>{len(unique_funcs)}</h3><p>Unique EPM Functions</p></div>', unsafe_allow_html=True)

    # ── Sheet Selection ──
    st.markdown("---")
    st.markdown("### 📋 Select Sheets to Process")

    # Categorize sheets
    formatting_sheets = [s for s in workbook_data.sheet_names if "format" in s.lower() or "frmt" in s.lower()]
    data_sheets = [s for s in workbook_data.sheet_names if s not in formatting_sheets]

    col_left, col_right = st.columns(2)
    with col_left:
        st.markdown("**Data/Report Sheets:**")
        selected_data = st.multiselect(
            "Select data sheets",
            data_sheets,
            default=data_sheets,
            label_visibility="collapsed"
        )
    with col_right:
        st.markdown("**Formatting Sheets:**")
        selected_fmt = st.multiselect(
            "Select formatting sheets",
            formatting_sheets,
            default=formatting_sheets,
            label_visibility="collapsed"
        )

    selected_sheets = selected_data + selected_fmt

    # ── Process Button ──
    st.markdown("---")
    if st.button("🚀 Generate Specifications", type="primary", use_container_width=True):
        if not selected_sheets:
            st.warning("Please select at least one sheet.")
        else:
            # ── Step 2: Run Agents ──
            orchestrator = Orchestrator()

            progress = st.progress(0, text="Initializing agents...")
            agent_status = st.empty()

            # Filter workbook to selected sheets only
            filtered_sheets = {k: v for k, v in workbook_data.sheets.items() if k in selected_sheets}
            original_sheets = workbook_data.sheets
            workbook_data.sheets = filtered_sheets

            with st.spinner("🤖 Running agents..."):
                all_specs = orchestrator.process_workbook(workbook_data)

            workbook_data.sheets = original_sheets  # Restore
            progress.progress(50, text="Agents complete. Generating documents...")

            # ── Step 3: Generate Documents ──
            output_dir = tempfile.mkdtemp()
            generated = generate_all_specs(all_specs, output_dir)

            progress.progress(100, text="Done!")

            # ── Results ──
            st.markdown("---")
            st.markdown("### ✅ Generated Specifications")

            success_count = sum(1 for v in generated.values() if not str(v).startswith("ERROR"))
            st.success(f"Successfully generated {success_count} / {len(generated)} specifications")

            # ── Download buttons ──
            for sheet_name, filepath in generated.items():
                if str(filepath).startswith("ERROR"):
                    st.error(f"❌ {sheet_name}: {filepath}")
                else:
                    with open(filepath, "rb") as f:
                        doc_bytes = f.read()
                    safe_name = sheet_name.replace(" ", "_").replace("%", "Pct")
                    st.download_button(
                        label=f"📄 Download: {sheet_name}",
                        data=doc_bytes,
                        file_name=f"Spec_{safe_name}.docx",
                        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        key=f"dl_{safe_name}",
                    )

            # ── Download All as ZIP ──
            if success_count > 1:
                st.markdown("---")
                zip_path = os.path.join(output_dir, "All_Specifications.zip")
                with zipfile.ZipFile(zip_path, "w") as zf:
                    for sheet_name, filepath in generated.items():
                        if not str(filepath).startswith("ERROR"):
                            safe_name = sheet_name.replace(" ", "_").replace("%", "Pct")
                            zf.write(filepath, f"Spec_{safe_name}.docx")

                with open(zip_path, "rb") as f:
                    st.download_button(
                        label="📦 Download All Specifications (ZIP)",
                        data=f.read(),
                        file_name="EPM_Report_Specifications.zip",
                        mime="application/zip",
                        type="primary",
                        use_container_width=True,
                    )

            # ── Preview Section ──
            st.markdown("---")
            st.markdown("### 🔎 Specification Preview")

            preview_sheet = st.selectbox("Select sheet to preview:", list(all_specs.keys()))
            if preview_sheet:
                spec = all_specs[preview_sheet]

                tab1, tab2, tab3, tab4, tab5 = st.tabs([
                    "📐 Dimensions", "📊 Measures", "⚡ EPM Functions",
                    "✅ Validations", "🔗 References"
                ])

                with tab1:
                    dims = spec.get("dimensions", {})
                    if dims:
                        for key, d in dims.items():
                            st.markdown(f'<div class="agent-card"><b>{d["name"]}</b> | Hierarchies: {", ".join(d.get("hierarchies", []))} | Display: {d.get("display_mode", "N/A")} | Members: {", ".join(d.get("members", [])[:5])}</div>', unsafe_allow_html=True)
                    else:
                        st.info("No dimensions found in this sheet.")

                with tab2:
                    meas = spec.get("measures", [])
                    if meas:
                        for m in meas[:15]:
                            desc = m.get("description", m.get("formula", ""))
                            st.markdown(f'<div class="agent-card"><b>{m["name"]}</b> ({m["type"]})<br/>{str(desc)[:150]}</div>', unsafe_allow_html=True)
                    else:
                        st.info("No measures found in this sheet.")

                with tab3:
                    funcs = spec.get("epm_functions", {})
                    if funcs:
                        for key, ef in funcs.items():
                            st.markdown(f'<div class="agent-card"><b>{ef["function"]}</b> — {ef["description"]}<br/>Used {ef["usage_count"]} times</div>', unsafe_allow_html=True)
                    else:
                        st.info("No EPM functions found in this sheet.")

                with tab4:
                    vals = spec.get("validations", [])
                    if vals:
                        for v in vals:
                            color = "#c0392b" if v.get("rule_type") == "Balance Validation" else "#2E5090"
                            st.markdown(f'<div class="agent-card" style="border-left-color:{color}"><b>{v["id"]}</b> — {v["description"]}<br/>Type: {v.get("rule_type", "N/A")}</div>', unsafe_allow_html=True)
                    else:
                        st.info("No validations found in this sheet.")

                with tab5:
                    refs = spec.get("cross_sheet_references", [])
                    if refs:
                        for r in refs[:10]:
                            st.markdown(f'<div class="agent-card">{r["from_cell"]} → <b>{r["target_sheet"]}</b><br/>{str(r["formula"])[:150]}</div>', unsafe_allow_html=True)
                    else:
                        st.info("No cross-sheet references found.")

    # Cleanup
    try:
        os.unlink(tmp_path)
    except:
        pass

else:
    # ── Landing Page ──
    st.markdown("---")
    st.markdown("### 🎯 What This Tool Does")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        **Input:**
        - SAP BPC/EPM Excel workbooks (.xlsx)
        - Supports EPM Add-in formulas
        - Reads formatting sheets
        """)
    with col2:
        st.markdown("""
        **Extracts:**
        - BPC Dimensions & hierarchies
        - Measures, KPIs, validations
        - EPM functions & local members
        - Custom formulas & business rules
        """)
    with col3:
        st.markdown("""
        **Output:**
        - One Word (.docx) spec per sheet
        - SAC migration recommendations
        - Complete formula documentation
        """)
