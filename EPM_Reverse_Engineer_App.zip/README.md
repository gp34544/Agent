# SAP EPM → SAC Report Specification Generator

## Setup
```bash
pip install streamlit openpyxl
npm install -g docx
```

## Run
```bash
streamlit run app.py
```

## Architecture
- **app.py** - Streamlit frontend (upload → select sheets → download specs)
- **agents.py** - 6 specialist agents + orchestrator
- **excel_parser.py** - Reads EPM workbooks via openpyxl
- **doc_generator.py** - Creates Word documents via docx-js (Node.js)

## Agents
1. DimensionAgent - Extracts BPC dimensions, hierarchies, display modes
2. MeasureAgent - Identifies KPIs, measures, calculated members
3. FormulaAgent - Catalogs EPM functions, local members, Excel formulas
4. FormattingAgent - Reads EPM formatting rules and layout
5. ValidationAgent - Extracts business rules and data quality checks
6. SpecificationAgent - Assembles everything into Word docs
