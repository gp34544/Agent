"""
doc_generator.py
Generates Word (.docx) specification documents from agent output.

This version accepts EITHER:
  - a Python dict 'spec' with fixed keys, OR
  - a path to a JSON file containing those keys.

Node.js 'docx' npm package is required.
  Install once in your project dir:  npm install docx
"""

import json
import subprocess
import os
import sys
import tempfile
from typing import Dict, Any, Union

# ── Resolve project directory (where node_modules lives) ──
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Fixed keys expected in the JSON file ──
FIXED_KEYS = {
    "report headers",
    "dimensions",
    "Calculations/KPIs",
    "Model",
    "Environment",
    "EPM formulas",
    "EPM Local Members",
    "Normal Excel formulas",
    "Report Summary",
}

def _load_spec(spec_or_json_path: Union[Dict[str, Any], str]) -> Dict[str, Any]:
    """
    Accepts either a Python dict or a JSON file path.
    Returns the loaded dict and validates fixed keys exist (creates harmless defaults if missing).
    """
    if isinstance(spec_or_json_path, (str, os.PathLike)):
        json_path = os.path.abspath(spec_or_json_path)
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"JSON file not found: {json_path}")
        with open(json_path, "r", encoding="utf-8") as f:
            spec = json.load(f)
    elif isinstance(spec_or_json_path, dict):
        spec = spec_or_json_path
    else:
        raise TypeError("spec_or_json_path must be a dict or a path to a JSON file")

    # Ensure all fixed keys exist with defaults
    defaults = {
        "report headers": {},
        # these used to be dicts with comma-separated values, but older
        # consumers may still send that form.  the new canonical format is a
        # list of dicts (one entry per row in the eventual table).
        "dimensions": [],
        "Calculations/KPIs": [],
        "Model": "",
        "Environment": "",
        "EPM formulas": [],
        "EPM Local Members": [],
        "Normal Excel formulas": [],
        "Report Summary": "",
    }
    for k, v in defaults.items():
        spec.setdefault(k, v)

    # Basic validation of types for robustness
    if not isinstance(spec["report headers"], dict):
        spec["report headers"] = {}
    # dimensions and calculations may be either a dict (old-style) or a list
    # of dicts (new-style).  keep the raw value here and normalise later.
    if not isinstance(spec["dimensions"], (dict, list)):
        spec["dimensions"] = []
    if not isinstance(spec["Calculations/KPIs"], (dict, list)):
        spec["Calculations/KPIs"] = []
    if not isinstance(spec["EPM formulas"], list):
        spec["EPM formulas"] = []
    if not isinstance(spec["EPM Local Members"], list):
        spec["EPM Local Members"] = []
    if not isinstance(spec["Normal Excel formulas"], list):
        spec["Normal Excel formulas"] = []

    # Normalize common typos in the keys used by the tables.  The JSON
    # produced by various agents sometimes spells "Actual value in excel"
    # incorrectly as "Actula value in excel", so handle that gracefully.
    def _fix_actual_key(item):
        if isinstance(item, dict) and "Actula value in excel" in item:
            item["Actual value in excel"] = item.pop("Actula value in excel")

    for list_key in ("EPM formulas", "EPM Local Members", "Normal Excel formulas"):
        for entry in spec.get(list_key, []):
            _fix_actual_key(entry)

    # Another frequent typo is the report summary key itself:
    if "Report Summery" in spec and "Report Summary" not in spec:
        spec["Report Summary"] = spec.pop("Report Summery")

    return spec
import tempfile
import uuid

def generate_docx(spec_or_json_path: Union[Dict[str, Any], str], output_path: str) -> str:
    """
    Generate a .docx specification document from either:
      - dict with fixed keys, or
      - JSON file path with fixed keys.

    Returns absolute output path on success.
    """
    # Normalize/validate spec
    spec = _load_spec(spec_or_json_path)

    # Helper to convert old-style dicts (possibly with comma-separated values)
    # into a list of dictionaries.  New-style input should already be a
    # list-of-dicts so this will be a no-op in that case.
    def _ensure_list_of_dicts(val):
        if isinstance(val, dict):
            # convert each key/value pair to its own dict; this matches the
            # format produced by older versions of the tool.
            return [{k: v} for k, v in val.items()]
        if isinstance(val, list):
            # ensure all members are dicts; non-dicts are wrapped under a
            # generic 'Value' key so they still appear in the table.
            return [item if isinstance(item, dict) else {"Value": item} for item in val]
        return []

    spec["dimensions"] = _ensure_list_of_dicts(spec.get("dimensions", []))
    spec["Calculations/KPIs"] = _ensure_list_of_dicts(spec.get("Calculations/KPIs", []))

    # Use OS-appropriate temp directory
    tmp_dir = tempfile.gettempdir()
    json_path = os.path.join(tmp_dir, "spec_data.json")
    # js_path = os.path.join(tmp_dir, "generate_doc.js")
    js_path = os.path.join(PROJECT_DIR, f"generate_doc_{uuid.uuid4().hex}.js")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    # Write spec to temp JSON (this is what Node script will read)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, default=str)

    # Build and write the JS script (use forward slashes for Node)
    json_path_js = json_path.replace("\\", "/")
    output_path_js = os.path.abspath(output_path).replace("\\", "/")

    js_script = _build_js_script_for_fixed_schema(json_path_js, output_path_js)
    with open(js_path, "w", encoding="utf-8") as f:
        f.write(js_script)

    node_mod_path = os.path.join(PROJECT_DIR, "node_modules", "docx")
    if not os.path.exists(node_mod_path):
        raise RuntimeError(
            f"Node.js 'docx' not installed in project dir: {node_mod_path!r}\n"
            f"Fix: cd {PROJECT_DIR} && npm install docx"
        )

    # Run Node.js from the project directory (so it finds node_modules/docx)
    try:
        result = subprocess.run(
            ["node", js_path],
            capture_output=True, text=True, timeout=60,
            cwd=PROJECT_DIR,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "Node.js not found! Install from https://nodejs.org/\n"
            "Then run: npm install docx (in project directory)"
        )

    if result.returncode != 0:
        error_msg = (result.stderr or "Unknown error")[:1000]
        if "Cannot find module" in error_msg and "docx" in error_msg:
            raise RuntimeError(
                f"Node.js 'docx' module not found!\n"
                f"Fix: cd {PROJECT_DIR} && npm install docx\n"
                f"Original error: {error_msg}"
            )
        raise RuntimeError(f"docx generation failed:\n{error_msg}")

    return os.path.abspath(output_path)


def _build_js_script_for_fixed_schema(json_path: str, output_path: str) -> str:
    """
    Generates a Node.js script that reads the new JSON schema and writes a .docx.
    Sections:
      - Report Headers (as table)
      - Dimensions (as table with sub-keys as columns)
      - Calculations/KPIs (as table with sub-keys as columns)
      - Model
      - Environment
      - EPM Formulas (list table)
      - EPM Local Members (list table)
      - Normal Excel Formulas (list table)
      - Report Summary
    """
    return '''
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  Header, Footer, PageNumber
} = require("docx");

const spec = JSON.parse(fs.readFileSync("''' + json_path + '''", "utf-8"));

// ── Helpers ──
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headerBg = { fill: "2E5090", type: ShadingType.CLEAR };
const altRowBg = { fill: "F2F6FC", type: ShadingType.CLEAR };
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };

function clean(v) {
  if (v == null) return "";
  return String(v).replace(/&amp;/g, "&");
}

function headerCell(text, width) {
  return new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: headerBg, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text: clean(text), bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })]
  });
}

function dataCell(text, width, shading) {
  const opts = { borders, width: { size: width, type: WidthType.DXA }, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text: clean(text), font: "Arial", size: 18 })] })] };
  if (shading) opts.shading = shading;
  return new TableCell(opts);
}

function sectionHeading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 300, after: 150 },
    children: [new TextRun({ text, bold: true, font: "Arial", size: 28, color: "2E5090" })]
  });
}

function bodyText(text) {
  return new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({ text: clean(text), font: "Arial", size: 20 })]
  });
}

function emptyLine() {
  return new Paragraph({ spacing: { after: 80 }, children: [] });
}

// ── Build Document ──
const children = [];

// Title: Use Heading from report headers or default
const reportHeaders = spec["report headers"] || {};
const titleText = clean(reportHeaders.Heading || "Report Specification");
children.push(new Paragraph({
  heading: HeadingLevel.HEADING_1, spacing: { after: 200 },
  children: [new TextRun({ text: titleText, bold: true, font: "Arial", size: 36, color: "2E5090" })]
}));

// 1. Report Headers Table (key-value pairs)
children.push(sectionHeading("1. Report Specification"));
if (Object.keys(reportHeaders).length > 0) {
  const rows = [new TableRow({ children: [headerCell("Field", 3000), headerCell("Value", 6360)] })];
  let isAlt = false;
  for (const [key, value] of Object.entries(reportHeaders)) {
    const bg = isAlt ? altRowBg : undefined;
    rows.push(new TableRow({
      children: [dataCell(key, 3000, bg), dataCell(clean(value), 6360, bg)]
    }));
    isAlt = !isAlt;
  }
  
  // Add Model as a row
  let bg = isAlt ? altRowBg : undefined;
  rows.push(new TableRow({
    children: [dataCell("Model", 3000, bg), dataCell(clean(spec.Model || ""), 6360, bg)]
  }));
  isAlt = !isAlt;
  
  // Add Environment as a row
  bg = isAlt ? altRowBg : undefined;
  rows.push(new TableRow({
    children: [dataCell("Environment", 3000, bg), dataCell(clean(spec.Environment || ""), 6360, bg)]
  }));
  
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: [3000, 6360], rows }));
} else {
  children.push(bodyText("No report headers supplied."));
}
children.push(emptyLine());

// 2. Dimensions Table (accepts either old-style object or new-style array-of-dicts)
children.push(sectionHeading("2. Dimensions"));
let dimensions = spec.dimensions || [];

// if user provided a plain object we convert it into a list of single-entry
// dictionaries (maintains backwards compatibility).
if (!Array.isArray(dimensions) && typeof dimensions === "object") {
  dimensions = Object.entries(dimensions).map(([k, v]) => ({ [k]: v }));
}

if (Array.isArray(dimensions) && dimensions.length > 0) {
  // determine all possible column headers by unioning keys from every row
  const columnHeaders = Array.from(
    new Set(dimensions.flatMap(obj => Object.keys(obj)))
  );

  const colWidth = Math.floor(9360 / columnHeaders.length);
  const rows = [new TableRow({
    children: columnHeaders.map(header => headerCell(header, colWidth))
  })];

  dimensions.forEach((item, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    rows.push(new TableRow({
      children: columnHeaders.map(header => dataCell(clean(item[header] || ""), colWidth, bg))
    }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: Array(columnHeaders.length).fill(colWidth), rows }));
} else {
  children.push(bodyText("No dimensions supplied."));
}
children.push(emptyLine());

// 3. Calculations/KPIs Table (array-of-dicts or legacy object)
children.push(sectionHeading("3. Calculations / KPIs"));
let calculations = spec["Calculations/KPIs"] || [];
if (!Array.isArray(calculations) && typeof calculations === "object") {
  calculations = Object.entries(calculations).map(([k, v]) => ({ [k]: v }));
}

if (Array.isArray(calculations) && calculations.length > 0) {
  const columnHeaders = Array.from(
    new Set(calculations.flatMap(obj => Object.keys(obj)))
  );
  const colWidth = Math.floor(9360 / columnHeaders.length);
  const rows = [new TableRow({
    children: columnHeaders.map(header => headerCell(header, colWidth))
  })];

  calculations.forEach((item, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    rows.push(new TableRow({
      children: columnHeaders.map(header => dataCell(clean(item[header] || ""), colWidth, bg))
    }));
  });

  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: Array(columnHeaders.length).fill(colWidth), rows }));
} else {
  children.push(bodyText("No calculations/KPIs supplied."));
}
children.push(emptyLine());

// 4. EPM Formulas Table
children.push(sectionHeading("4. EPM Formulas"));
const epmFormulas = Array.isArray(spec["EPM formulas"]) ? spec["EPM formulas"] : [];
if (epmFormulas.length > 0) {
  const colWidths = [2000, 2000, 2000, 3360];
  const rows = [new TableRow({
    children: [
      headerCell("EPM Formula", colWidths[0]),
      headerCell("Position", colWidths[1]),
      headerCell("Actual Value", colWidths[2]),
      headerCell("Notes", colWidths[3])
    ]
  })];
  
  epmFormulas.forEach((item, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    rows.push(new TableRow({
      children: [
        dataCell(clean(item["EPM formula"] || ""), colWidths[0], bg),
        dataCell(clean(item["EPM Formula Position"] || ""), colWidths[1], bg),
        // accept either correct spelling or common typo
        dataCell(clean(item["Actual value in excel"] || item["Actula value in excel"] || ""), colWidths[2], bg),
        dataCell("", colWidths[3], bg)
      ]
    }));
  });
  
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: colWidths, rows }));
} else {
  children.push(bodyText("No EPM formulas supplied."));
}
children.push(emptyLine());

// 7. EPM Local Members Table
children.push(sectionHeading("5. EPM Local Members"));
const epmLocalMembers = Array.isArray(spec["EPM Local Members"]) ? spec["EPM Local Members"] : [];
if (epmLocalMembers.length > 0) {
  const colWidths = [2500, 2000, 2000, 2860];
  const rows = [new TableRow({
    children: [
      headerCell("EPM Local Member", colWidths[0]),
      headerCell("Position", colWidths[1]),
      headerCell("Actual Value", colWidths[2]),
      headerCell("Notes", colWidths[3])
    ]
  })];
  
  epmLocalMembers.forEach((item, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    rows.push(new TableRow({
      children: [
        dataCell(clean(item["EPM Local Member"] || ""), colWidths[0], bg),
        dataCell(clean(item["EPM Local Member Position"] || ""), colWidths[1], bg),
        // accept either correct spelling or common typo
        dataCell(clean(item["Actual value in excel"] || item["Actula value in excel"] || ""), colWidths[2], bg),
        dataCell("", colWidths[3], bg)
      ]
    }));
  });
  
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: colWidths, rows }));
} else {
  children.push(bodyText("No EPM local members supplied."));
}
children.push(emptyLine());

// 8. Normal Excel Formulas Table
children.push(sectionHeading("6. Normal Excel Formulas"));
const excelFormulas = Array.isArray(spec["Normal Excel formulas"]) ? spec["Normal Excel formulas"] : [];
if (excelFormulas.length > 0) {
  const colWidths = [2500, 2000, 2000, 2860];
  const rows = [new TableRow({
    children: [
      headerCell("Excel Formula", colWidths[0]),
      headerCell("Position", colWidths[1]),
      headerCell("Actual Value", colWidths[2]),
      headerCell("Notes", colWidths[3])
    ]
  })];
  
  excelFormulas.forEach((item, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    rows.push(new TableRow({
      children: [
        dataCell(clean(item["Excel formula"] || ""), colWidths[0], bg),
        dataCell(clean(item["Excel Formula Position"] || ""), colWidths[1], bg),
        // accept either correct spelling or common typo
        dataCell(clean(item["Actual value in excel"] || item["Actula value in excel"] || ""), colWidths[2], bg),
        dataCell("", colWidths[3], bg)
      ]
    }));
  });
  
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: colWidths, rows }));
} else {
  children.push(bodyText("No Excel formulas supplied."));
}
children.push(emptyLine());

// 9. Report Summary
children.push(sectionHeading("7. Report Summary"));
children.push(bodyText(clean(spec["Report Summary"] || "Not provided.")));

// ── Build Doc ──
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 240, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 200, after: 150 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "SAP EPM Report Specification", italics: true, font: "Arial", size: 16, color: "888888" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", font: "Arial", size: 16 }),
            new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 16 }),
          ]
        })]
      })
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("''' + output_path + '''", buffer);
  console.log("OK");
}).catch(err => {
  console.error("Error:", err.message || err);
  process.exit(1);
});
'''


def generate_all_specs_from_json_folder(input_dir: str, output_dir: str):
    """
    Optional helper: iterate all *.json files in input_dir and generate a .docx for each,
    using the file name (without extension) as the output doc base name.
    """
    os.makedirs(output_dir, exist_ok=True)
    results = {}
    for name in os.listdir(input_dir):
        if not name.lower().endswith(".json"):
            continue
        json_path = os.path.join(input_dir, name)
        safe_base = os.path.splitext(name)[0].replace(" ", "_").replace("%", "Pct").replace("/", "_")
        out_path = os.path.join(output_dir, f"Spec_{safe_base}.docx")
        try:
            generate_docx(json_path, out_path)
            results[name] = out_path
            print(f"  ✅ {name}: {out_path}")
        except Exception as e:
            results[name] = f"ERROR: {e}"
            print(f"  ❌ {name}: {e}")
    return results
