
import json
from tkinter import ACTIVE
import pandas as pd
from langchain_core.prompts import PromptTemplate
import boto3
from langchain_community.chat_models import BedrockChat
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.messages import HumanMessage
from langchain_core.prompts import PromptTemplate
from langchain_aws import ChatBedrockConverse
import base64

# global.anthropic.claude-sonnet-4-6
# global.anthropic.claude-opus-4-6-v1
# us.anthropic.claude-sonnet-4-6
# global.anthropic.claude-sonnet-4-5-20250929-v1:0
# 'us.anthropic.claude-haiku-4-5-20251001-v1:0

client = boto3.client(service_name='bedrock-runtime',
region_name='us-east-1', 
aws_access_key_id='AKIAR762QMAE3GSH6DMR',
aws_secret_access_key='88qUhblo/m9jKpJaheEw7QJPAueyeADKVAGpkzyQ'
)

# client = boto3.client("bedrock", region_name="your-source-region") 
# response = client.list_inference_profiles() 
# print(response)

# image = "ss/ms_buyer_full.png"
image = "ss/ms_seller_full.png"

with open(image, "rb") as f:
    b64_image = base64.b64encode(f.read()).decode("utf-8")

messages = [
    {
        "role": "system",
        "content": [
            {"type": "text", "text": "You are a precise EPM extractor. Return clean JSON only."}
        ],
    },
    {
        "role": "user",
        "content": [
            # Optional instruction text (you can omit this block if you truly want 'only image')
            {"type": "text", "text": "Extract the dimensions , KPI from below SAP EPM reports."},
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",   # change to image/jpeg if JPG
                    "data": b64_image,
                },
            },
        ],
    },
]

def cross_region_llm():
    bedrock = boto3.client(service_name='bedrock-runtime',
    region_name='us-east-1', 
    aws_access_key_id='AKIAR762QMAE3GSH6DMR',
    aws_secret_access_key='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'
    )
    bedrock_model_id = 'global.anthropic.claude-opus-4-6-v1'


    llm = ChatBedrockConverse(model_id=bedrock_model_id,client=bedrock,temperature=0, max_tokens=None
    )
    return llm

llm = ChatBedrockConverse(
    model="global.anthropic.claude-opus-4-6-v1", 
    temperature=0,
    max_tokens=None,
    client=client,
)


res = llm.invoke(messages)
print(res.content)






























# messages = [
#     (
#         "system",
#         "You are a helpful assistant that shapes sentences into poetic form. Translate the user sentence.",
#     ),
#     ("human", "I love programming."),
# ]

# llm = ChatBedrockConverse(
#     model='global.anthropic.claude-opus-4-6-v1',
#     temperature=0,
#     max_tokens=None,
#     client=client,
# )

# print(llm.invoke(messages).content)


# global.anthropic.claude-sonnet-4-6
# global.anthropic.claude-opus-4-6-v1
# us.anthropic.claude-sonnet-4-6
# global.anthropic.claude-sonnet-4-5-20250929-v1:0
# 'us.anthropic.claude-haiku-4-5-20251001-v1:0