# SAP BPC/EPM Report Analyzer

## Project Overview

A Streamlit web application that extracts and documents SAP BPC/EPM Excel reports using Claude AI via AWS Bedrock. It analyzes Excel sheets cell-by-cell, combines that with a screenshot of the report, and generates structured Word documents (DOCX) capturing dimensions, KPIs, EPM formulas, and report specifications.

## Architecture

### File Map

| File | Role |
|---|---|
| `app3.py` | Main Streamlit UI — file upload, sheet selection, orchestrates processing |
| `cross_region_model.py` | AWS Bedrock LLM client setup using cross-region inference profiles |
| `text_processing_functions.py` | Excel parsing (openpyxl) — extracts cell values, EPM/Excel formulas per sheet |
| `word_doc.py` | DOCX generator (simple spec format) — renders JSON → Word via Node.js `docx` |
| `word_doc_final.py` | DOCX generator (full FSD format) — Functional Specification Document with 14 sections |

### Data Flow

```
Excel (.xlsx) + Screenshot (PNG/JPG)
        ↓
text_processing_functions.py
  extract_sheet_records_for_llm()   → list of {coord, value, epm_formula, excel_formula}
  to_row_text_all_fields()          → formatted text for LLM prompt
        ↓
app3.py: process_single_sheet()
  Builds prompt → calls Claude via AWS Bedrock (ChatBedrockConverse)
        ↓
LLM returns JSON spec
  extract_json_safely()             → parsed Python dict
  Saved as spec_<sheet>.json
        ↓
word_doc.py: generate_docx()
  Writes temp JSON + JS script → runs Node.js → outputs .docx
```

## Tech Stack

- **Python**: Streamlit, LangChain (langchain-aws, langchain-core, langchain-community), boto3, openpyxl, pandas, python-docx
- **LLM**: Claude via AWS Bedrock cross-region inference (`global.anthropic.claude-opus-4-6-v1`)
- **DOCX generation**: Node.js with `docx` npm package (spawned via `subprocess`)
- **Region**: `us-east-1`

## Key Modules

### `cross_region_model.py`
- Defines `cross_region_llm()` — returns a `ChatBedrockConverse` instance
- Uses cross-region inference profile IDs (prefix `global.` or `us.`):
  - `global.anthropic.claude-opus-4-6-v1`
  - `global.anthropic.claude-sonnet-4-6`
  - `us.anthropic.claude-haiku-4-5-20251001-v1:0`

### `text_processing_functions.py`
- `extract_sheet_records_for_llm(path, sheet_name)` — reads `.xlsx` with openpyxl (both `data_only=False` for formulas and `data_only=True` for evaluated values); skips blank cells
- `to_row_text_all_fields(records)` — formats records as `Row N: A1 value="..."; epm_formula="..."; excel_formula="..."`
- EPM formula detection: matches functions starting with `=EPM` or `=BPC`, plus a whitelist in `KNOWN_EPM_FUNCTIONS`

### `word_doc.py` (simple spec)
- Generates a 7-section DOCX: Report Headers, Dimensions, Calculations/KPIs, EPM Formulas, EPM Local Members, Normal Excel Formulas, Report Summary
- Handles typo `"Actula value in excel"` → normalizes to `"Actual value in excel"`
- Requires `node_modules/docx` in the project directory

### `word_doc_final.py` (full FSD)
- Generates a 14-section Functional Specification Document for BPC→SAC migration
- Sections include: Revision History, Purpose/Scope, BPC Dimensions, Account/Measure Details, Business Rules, Dimension Mapping, SAC Target Design, Gaps/Risks, Testing, Approvals, Appendix

## Setup Requirements

### Python dependencies
```
streamlit
pandas
openpyxl
python-docx
boto3
langchain-aws
langchain-core
langchain-community
```

### Node.js dependency (for DOCX generation)
```bash
npm install docx
```
Run this in the project directory (`/Users/ruchira/Downloads/EPM (1)/`). The `node_modules/docx` folder must be present or `generate_docx()` raises a `RuntimeError`.

### AWS credentials
- AWS Bedrock access required in `us-east-1`
- Currently credentials are configured in `cross_region_model.py`
- **Security**: Credentials should be moved to environment variables or AWS credential files

## Running the App

```bash
streamlit run app3.py
```

## LLM Output JSON Schema

The LLM is prompted to return JSON with these keys:

```json
{
  "report headers": { "Heading": "", "Report Objective": "", "User Action": "" },
  "dimensions": [{ "Dimensions": "", "Hierarchies": "", "Display": "", "Business Purpose": "", "Position of Dimension": "" }],
  "Calculations/KPIs": [{ "Name": "", "Description": "", "Formula": "" }],
  "Model": "",
  "Environment": "",
  "EPM formulas": [{ "EPM formula": "", "EPM Formula Position": "", "Actula value in excel": "" }],
  "EPM Local Members": [{ "EPM Local Member": "", "EPM Local Member Position": "", "Actula value in excel": "" }],
  "Normal Excel formulas": [{ "Excel formula": "", "Excel Formula Position": "", "Actula value in excel": "" }],
  "Report Summary": ""
}
```

Note: The key `"Actula value in excel"` (typo for "Actual") is intentional — the codebase normalizes it in both Python and JS.

## Important Notes

- `app3.py` imports `generate_docx` from `word_doc` (not `word_doc_final`) for sheet processing
- `word_doc_final.py` is imported at the top of `app3.py` (`from word_doc_final import generate_docx`) but overridden by the local import inside `process_single_sheet()`
- Each processed sheet produces: `spec_<sheet>.json` and `output/<sheet>.docx`
- Temp JS scripts (`generate_doc_<uuid>.js`) are written to the project directory and cleaned up after use
- `cross_region_model.py` has standalone test code (image load + direct invoke) that runs on import — it should be guarded or removed when used as a module
