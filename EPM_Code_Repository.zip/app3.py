# app.py
import streamlit as st
import pandas as pd
import base64
import json
import tempfile
import os
import io
import zipfile
from pathlib import Path
import re
from word_doc_final import generate_docx

from docx import Document
from langchain_core.messages import HumanMessage

# ✨ Your modules
from cross_region_model import cross_region_llm
from text_processing_functions import extract_sheet_records_for_llm, to_row_text_all_fields

# ─────────────────────────────────────────────────────────
# Init LLM
# ─────────────────────────────────────────────────────────
llm = cross_region_llm()

# ─────────────────────────────────────────────────────────
# Streamlit page config
# ─────────────────────────────────────────────────────────
st.set_page_config(page_title="Multi‑Sheet Excel + Screenshot Processor", page_icon="📄", layout="centered")


# ─────────────────────────────────────────────────────────
# Utilities
# ─────────────────────────────────────────────────────────
def save_uploaded_excel(uploaded_file) -> str:
    """
    Save uploaded Excel file to a real temporary path and return the file path.
    Uses getbuffer() to avoid consuming the stream position in Streamlit.
    """
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx")
    tmp.write(uploaded_file.getbuffer())
    tmp.flush()
    return tmp.name

def bytes_to_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("utf-8")

def sanitize_filename(name: str) -> str:
    # Remove characters not allowed on Windows/macOS/Linux filenames
    name = re.sub(r'[\\/*?:"<>|]', "_", name)
    name = name.strip()
    return name or "output"

def extract_json_safely(raw_text: str):
    """
    Try to parse LLM output into JSON:
      - Remove code fences if present
      - Extract substring between first '{' and last '}'
    """
    if not raw_text:
        return {"error": "Empty LLM output"}

    txt = raw_text.strip()

    # Drop Markdown fences ```json ... ```
    if txt.startswith("```"):
        # Find the first fence and last fence
        parts = re.split(r"```(?:json)?", txt, flags=re.IGNORECASE)
        # Heuristic: last chunk may contain the content
        txt = "".join(parts)

    # Extract JSON object by locating outer braces
    start = txt.find("{")
    end = txt.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = txt[start:end+1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    # Last attempt: direct json loads
    try:
        return json.loads(txt)
    except Exception:
        return {"error": "Failed to parse JSON", "raw_llm_output": raw_text}


def extract_json_from_llm(raw_text: str):
    """
    Extracts JSON block from LLM response and returns a Python dict.
    Handles cases like:
      ```json { ... } ```
      { ... }
      ===== Raw Model Output =====
      Mixed text + JSON
    """
    # 1. Remove code fences ```json ``` 
    cleaned = re.sub(r"```(json)?", "", raw_text)
    cleaned = cleaned.replace("```", "")

    # 2. Find the JSON object: everything between the first { and last }
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if not match:
        raise ValueError("No JSON object found in LLM response")

    json_text = match.group(0)

    # 3. Convert to Python dict
    try:
        return json.loads(json_text)
    except json.JSONDecodeError as e:
        print("JSON decode failed. Raw text:")
        print(json_text)
        raise e


# ─────────────────────────────────────────────────────────
# Core per‑sheet processing using your existing extractor
# ─────────────────────────────────────────────────────────
def process_single_sheet(sheet_name: str, tmp_excel_path: str, screenshot_b64: str, mime_type: str = "image/png", base_dir: Path = Path(".")) -> str:
    """
    Runs your full logic for ONE sheet + ONE screenshot and follows your desired flow:
      - parse LLM output to JSON
      - save JSON to base/spec_<sheet>.json
      - call generate_docx(json_path, out_path)
      - return path to generated DOCX

    base_dir: folder that contains spec.json and 'output/' folder (configurable from UI)
    """
    # 1) Extract records using your function (path + sheet_name)
    extract_records_row_wise = extract_sheet_records_for_llm(
        tmp_excel_path,
        sheet_name,
        skip_blanks=True
    )

    # 2) Convert to LLM-friendly row text (your function)
    cleaned_input_for_llm = to_row_text_all_fields(
        extract_records_row_wise,
        always_show_all_keys=True,
        sort_rows_and_cols=True
    )

    cleaned_sheet_data_row_wise = f"""CLEANED_SHEET_DATA:
{cleaned_input_for_llm}
END_CLEANED_SHEET_DATA
"""

    # 3) Build prompt targeting the FSD Option-A schema (matches word_doc_final.py)
    prompt = f”””
You are a meticulous analyst of SAP BPC/EPM Excel reports preparing a Functional Specification Document (FSD) for migration to SAP Analytics Cloud (SAC) Planning.

You will be given:
1) A screenshot of the report.
2) A structured list of rows from the worksheet (“CLEANED_SHEET_DATA”) where each row lists:
   - cell address, visible value, EPM formula (if any), Excel formula (if any)

RULES:
- Use ONLY evidence from the provided rows and screenshot. Do NOT hallucinate.
- Reference cell addresses when asserting facts.
- Prefer cell data over general BPC/EPM knowledge.
- For EPM formulas: check ROW BY ROW, include every formula starting with =EPM, =BPC, or =_xll.EPM / =_xll.FPMXLClient. Do not miss any.
- For EPM local members: any formula containing EPMLocalMember is a local member — list ALL of them.
- For account_measure_details (KPIs): extract every ACCOUNT dimension member from EPMOlapMemberO formulas on the ACCOUNT dimension (e.g. SME_SALES, SME_COGS, SMEPERCENT) AND every EPMLocalMember (e.g. “Entity Description”, “Trading Partner Description”, “Check”). For each entry identify whether it is Input, Calculated, or Reported.
- For dimension_usage: identify every BPC dimension used (ACCOUNT, ENTITY, TIME, CATEGORY, TPARTNER, DATASRC, BFLOW, CURRENCY etc.) and whether it appears in rows, columns, or page axis.
- For member_selections: for every EPMOlapMemberO or EPMContextMember formula, record the dimension, member ID, hierarchy, the exact formula, and the cell value.
- For excel_formulas: include ALL regular Excel formulas (=IF, =RIGHT, =F25&..., etc.) row by row.
- For dimension mapping: map each BPC dimension to a suggested SAC dimension type.
- Give only JSON output, nothing else.

Below is the content of the excel file:

{cleaned_sheet_data_row_wise}

Required JSON format (return ALL keys, use empty string “” or [] if not found):
{{
  “basic report info”: {{
    “Document Title”: “FSD - <report heading>”,
    “Project Name”: “BPC EPM to SAC Migration”,
    “Report / Template Name”: “<report name from heading cell>”,
    “SAC Target Model”: “”,
    “Document Version”: “1.0”,
    “Status”: “Draft”,
    “Prepared By”: “”,
    “Reviewed By”: “”,
    “Approved By”: “”,
    “Date”: “”
  }},
  “revision history”: [
    {{“Version”: “1.0”, “Date”: “”, “Author”: “”, “Change Description”: “Initial Draft”, “Reviewed By”: “”}}
  ],
  “purpose”: “This FSD defines the requirements and design specifications for migrating the BPC EPM report to SAC Planning.”,
  “scope”: “Source BPC EPM report analysis, dimension/measure mapping, SAC model and story design, testing and acceptance criteria.”,
  “out_of_scope”: “Integration with non-SAP systems, historical data migration.”,
  “report identification”: {{
    “BPC Application / Environment”: “<environment from EPMModelCubeID or context member>”,
    “Report / Template Name”: “<report name>”,
    “Report Type”: “Input Template”,
    “BPC Model / Cube”: “<model name from EPMModelCubeID>”,
    “Primary Business Process”: “<infer from report heading>”,
    “Frequency of Use”: “Manual”,
    “Number of Active Users”: “Manual”,
    “Business Owner”: “”
  }},
  “report_description”: “<report objective text from the sheet>”,
  “dimension_usage”: [
    {{“BPC Dimension”: “”, “Dimension Type”: “”, “Used in Rows Axis”: “Yes/No”, “Used in Cols Axis”: “Yes/No”, “Used in Page Axis”: “Yes/No”, “Member Filter”: “”}}
  ],
  “member_selections”: [
    {{“Dimension”: “”, “Members / Range”: “”, “Hierarchy Used”: “”, “BPC Formula / MDX”: “<exact EPMOlapMemberO or EPMContextMember formula>”, “Cell Value”: “”}}
  ],
  “account_measure_details”: [
    {{“Account ID”: “”, “Account Description”: “”, “Account Type”: “”, “Input / Calc / Reported”: “”, “Local Member / Excel Formula”: “”}}
  ],
  “epm_formulas”: [
    {{“EPM Formula”: “<exact formula>”, “Cell/Range Applied”: “<cell coord>”, “SAC Equivalent”: “”}}
  ],
  “excel_formulas”: [
    {{“Cell”: “<coord>”, “Type”: “Conditional Logic / Lookup / Text”, “Formula”: “<exact formula>”, “Explanation”: “”}}
  ],
  “dimension mapping”: [
    {{“BPC Dimension”: “”, “Hierarchy”: “”, “SAC Dimension”: “”, “SAC Type”: “”, “SAC Mapping Notes”: “”, “Gap / Action”: “”}}
  ],
  “sac_target_model”: {{
    “SAC Tenant / System”: “”,
    “SAC Model Name”: “”,
    “Model Type”: “Planning Model”,
    “Planning Area”: “”,
    “Currency Setting”: “”,
    “Fiscal Year Variant”: “”,
    “SAC Story Name”: “”,
    “Story Type”: “Planning Story”
  }},
  “sac_story_design”: [
    {{“Page #”: “1”, “Page Name”: “”, “Purpose / Description”: “”, “Widgets / Components”: “”, “BPC Tab Equivalent”: “”}}
  ],
  “data_actions”: [
    {{“Data Action Name”: “”, “Logic Description”: “”, “Trigger”: “”, “BPC Equivalent”: “”}}
  ],
  “input_form_design”: [
    {{“Input Field / Measure”: “”, “Data Type”: “”, “Editable (Y/N)”: “”, “Validation Rule”: “”, “Notes”: “”}}
  ],
  “gaps_risks”: [
    {{“Gap / Risk Description”: “”, “Category”: “”, “Priority”: “”, “Mitigation / Resolution”: “”}}
  ],
  “test_scenarios”: [
    {{“TC #”: “TC-01”, “Test Scenario”: “Data retrieval”, “Expected Result”: “Values match BPC report”, “Actual Result”: “”, “Status”: “”, “Tester”: “”}},
    {{“TC #”: “TC-02”, “Test Scenario”: “Calculated measures”, “Expected Result”: “Formula results match BPC”, “Actual Result”: “”, “Status”: “”, “Tester”: “”}}
  ],
  “acceptance_criteria”: “All test cases pass with no critical defects. Output values in SAC match BPC report within agreed tolerance. Business owner sign-off obtained.”,
  “approvals”: [
    {{“Name”: “”, “Role / Title”: “Business Owner”, “Department”: “”, “Date”: “”, “Signature”: “”}},
    {{“Name”: “”, “Role / Title”: “Functional Architect”, “Department”: “”, “Date”: “”, “Signature”: “”}}
  ],
  “glossary”: [
    {{“Term”: “BPC”, “Definition”: “SAP Business Planning & Consolidation”}},
    {{“Term”: “EPM”, “Definition”: “Enterprise Performance Management”}},
    {{“Term”: “SAC”, “Definition”: “SAP Analytics Cloud”}},
    {{“Term”: “FSD”, “Definition”: “Functional Specification Document”}}
  ],
  “reference_documents”: [
    {{“Document Name”: “BPC EPM Report Workbook”, “Author / Owner”: “”, “Version”: “”, “Location”: “”}}
  ],
  “open_issues”: []
}}
“””

    # 4) Prepare LLM content (text + image b64)
    content = [
        {"type": "text", "text": prompt},
        {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": mime_type,
                "data": screenshot_b64
            }
        }
    ]

    # 5) Call the model
    response = llm.invoke([HumanMessage(content=content)])
    raw_text = response.content

    # 6) Robust JSON parsing
    parsed_json = extract_json_safely(raw_text)
    # parsed_json = extract_json_from_llm(raw_text)
    # from normalize_json import normalize_llm_json

    # raw = parsed_json
    # parsed_json = normalize_llm_json(raw)

    # 7) Save parsed JSON to base/spec_<sheet>.json
    safe_sheet = sanitize_filename(sheet_name)
    base_dir.mkdir(parents=True, exist_ok=True)
    (base_dir / "output").mkdir(parents=True, exist_ok=True)

    json_path = base_dir / f"spec_{safe_sheet}.json"
    with open(json_path, "w", encoding="utf-8") as jf:
        json.dump(parsed_json, jf, indent=2, ensure_ascii=False)

    # 8) Call your generate_docx(json_path, out_path)
    #    If your function returns the saved path, use it; otherwise use out_path directly.
    out_path = base_dir / "output" / f"{safe_sheet}.docx"

    from word_doc_final import generate_docx
    

    try:
        saved_path = generate_docx(str(json_path), str(out_path))
        final_docx_path = saved_path if saved_path else str(out_path)
    except Exception as e:
        # As a fallback, write a simple docx with the JSON so the user gets something
        doc = Document()
        doc.add_heading(f"Sheet: {sheet_name}", level=1)
        doc.add_paragraph("⚠️ generate_docx() failed. Fallback content below.\n")
        doc.add_paragraph(json.dumps(parsed_json, indent=2))
        doc.save(str(out_path))
        final_docx_path = str(out_path)
        # Also surface the error in the UI caller

    return final_docx_path

# ─────────────────────────────────────────────────────────
# Streamlit UI
# ─────────────────────────────────────────────────────────
st.title("📄 Multi‑Sheet Excel Processor (BPC/EPM)")

st.markdown(
    "Upload an Excel file, select sheets, upload a screenshot per sheet, and generate **one Word file per sheet**."
)

# Maintain screenshots across reruns
if "screens" not in st.session_state:
    st.session_state["screens"] = {}  # {sheet: {"bytes": b"...", "mime": ..., "name": ...}}

# 1) Excel upload
excel_file = st.file_uploader("Upload Excel File", type=["xlsx"], key="excel_upload")

if excel_file:
    # Save uploaded Excel to temp file path
    tmp_excel_path = save_uploaded_excel(excel_file)

    # Load sheet names
    try:
        xls = pd.ExcelFile(tmp_excel_path)
        sheet_names = xls.sheet_names
    except Exception as e:
        st.error(f"Failed to read Excel: {e}")
        st.stop()

    # ---- OUTPUT & SPEC SETTINGS (UPDATED FOR DEPLOYMENT) ----
    st.subheader("Output & Spec Settings")

    # Create safe temp directory as default base directory
    default_base = tempfile.mkdtemp(prefix="bpc_epm_output_")

    base_dir_str = st.text_input(
        "Base folder (for SPEC JSONs + generated DOCX files):",
        value=default_base
    )

    base_dir = Path(base_dir_str)

    # Ensure directories exist
    (base_dir / "output").mkdir(parents=True, exist_ok=True)
    # -----------------------------------------------------------

    # 2) Select sheets
    selected_sheets = st.multiselect(
        "Select Sheets to Process",
        sheet_names,
        default=sheet_names
    )

    # 3) Upload screenshots
    if selected_sheets:
        st.subheader("Upload Screenshot for Each Selected Sheet")

        for sheet in selected_sheets:
            col1, col2 = st.columns([0.7, 0.3])

            with col1:
                up = st.file_uploader(
                    f"Screenshot for '{sheet}'",
                    type=["png", "jpg", "jpeg"],
                    key=f"ss_{sheet}"
                )

            with col2:
                if up is not None:
                    st.session_state["screens"][sheet] = {
                        "bytes": up.getvalue(),
                        "mime": up.type or "image/png",
                        "name": up.name
                    }

                if sheet in st.session_state["screens"]:
                    st.caption(f"Attached: {st.session_state['screens'][sheet]['name']}")
                else:
                    st.caption("No screenshot yet")

    # 4) Process button
    if st.button("🚀 Process All Selected Sheets"):
        missing = [s for s in selected_sheets if s not in st.session_state["screens"]]
        if missing:
            st.error(f"Please upload screenshots for: {', '.join(missing)}")
            st.stop()

        output_files = []
        total = len(selected_sheets)
        progress = st.progress(0, text="Starting...")

        for idx, sheet in enumerate(selected_sheets, start=1):
            scr = st.session_state["screens"][sheet]
            ss_b64 = bytes_to_base64(scr["bytes"])
            mime = scr["mime"] if scr["mime"] in ("image/png", "image/jpeg") else "image/png"

            try:
                out_path = process_single_sheet(
                    sheet,
                    tmp_excel_path,
                    ss_b64,
                    mime,
                    base_dir=base_dir   # ⭐ important change
                )
                output_files.append(out_path)
                progress.progress(idx / total, text=f"Processed {idx}/{total}: {sheet}")
            except Exception as e:
                st.error(f"Error processing '{sheet}': {e}")

        st.success("All selected sheets processed!")

        # Download buttons
        for file_path in output_files:
            try:
                with open(file_path, "rb") as f:
                    st.download_button(
                        label=f"⬇ Download {os.path.basename(file_path)}",
                        data=f.read(),
                        file_name=os.path.basename(file_path)
                    )
            except:
                st.warning(f"Could not read {file_path}")

        # ZIP download
        if output_files:
            zip_buf = io.BytesIO()
            with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in output_files:
                    if os.path.exists(p):
                        zf.write(p, arcname=os.path.basename(p))

            st.download_button(
                "📦 Download All as ZIP",
                data=zip_buf.getvalue(),
                file_name="outputs.zip",
                mime="application/zip"
            )

else:
    st.info("Please upload an Excel (.xlsx) to begin.")