import re
import json
from typing import List, Dict, Optional
import openpyxl
from openpyxl.utils import get_column_letter
import re
import json
from collections import defaultdict
from typing import List, Dict, Tuple, Optional

import re
import json
from collections import defaultdict
from typing import List, Dict, Tuple



KNOWN_EPM_FUNCTIONS = {
    "EPMRETRIEVEDATA",
    "EPMMEMBERPROPERTY",
    "EPMOLAPMEMBER",
    "EPMCONTEXTMEMBER",
    "EPMDIMENSIONOVERRIDE",
    "EPMCOPYRANGEPASTE",
    "EPMEXECUTEAPI",
    "EPMINSERTROW",
    "EPMINSERTCOLUMN",
    # Add/trim based on your tenant’s usage; keep uppercase
}

EPM_FUNC_PATTERN = re.compile(r"^=(EPM|BPC)[A-Z0-9_\.]*\s*\(", re.IGNORECASE)


def _normalize_blank(v) -> Optional[str]:
    """Convert empty-like values to None, else return stringified value."""
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip()
        return s if s != "" else None
    return str(v)


def _extract_formula(cell) -> Optional[str]:
    """Return formula string with leading '=' if present, else None."""
    val = cell.value
    if isinstance(val, str) and val.startswith("="):
        return val
    # openpyxl puts formulas in cell.value when data_only=False; below are fallbacks
    if getattr(cell, "data_type", None) == "f":
        # Usually cell.value already has the formula. If not, try attributes.
        f = getattr(cell, "value", None)
        if isinstance(f, str) and f.startswith("="):
            return f
        f2 = getattr(cell, "formula", None)
        if f2:
            return f2 if isinstance(f2, str) and f2.startswith("=") else "=" + str(f2)
        f3 = getattr(cell, "_formula", None)
        if f3:
            return "=" + str(f3)
    return None


def _is_epm_formula(formula: str) -> bool:
    """Heuristic: classify EPM formulas."""
    if not formula or not isinstance(formula, str) or not formula.startswith("="):
        return False
    f_up = formula.upper()
    # Direct match like =EPMRetrieveData( ... ), =BPC..., etc.
    if EPM_FUNC_PATTERN.match(formula):
        return True
    # Whitelist known EPM functions
    for fname in KNOWN_EPM_FUNCTIONS:
        if f"={fname}(" in f_up:
            return True
    # Fallback: if 'EPM' appears anywhere after '='
    if "EPM" in f_up:
        return True
    return False


def extract_sheet_records_for_llm(
    path: str,
    sheet_name: str,
    skip_blanks: bool = True,
) -> List[Dict[str, str]]:
    """
    Returns list of dicts like:
    {
      "column_and_row_position": "H14",
      "actual_value": "missing buyer %",
      "epm_formula": "",
      "excel_formula": ""
    }

    Rules:
      - Include a cell if it has either a non-blank value OR a formula.
      - 'actual_value' is from a data_only=True read (evaluated value).
      - Classify formulas into 'epm_formula' vs 'excel_formula'.
    """
    # Load for formulas
    wb = openpyxl.load_workbook(path, data_only=False)
    ws = wb[sheet_name]

    # Load for evaluated values
    wb_vals = openpyxl.load_workbook(path, data_only=True)
    ws_vals = wb_vals[sheet_name]

    max_row = ws.max_row
    max_col = ws.max_column

    records: List[Dict[str, str]] = []

    for r in range(1, max_row + 1):
        for c in range(1, max_col + 1):
            cell = ws.cell(row=r, column=c)
            coord = f"{get_column_letter(c)}{r}"

            # Extract formula (if any)
            formula = _extract_formula(cell)

            # Evaluate actual value
            evaluated = _normalize_blank(ws_vals.cell(row=r, column=c).value)
            literal_non_formula = None
            if formula is None:
                literal_non_formula = _normalize_blank(cell.value)

            # Decide if we include this cell
            has_anything = (evaluated is not None) or (formula is not None) or (literal_non_formula is not None)
            if not has_anything and skip_blanks:
                continue

            # Classify formulas
            epm_formula = ""
            excel_formula = ""
            if formula:
                if _is_epm_formula(formula):
                    epm_formula = formula
                else:
                    excel_formula = formula

            # Choose actual_value:
            # - Prefer evaluated value (more LLM-friendly).
            # - If None, fall back to literal value (for labels).
            actual_value = evaluated if evaluated is not None else literal_non_formula

            # Build record (use keys that match your ask)
            rec = {
                "column_and_row_position": coord,
                "actual_value": actual_value if actual_value is not None else "",
                "epm_formula": epm_formula,
                "excel_formula": excel_formula,
            }
            records.append(rec)

    return records



# records = extract_sheet_records_for_llm("files/Sample Report BPC EPM.xlsx", "Missing Seller %", skip_blanks=True)
# print(records)


# for all sheets 

def extract_all_sheets_to_json(path: str, output_json: str):
    wb = openpyxl.load_workbook(path, data_only=False)
    output = {}

    for sheet in wb.sheetnames:
        print(f"Processing sheet: {sheet}")
        output[sheet] = extract_sheet_records_for_llm(path, sheet)

    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"\nJSON saved → {output_json}")



# not needed
def save_sheet_records_json(
    path: str,
    sheet_name: str,
    out_json_path: Optional[str] = None
) -> str:
    """
    Extract and save LLM-friendly records for a given sheet as JSON.
    Returns the output file path.
    """
    if out_json_path is None:
        safe_sheet = "".join(ch if ch.isalnum() or ch in ("_", "-") else "_" for ch in sheet_name)
        out_json_path = f"epm_cells_{safe_sheet}.json"

    records = extract_sheet_records_for_llm(path, sheet_name, skip_blanks=True)
    with open(out_json_path, "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)
    return out_json_path





def _col_row_from_coord(coord: str) -> Tuple[str, int]:
    """Split 'G25' -> ('G', 25)."""
    m = re.match(r"^([A-Za-z]+)(\d+)$", coord)
    if not m:
        # Fallback: unknown format; keep as is
        return coord.upper(), 0
    return m.group(1).upper(), int(m.group(2))


def _one_line(s) -> str:
    """Ensure single-line, safe JSON quoting for text fields."""
    if s is None:
        return ""
    if isinstance(s, (int, float)):
        return str(s)
    # To preserve all text exactly but safely, JSON-quote strings
    t = str(s).replace("\r", " ").replace("\n", " ")
    return t


def to_row_text_all_fields(
    records: List[Dict[str, str]],
    *,
    always_show_all_keys: bool = True,
    sort_rows_and_cols: bool = True,
) -> str:
    """
    Convert list of dicts into simple lines, preserving all fields.
    Format per cell:
      Row 25: G25 value="IC_TOTAL_THIRD"; epm_formula="= ..."; excel_formula=""

    Parameters:
      - always_show_all_keys: if True, always prints value/epm_formula/excel_formula even if empty.
      - sort_rows_and_cols: if True, rows ascending and columns in A..Z..AA order.

    Expected keys in each record:
      - column_and_row_position (e.g., "G25")
      - actual_value
      - epm_formula
      - excel_formula
    """
    by_row = defaultdict(list)
    for rec in records:
        coord = rec.get("column_and_row_position") or rec.get("coordinate") or ""
        if not coord:
            continue
        col, row = _col_row_from_coord(coord)
        value = rec.get("actual_value", "")
        epm = rec.get("epm_formula", "")
        xlf = rec.get("excel_formula", "")

        by_row[row].append({
            "_col": col,
            "coord": coord,
            "value": "" if value is None else _one_line(value),
            "epm_formula": "" if epm is None else _one_line(epm),
            "excel_formula": "" if xlf is None else _one_line(xlf),
        })

    lines = []
    row_items = sorted(by_row.items(), key=lambda kv: kv[0]) if sort_rows_and_cols else by_row.items()
    for row_idx, cells in row_items:
        if sort_rows_and_cols:
            cells.sort(key=lambda x: x["_col"])
        parts = []
        for c in cells:
            coord = c["coord"]
            v = c["value"]
            epm = c["epm_formula"]
            xlf = c["excel_formula"]

            if always_show_all_keys:
                # Always show all three fields—even if empty—to avoid losing any info
                parts.append(
                    f'{coord} value="{v}"; epm_formula="{epm}"; excel_formula="{xlf}"'
                )
            else:
                # Only show non-empty fields (OPTIONAL path)
                sub = [f'{coord}']
                if v != "":
                    sub.append(f'value="{v}"')
                if epm != "":
                    sub.append(f'epm_formula="{epm}"')
                if xlf != "":
                    sub.append(f'excel_formula="{xlf}"')
                parts.append("; ".join(sub))

        if parts:
            lines.append(f"Row {row_idx}: " + " | ".join(parts))

    return "\n".join(lines)



# cleaned_text = to_row_text_all_fields(
#     records,
#     always_show_all_keys=True,   # ensures no information is dropped
#     sort_rows_and_cols=True
# )

# final_prompt = f"""CLEANED_SHEET_DATA:
# {cleaned_text}
# END_CLEANED_SHEET_DATA
# """
# print(final_prompt)