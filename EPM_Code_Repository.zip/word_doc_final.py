"""
doc_generator.py
Generates a Word (.docx) Functional Specification Document (FSD) from a SINGLE JSON
following the Option-A schema confirmed by the user.

✅ Exact section order and formatting patterned after the uploaded FSD mock:
   - Cover / Header Info block
   - 1. Document Revision History
   - 2. Purpose and Scope (2.1, 2.2, 2.3)
   - 3. Source BPC EPM Report Overview (3.1, 3.2, 3.3)
   - 4. Source BPC Dimensions & Member Analysis (4.1, 4.2)
   - 5. BPC Account / Measure Details
   - 6. Business Rules & Calculation Logic (6.1, 6.2)
   - 7. BPC to SAC Dimension & Measure Mapping (7.1)
   - 8. SAC Planning Target Design (8.1, 8.2, 8.3, 8.4)
   - 9. Gaps, Risks & Mitigation
   - 10. Testing & Acceptance Criteria (10.1, 10.2, 10.3)
   - 14. Approvals & Sign-Off
   - 11. Appendix (11.1, 11.2)  [kept label to mirror the mock]
   - Open Issues & Action Items

Wherever a JSON value is a LIST → it renders as a TABLE (one row per list entry).
Missing values/entries render as blanks.

Requires Node.js 'docx' npm package in the project directory:
    npm install docx
"""

import json
import subprocess
import os
import sys
import tempfile
import uuid
from typing import Dict, Any, Union

# ──────────────────────────────────────────────────────────────────────────────
# Project dir (where node_modules lives)
# ──────────────────────────────────────────────────────────────────────────────
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))

# ──────────────────────────────────────────────────────────────────────────────
# Fixed top-level keys (Option A schema)
# ──────────────────────────────────────────────────────────────────────────────
FIXED_KEYS = [
    "basic report info",
    "revision history",
    "purpose",
    "scope",
    "out_of_scope",
    "report identification",
    "report_description",
    "dimension_usage",
    "member_selections",
    "account_measure_details",
    "epm_formulas",
    "excel_formulas",
    "dimension mapping",
    "sac_target_model",
    "sac_story_design",
    "data_actions",
    "input_form_design",
    "gaps_risks",
    "test_scenarios",
    "acceptance_criteria",
    "approvals",
    "glossary",
    "reference_documents",
    "open_issues",
]

# ──────────────────────────────────────────────────────────────────────────────
# Load spec: accepts dict or JSON path, ensure all keys exist with safe defaults
# ──────────────────────────────────────────────────────────────────────────────
def _load_spec(spec_or_json_path: Union[Dict[str, Any], str]) -> Dict[str, Any]:
    if isinstance(spec_or_json_path, (str, os.PathLike)):
        json_path = os.path.abspath(spec_or_json_path)
        if not os.path.exists(json_path):
            raise FileNotFoundError(f"JSON file not found: {json_path}")
        with open(json_path, "r", encoding="utf-8") as f:
            spec = json.load(f)
    elif isinstance(spec_or_json_path, dict):
        spec = spec_or_json_path
    else:
        raise TypeError("spec_or_json_path must be a dict or a path to a JSON file")

    # Defaults for all fixed keys
    defaults = {
        "basic report info": {
            "Document Title": "",
            "Project Name": "",
            "Report / Template Name": "",
            "SAC Target Model": "",
            "Document Version": "",
            "Status": "",
            "Prepared By": "",
            "Reviewed By": "",
            "Approved By": "",
            "Date": ""
        },
        "revision history": [],
        "purpose": "",
        "scope": "",
        "out_of_scope": "",
        "report identification": {
            "BPC Application / Environment": "",
            "Report / Template Name": "",
            "Report Type": "",
            "BPC Model / Cube": "",
            "Primary Business Process": "",
            "Frequency of Use": "",
            "Number of Active Users": "",
            "Business Owner": ""
        },
        "report_description": "",
        "dimension_usage": [],
        "member_selections": [],
        "account_measure_details": [],
        "epm_formulas": [],
        "excel_formulas": [],
        "dimension mapping": [],
        "sac_target_model": {
            "SAC Tenant / System": "",
            "SAC Model Name": "",
            "Model Type": "",
            "Planning Area": "",
            "Currency Setting": "",
            "Fiscal Year Variant": "",
            "SAC Story Name": "",
            "Story Type": ""
        },
        "sac_story_design": [],
        "data_actions": [],
        "input_form_design": [],
        "gaps_risks": [],
        "test_scenarios": [],
        "acceptance_criteria": "",
        "approvals": [],
        "glossary": [],
        "reference_documents": [],
        "open_issues": [],
    }

    for k in FIXED_KEYS:
        if k not in spec:
            spec[k] = defaults[k]

    # Normalize types to expected structures
    if not isinstance(spec["basic report info"], dict):
        spec["basic report info"] = defaults["basic report info"]
    for list_key in [
        "revision history", "dimension_usage", "member_selections",
        "account_measure_details", "epm_formulas", "excel_formulas",
        "dimension mapping", "sac_story_design", "data_actions",
        "input_form_design", "gaps_risks", "test_scenarios",
        "approvals", "glossary", "reference_documents", "open_issues"
    ]:
        if not isinstance(spec[list_key], list):
            spec[list_key] = []

    if not isinstance(spec["report identification"], dict):
        spec["report identification"] = defaults["report identification"]
    if not isinstance(spec["sac_target_model"], dict):
        spec["sac_target_model"] = defaults["sac_target_model"]
    if not isinstance(spec["purpose"], str):
        spec["purpose"] = ""
    if not isinstance(spec["scope"], str):
        spec["scope"] = ""
    if not isinstance(spec["out_of_scope"], str):
        spec["out_of_scope"] = ""
    if not isinstance(spec["report_description"], str):
        spec["report_description"] = ""
    if not isinstance(spec["acceptance_criteria"], str):
        spec["acceptance_criteria"] = ""

    return spec


# ──────────────────────────────────────────────────────────────────────────────
# Main API
# ──────────────────────────────────────────────────────────────────────────────
def generate_docx(spec_or_json_path: Union[Dict[str, Any], str], output_path: str) -> str:
    """
    Generate a .docx Functional Specification Document from the provided
    Option-A JSON/dict. Returns absolute path on success.
    """
    spec = _load_spec(spec_or_json_path)

    tmp_dir = tempfile.gettempdir()
    json_path = os.path.join(tmp_dir, f"spec_data_{uuid.uuid4().hex}.json")
    js_path = os.path.join(PROJECT_DIR, f"generate_doc_{uuid.uuid4().hex}.js")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, default=str)

    # Build Node.js script
    js_script = _build_js_script_for_option_a(json_path.replace("\\", "/"), os.path.abspath(output_path).replace("\\", "/"))
    with open(js_path, "w", encoding="utf-8") as f:
        f.write(js_script)

    # Verify docx package
    node_mod_path = os.path.join(PROJECT_DIR, "node_modules", "docx")
    if not os.path.exists(node_mod_path):
        raise RuntimeError(
            f"Node.js 'docx' not installed: {node_mod_path}\n"
            f"Fix: cd {PROJECT_DIR} && npm install docx"
        )

    # Run Node.js to generate docx
    try:
        result = subprocess.run(
            ["node", js_path],
            capture_output=True, text=True, timeout=120,
            cwd=PROJECT_DIR,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "Node.js not found! Install from https://nodejs.org/\n"
            "Then run: npm install docx (in project directory)"
        )

    if result.returncode != 0:
        msg = (result.stderr or result.stdout or "Unknown error")[:2000]
        if "Cannot find module" in msg and "docx" in msg:
            raise RuntimeError(
                f"'docx' module not found. Run: npm install docx\nOriginal error:\n{msg}"
            )
        raise RuntimeError(f"docx generation failed:\n{msg}")

    # Cleanup temp JS/JSON
    try:
        os.remove(js_path)
    except Exception:
        pass
    try:
        os.remove(json_path)
    except Exception:
        pass

    return os.path.abspath(output_path)


# ──────────────────────────────────────────────────────────────────────────────
# Node.js builder for Option A schema
# ──────────────────────────────────────────────────────────────────────────────
def _build_js_script_for_option_a(json_path: str, output_path: str) -> str:
    return '''
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  Header, Footer, PageNumber
} = require("docx");

const SPEC_PATH = "''' + json_path + '''";
const OUT_PATH  = "''' + output_path + '''";
const spec = JSON.parse(fs.readFileSync(SPEC_PATH, "utf-8"));

// ── Visual constants (matching the uploaded mock) ──
const colorPrimary = "2E5090";     // blue headings
const colorHeader  = "2E5090";     // table header background reference
const colorAltRow  = "F2F6FC";     // light alt row
const colorGrid    = "CCCCCC";     // table grid
const baseFont     = "Arial";

const border      = { style: BorderStyle.SINGLE, size: 1, color: colorGrid };
const borders     = { top: border, bottom: border, left: border, right: border };
const headerShade = { fill: colorHeader, type: ShadingType.CLEAR };
const altShade    = { fill: colorAltRow, type: ShadingType.CLEAR };
const cellMargins = { top: 80, bottom: 80, left: 120, right: 120 };

function clean(v) {
  if (v == null) return "";
  return String(v).replace(/&amp;/g, "&");
}

function H1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 240, after: 160 },
    alignment: AlignmentType.LEFT,
    children: [new TextRun({ text, bold: true, font: baseFont, size: 36, color: colorPrimary })]
  });
}

function H2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 220, after: 120 },
    children: [new TextRun({ text, bold: true, font: baseFont, size: 28, color: colorPrimary })]
  });
}

function H3(text) {
  return new Paragraph({
    spacing: { before: 160, after: 80 },
    children: [new TextRun({ text, bold: true, font: baseFont, size: 24, color: colorPrimary })]
  });
}

function txt(text) {
  return new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({ text: clean(text), font: baseFont, size: 20 })]
  });
}

function emptyLine() { return new Paragraph({ children: [], spacing: { after: 60 } }); }

function headerCell(text, width) {
  return new TableCell({
    borders, width: { size: width, type: WidthType.DXA }, margins: cellMargins, shading: headerShade,
    children: [new Paragraph({
      children: [new TextRun({ text: clean(text), bold: true, color: "FFFFFF", font: baseFont, size: 20 })]
    })]
  });
}

function dataCell(text, width, shaded) {
  const opts = { borders, width: { size: width, type: WidthType.DXA }, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text: clean(text), font: baseFont, size: 20 })] })] };
  if (shaded) opts.shading = altShade;
  return new TableCell(opts);
}

function kvTable(pairs, totalWidth=9360) {
  // Renders 2 key/value pairs per row: [Label, Value, Label, Value]
  const colWidths = [2000, 2680, 2000, 2680];
  const rows = [];
  // Header row
  rows.push(new TableRow({
    children: [
      headerCell("Field", colWidths[0]),
      headerCell("Value", colWidths[1]),
      headerCell("Field", colWidths[2]),
      headerCell("Value", colWidths[3]),
    ]
  }));
  let i = 0, isAlt = false;
  while (i < pairs.length) {
    const left = pairs[i] || ["",""];
    const right = pairs[i+1] || ["",""];
    rows.push(new TableRow({
      children: [
        dataCell(left[0] || "", colWidths[0], isAlt),
        dataCell(left[1] || "", colWidths[1], isAlt),
        dataCell(right[0] || "", colWidths[2], isAlt),
        dataCell(right[1] || "", colWidths[3], isAlt),
      ]
    }));
    isAlt = !isAlt;
    i += 2;
  }
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths: colWidths,
    rows
  });
}

function fixedTable(headers, rowsData, totalWidth=9360) {
  // headers: array of strings (column headers in order)
  // rowsData: array of row objects; missing values -> ""
  const colWidth = Math.floor(totalWidth / headers.length);
  const headerRow = new TableRow({ children: headers.map(h => headerCell(h, colWidth)) });
  const rows = [headerRow];
  rowsData.forEach((obj, idx) => {
    const shaded = idx % 2 === 1;
    rows.push(new TableRow({
      children: headers.map(h => dataCell(clean(obj[h] || ""), colWidth, shaded))
    }));
  });
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths: headers.map(() => colWidth),
    rows
  });
}

// ── Build Document children ──
const docChildren = [];

// COVER: Title block (as in the uploaded mock)
docChildren.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 80 },
  children: [new TextRun({ text: "FUNCTIONAL SPECIFICATION DOCUMENT", bold: true, font: baseFont, size: 36, color: colorPrimary })]
}));

docChildren.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: "BPC EPM Report Migration to", font: baseFont, size: 26 })]
}));
docChildren.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  spacing: { after: 220 },
  children: [new TextRun({ text: "SAP Analytics Cloud (SAC) Planning", bold: true, font: baseFont, size: 28 })]
}));

// Header Info Block (two-pairs per row table)
const hdr = spec["basic report info"] || {};
const headerPairs = [
  ["Document Title", hdr["Document Title"] || ""],
  ["Project Name", hdr["Project Name"] || ""],
  ["Report / Template Name", hdr["Report / Template Name"] || ""],
  ["SAC Target Model", hdr["SAC Target Model"] || ""],
  ["Document Version", hdr["Document Version"] || ""],
  ["Status", hdr["Status"] || ""],
  ["Prepared By", hdr["Prepared By"] || ""],
  ["Reviewed By", hdr["Reviewed By"] || ""],
  ["Approved By", hdr["Approved By"] || ""],
  ["Date", hdr["Date"] || ""],
];
docChildren.push(kvTable(headerPairs));
docChildren.push(emptyLine());

// 1. Document Revision History
docChildren.push(H2("1. Document Revision History"));
const revHeaders = ["Version", "Date", "Author", "Change Description", "Reviewed By"];
docChildren.push(fixedTable(revHeaders, Array.isArray(spec["revision history"]) ? spec["revision history"] : []));
docChildren.push(emptyLine());

// 2. Purpose and Scope
docChildren.push(H2("2. Purpose and Scope"));
docChildren.push(H3("2.1 Purpose"));
docChildren.push(txt(spec["purpose"] || ""));
docChildren.push(H3("2.2 Scope"));
docChildren.push(txt(spec["scope"] || ""));
docChildren.push(H3("2.3 Out of Scope"));
docChildren.push(txt(spec["out_of_scope"] || ""));
docChildren.push(emptyLine());

// 3. Source BPC EPM Report Overview
docChildren.push(H2("3. Source BPC EPM Report Overview"));
docChildren.push(H3("3.1 Report Identification"));
const repId = spec["report identification"] || {};
const repIdPairs = [
  ["BPC Application / Environment", repId["BPC Application / Environment"] || ""],
  ["Report / Template Name", repId["Report / Template Name"] || ""],
  ["Report Type", repId["Report Type"] || ""],
  ["BPC Model / Cube", repId["BPC Model / Cube"] || ""],
  ["Primary Business Process", repId["Primary Business Process"] || ""],
  ["Frequency of Use", repId["Frequency of Use"] || ""],
  ["Number of Active Users", repId["Number of Active Users"] || ""],
  ["Business Owner", repId["Business Owner"] || ""],
];
docChildren.push(kvTable(repIdPairs));
docChildren.push(H3("3.2 Report Description and Business Purpose"));
docChildren.push(txt(spec["report_description"] || ""));
docChildren.push(H3("3.3 Report Layout / Structure Summary"));
docChildren.push(txt("")); // blank as per rule (no key provided)
docChildren.push(emptyLine());

// 4. Source BPC Dimensions & Member Analysis
docChildren.push(H2("4. Source BPC Dimensions & Member Analysis"));
docChildren.push(H3("4.1 Dimension Usage in Report"));
const dimUsageHeaders = ["BPC Dimension", "Dimension Type", "Used in Rows Axis", "Used in Cols Axis", "Used in Page Axis", "Member Filter"];
docChildren.push(fixedTable(dimUsageHeaders, Array.isArray(spec["dimension_usage"]) ? spec["dimension_usage"] : []));
docChildren.push(H3("4.2 Member Selections and Hierarchies"));
const memSelHeaders = ["Dimension", "Members / Range", "Hierarchy Used", "BPC Formula / MDX", "Cell Value"];
docChildren.push(fixedTable(memSelHeaders, Array.isArray(spec["member_selections"]) ? spec["member_selections"] : []));
docChildren.push(emptyLine());

// 5. BPC Account / Measure Details
docChildren.push(H2("5. BPC Account / Measure Details"));
const acctHeaders = ["Account ID", "Account Description", "Account Type", "Input / Calc / Reported", "Local Member / Excel Formula"];
docChildren.push(fixedTable(acctHeaders, Array.isArray(spec["account_measure_details"]) ? spec["account_measure_details"] : []));
docChildren.push(emptyLine());

// 6. Business Rules & Calculation Logic
docChildren.push(H2("6. Business Rules & Calculation Logic"));
docChildren.push(H3("6.1 EPM Formulas & Dynamic Templates"));
const epmHeaders = ["EPM Formula", "Cell/Range Applied", "SAC Equivalent"];
docChildren.push(fixedTable(epmHeaders, Array.isArray(spec["epm_formulas"]) ? spec["epm_formulas"] : []));
docChildren.push(H3("6.2 Custom Excel Formulas"));
const xlsHeaders = ["Cell", "Type", "Formula", "Explanation"];
docChildren.push(fixedTable(xlsHeaders, Array.isArray(spec["excel_formulas"]) ? spec["excel_formulas"] : []));
docChildren.push(emptyLine());

// 7. BPC to SAC Dimension & Measure Mapping
docChildren.push(H2("7. BPC to SAC Dimension & Measure Mapping"));
docChildren.push(H3("7.1 Dimension Mapping"));
const mapHeaders = ["BPC Dimension", "Hierarchy", "SAC Dimension", "SAC Type", "SAC Mapping Notes", "Gap / Action"];
docChildren.push(fixedTable(mapHeaders, Array.isArray(spec["dimension mapping"]) ? spec["dimension mapping"] : []));
docChildren.push(emptyLine());

// 8. SAC Planning Target Design
docChildren.push(H2("8. SAC Planning Target Design"));
docChildren.push(H3("8.1 Target SAC Model (FDD-aligned)"));
const sac = spec["sac_target_model"] || {};
const sacPairs = [
  ["SAC Tenant / System", sac["SAC Tenant / System"] || ""],
  ["SAC Model Name", sac["SAC Model Name"] || ""],
  ["Model Type", sac["Model Type"] || ""],
  ["Planning Area", sac["Planning Area"] || ""],
  ["Currency Setting", sac["Currency Setting"] || ""],
  ["Fiscal Year Variant", sac["Fiscal Year Variant"] || ""],
  ["SAC Story Name", sac["SAC Story Name"] || ""],
  ["Story Type", sac["Story Type"] || ""],
];
docChildren.push(kvTable(sacPairs));

docChildren.push(H3("8.2 SAC Story / Page Design"));
const storyHeaders = ["Page #", "Page Name", "Purpose / Description", "Widgets / Components", "BPC Tab Equivalent"];
docChildren.push(fixedTable(storyHeaders, Array.isArray(spec["sac_story_design"]) ? spec["sac_story_design"] : []));

docChildren.push(H3("8.3 SAC Data Actions / Calculations"));
const daHeaders = ["Data Action Name", "Logic Description", "Trigger", "BPC Equivalent"];
docChildren.push(fixedTable(daHeaders, Array.isArray(spec["data_actions"]) ? spec["data_actions"] : []));

docChildren.push(H3("8.4 Input Form Design"));
const inFormHeaders = ["Input Field / Measure", "Data Type", "Editable (Y/N)", "Validation Rule", "Notes"];
docChildren.push(fixedTable(inFormHeaders, Array.isArray(spec["input_form_design"]) ? spec["input_form_design"] : []));
docChildren.push(emptyLine());

// 9. Gaps, Risks & Mitigation
docChildren.push(H2("9. Gaps, Risks & Mitigation"));
const gapHeaders = ["Gap / Risk Description", "Category", "Priority", "Mitigation / Resolution"];
docChildren.push(fixedTable(gapHeaders, Array.isArray(spec["gaps_risks"]) ? spec["gaps_risks"] : []));
docChildren.push(emptyLine());

// 10. Testing & Acceptance Criteria
docChildren.push(H2("10. Testing & Acceptance Criteria"));
docChildren.push(H3("10.1 Testing Approach"));
// No JSON key (by design) → print blank paragraph
docChildren.push(txt(""));
docChildren.push(H3("10.2 Test Scenarios"));
const tsHeaders = ["TC #", "Test Scenario", "Expected Result", "Actual Result", "Status", "Tester"];
docChildren.push(fixedTable(tsHeaders, Array.isArray(spec["test_scenarios"]) ? spec["test_scenarios"] : []));
docChildren.push(H3("10.3 Acceptance Criteria"));
docChildren.push(txt(spec["acceptance_criteria"] || ""));
docChildren.push(emptyLine());

// 14. Approvals & Sign-Off (positioned to mirror the mock)
docChildren.push(H2("14. Approvals & Sign-Off"));
const apprHeaders = ["Name", "Role / Title", "Department", "Date", "Signature"];
docChildren.push(fixedTable(apprHeaders, Array.isArray(spec["approvals"]) ? spec["approvals"] : []));
docChildren.push(emptyLine());

// 11. Appendix (kept label to mirror the uploaded mock)
docChildren.push(H2("11. Appendix"));
docChildren.push(H3("11.1 Glossary"));
const glHeaders = ["Term", "Definition"];
docChildren.push(fixedTable(glHeaders, Array.isArray(spec["glossary"]) ? spec["glossary"] : []));
docChildren.push(H3("11.2 Reference Documents"));
const refHeaders = ["Document Name", "Author / Owner", "Version", "Location"];
docChildren.push(fixedTable(refHeaders, Array.isArray(spec["reference_documents"]) ? spec["reference_documents"] : []));
docChildren.push(emptyLine());

// Open Issues & Action Items (shown near the end as per mock)
docChildren.push(H2("Open Issues & Action Items"));
const issuesHeaders = ["Issue / Action", "Owner", "Due Date", "Status", "Priority"];
docChildren.push(fixedTable(issuesHeaders, Array.isArray(spec["open_issues"]) ? spec["open_issues"] : []));
docChildren.push(emptyLine());

// ── Header & Footer (styled similar to mock) ──
const ver = clean((spec["basic report info"] || {})["Document Version"] || "v1.0");
const headerPara = new Paragraph({
  alignment: AlignmentType.RIGHT,
  children: [new TextRun({
    text: `Functional Specification Document — BPC EPM to SAC Planning Migration ${ver}`,
    italics: true, font: baseFont, size: 18, color: "888888"
  })]
});
const footerPara = new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [
    new TextRun({ text: "Internal Use Only — Page ", font: baseFont, size: 18 }),
    new TextRun({ children: [PageNumber.CURRENT], font: baseFont, size: 18 }),
  ]
});

// ── Build the doc ──
const doc = new Document({
  styles: {
    default: { document: { run: { font: baseFont, size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: baseFont, color: colorPrimary },
        paragraph: { spacing: { before: 240, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: baseFont, color: colorPrimary },
        paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
      }
    },
    headers: { default: new Header({ children: [headerPara] }) },
    footers: { default: new Footer({ children: [footerPara] }) },
    children: docChildren
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(OUT_PATH, buf);
  console.log("OK");
}).catch(err => {
  console.error("Error:", err?.message || err);
  process.exit(1);
});
'''


# ──────────────────────────────────────────────────────────────────────────────
# Optional: generate all .docx from a folder of *.json files
# ──────────────────────────────────────────────────────────────────────────────
def generate_all_specs_from_json_folder(input_dir: str, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    results = {}
    for name in os.listdir(input_dir):
        if not name.lower().endswith(".json"):
            continue
        json_path = os.path.join(input_dir, name)
        safe_base = os.path.splitext(name)[0].replace(" ", "_").replace("%", "Pct").replace("/", "_")
        out_path = os.path.join(output_dir, f"FSD_{safe_base}.docx")
        try:
            generate_docx(json_path, out_path)
            results[name] = out_path
            print(f"  ✅ {name}: {out_path}")
        except Exception as e:
            results[name] = f"ERROR: {e}"
            print(f"  ❌ {name}: {e}")
    return results