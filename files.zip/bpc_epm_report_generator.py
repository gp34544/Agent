#!/usr/bin/env python3
"""
BPC EPM Report Generator
Generates 3 separate Word documents for each report sheet:
  1. Validations Report
  2. Missing Seller % Report
  3. Missing Buyer % Report

Each document includes:
  - A rendered screenshot of the report layout
  - Dimensions (attributes, display format, sorting, hierarchies, business rules)
  - Measures / KPIs with formulas and business logic
"""

import os
import re
import sys
import json
import subprocess
import textwrap
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional

import openpyxl
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont


# ──────────────────────────────────────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class DimensionInfo:
    name: str
    display_format: str = ""
    sorting: str = "Ascending (by Member ID)"
    hierarchies: List[str] = field(default_factory=list)
    properties: List[str] = field(default_factory=list)
    members: List[str] = field(default_factory=list)
    business_rules: List[str] = field(default_factory=list)
    context_formula: str = ""


@dataclass
class MeasureInfo:
    code: str
    description: str
    formula: str
    validation_formula: str
    account: str = ""
    flow: str = ""
    tpartner: str = ""
    tolerance: str = ""
    business_logic: str = ""


# ──────────────────────────────────────────────────────────────────────────────
# Colour palette (Excel-like)
# ──────────────────────────────────────────────────────────────────────────────

PALETTE = {
    "header_bg":   (0,  70,  127),   # dark navy
    "header_fg":   (255, 255, 255),
    "section_bg":  (0,  112, 192),   # medium blue
    "section_fg":  (255, 255, 255),
    "row_a":       (235, 243, 255),  # light blue
    "row_b":       (255, 255, 255),
    "warn_bg":     (255, 121, 121),  # soft red for totals
    "warn_fg":     (255, 255, 255),
    "grid":        (180, 180, 180),
    "text":        (30,  30,  30),
    "label_bg":    (255, 255, 204),  # yellow note
    "subhdr_bg":   (189, 215, 238),  # pale blue sub-header
    "subhdr_fg":   (0,   0,   0),
}


# ──────────────────────────────────────────────────────────────────────────────
# Screenshot renderer  (produces a PNG of the report layout)
# ──────────────────────────────────────────────────────────────────────────────

def _font(size: int, bold: bool = False):
    """Return a PIL font – falls back to default if TTF not found."""
    for fpath in [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]:
        if os.path.exists(fpath):
            try:
                return ImageFont.truetype(fpath, size)
            except Exception:
                pass
    return ImageFont.load_default()


def render_validations_screenshot(ws) -> str:
    """Render the Validations sheet layout to a PNG and return its path."""
    W, H = 1600, 900
    img = Image.new("RGB", (W, H), (255, 255, 255))
    draw = ImageDraw.Draw(img)

    fB16 = _font(16, bold=True)
    fB13 = _font(13, bold=True)
    fR11 = _font(11)
    fB11 = _font(11, bold=True)
    fR9  = _font(9)

    # ── title bar ──────────────────────────────────────────────────────────
    draw.rectangle([0, 0, W, 46], fill=PALETTE["header_bg"])
    draw.text((20, 12), "BPC EPM — Validations Report  (Model: BMAIN)",
              font=fB16, fill=PALETTE["header_fg"])

    # ── context bar ────────────────────────────────────────────────────────
    draw.rectangle([0, 46, W, 80], fill=PALETTE["subhdr_bg"])
    ctx = [("MODEL", "BMAIN"), ("CATEGORY", "<context>"),
           ("ENTITY", "<context>"), ("TIME", "<context>")]
    for i, (k, v) in enumerate(ctx):
        x = 20 + i * 200
        draw.text((x, 52), f"{k}:", font=fB11, fill=PALETTE["text"])
        draw.text((x + 80, 52), v, font=fR11, fill=(0, 80, 160))

    # ── report-objective note ───────────────────────────────────────────────
    draw.rectangle([0, 80, W, 108], fill=PALETTE["label_bg"])
    draw.text((20, 88),
              "Report Objective:  Data validation by entity — "
              "Assets vs Liabilities, P&L vs BS, Movement reconciliations",
              font=fR11, fill=(100, 70, 0))

    # ── column headers ──────────────────────────────────────────────────────
    cols = [
        ("Validation #", 110), ("Description", 330), ("CHECK", 90),
        ("VALIDATION", 90),    ("FS ITEM / Account", 150),
        ("FLOW", 70),          ("TPARTNER", 140),     ("Entity →", 200),
    ]
    y_hdr = 108
    draw.rectangle([0, y_hdr, W, y_hdr + 28], fill=PALETTE["section_bg"])
    x = 10
    for label, w in cols:
        draw.text((x + 4, y_hdr + 7), label, font=fB11, fill=PALETTE["section_fg"])
        draw.line([(x + w, y_hdr), (x + w, y_hdr + 28)], fill="white", width=1)
        x += w

    # ── Restrictive validations section ─────────────────────────────────────
    y = y_hdr + 28
    draw.rectangle([0, y, W, y + 20], fill=(220, 235, 255))
    draw.text((10, y + 4), "Restrictive Validations", font=fB13, fill=PALETTE["header_bg"])

    validations = [
        ("V11001", "Asset = Liabilities + Equity",              "SUM(entities)", "±100",
         "1001000001", "B99", "IC_TOTAL_THIRD"),
        ("V11002", "Opening Balance Assets = Opening Balance Liabilities",
         "SUM(entities)", "±10",  "1001000001", "B10",  "IC_TOTAL_THIRD"),
        ("V11003", "Net Income P&L = Net Income BS",            "SUM(J13,J14)−J15","±10",
         "2001000001", "B99", "Local Member"),
        ("V11004", "Balance Movements = End Balance",           "J17 − J11",       "±10",
         "GCOA",        "ERR", "Local Member"),
        ("V11005", "ERROR Movement Type Validation",            "SUM(entities)",   "±10",
         "GCOA",        "ERR", "IC_TOTAL_THIRD"),
    ]
    y += 20
    for i, (code, desc, formula, tol, acct, flow, tp) in enumerate(validations):
        bg = PALETTE["row_a"] if i % 2 == 0 else PALETTE["row_b"]
        draw.rectangle([0, y, W, y + 22], fill=bg)
        row_data = [code, desc, formula, f"IF OR(E>{tol}),1,0", acct, flow, tp, "→ per entity"]
        x = 10
        for j, (cell_text, (_, cw)) in enumerate(zip(row_data, cols)):
            draw.text((x + 4, y + 4), str(cell_text)[:22], font=fR9, fill=PALETTE["text"])
            x += cw
        draw.line([(0, y + 22), (W, y + 22)], fill=PALETTE["grid"], width=1)
        y += 22

    # ── Exceptions section ──────────────────────────────────────────────────
    draw.rectangle([0, y, W, y + 20], fill=(220, 235, 255))
    draw.text((10, y + 4), "Exceptions / Validation Errors", font=fB13, fill=PALETTE["header_bg"])
    y += 20

    exceptions = [
        ("V11006", "Missing Seller Margin %",                 "COUNTIFS(…)",   "—",      "GCOA", "ERR", "Local"),
        ("V11007", "Missing Buyer Allocation %",              "COUNTIFS(…)",   "—",      "GCOA", "ERR", "Local"),
        ("V11008", "RP Account Payable – TP THIRD",           "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V11009", "RP Account Receivable – TP THIRD",        "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110010","Accum. Dep. Movement vs P&L",             "VLOOKUP(…,17)", "±100",   "GCOA", "ERR", "Local"),
        ("V110011","Provision Inventory Movement vs P&L",     "VLOOKUP(…,5)",  "±100",   "GCOA", "ERR", "Local"),
        ("V110012","Provision Receivables Movement vs P&L",   "VLOOKUP(…,12)", "±100",   "GCOA", "ERR", "Local"),
        ("V110013","Investment in Subsidiary – TP THIRD",     "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110014","Provision in Investment Movement vs P&L", "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110015","Negative Revenue",                        "VLOOKUP(…,2)",  "±100",   "GCOA", "ERR", "Local"),
        ("V110016","Dividend Income – TP THIRD",              "VLOOKUP(…,2)",  "±100",   "GCOA", "ERR", "Local"),
        ("V110017","Capex Addition – Negative Movement",      "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110018","Capex Disposal – Positive Movement",      "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110019","Receivable Reverse Balance",              "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110020","Payable Reverse Balance",                 "SUMIF(…)",      "±100",   "GCOA", "ERR", "Local"),
        ("V110021","Reserves Addition vs Transfer",           "VLOOKUP(…,23)", "±100",   "GCOA", "ERR", "Local"),
        ("V110022","Finance Cost / COE – TP THIRD",          "VLOOKUP(…,12)", "±100",   "GCOA", "ERR", "Local"),
    ]
    for i, (code, desc, formula, tol, acct, flow, tp) in enumerate(exceptions):
        if y > H - 50:
            break
        bg = PALETTE["row_a"] if i % 2 == 0 else PALETTE["row_b"]
        draw.rectangle([0, y, W, y + 22], fill=bg)
        row_data = [code, desc, formula, f"IF |val|>{tol}", acct, flow, tp, "→ per entity"]
        x = 10
        for cell_text, (_, cw) in zip(row_data, cols):
            draw.text((x + 4, y + 4), str(cell_text)[:25], font=fR9, fill=PALETTE["text"])
            x += cw
        draw.line([(0, y + 22), (W, y + 22)], fill=PALETTE["grid"], width=1)
        y += 22

    # ── Total Failed row ────────────────────────────────────────────────────
    if y < H - 30:
        draw.rectangle([0, y, W, y + 26], fill=PALETTE["warn_bg"])
        draw.text((10, y + 6),
                  "Total Failed Validations   =SUM(F23:F40)   →  aggregated across all entities",
                  font=fB11, fill=PALETTE["warn_fg"])

    # ── outer border ────────────────────────────────────────────────────────
    draw.rectangle([0, 0, W - 1, H - 1], outline=(100, 100, 100), width=2)

    path = "/home/claude/screenshot_validations.png"
    img.save(path, "PNG")
    return path


def render_seller_screenshot(ws) -> str:
    """Render the Missing Seller % sheet layout."""
    W, H = 1400, 700
    img = Image.new("RGB", (W, H), (255, 255, 255))
    draw = ImageDraw.Draw(img)

    fB16 = _font(16, bold=True)
    fB13 = _font(13, bold=True)
    fB11 = _font(11, bold=True)
    fR11 = _font(11)
    fR9  = _font(9)

    # Title
    draw.rectangle([0, 0, W, 46], fill=PALETTE["header_bg"])
    draw.text((20, 12), "BPC EPM — Missing Seller % Report  (V11006)",
              font=fB16, fill=PALETTE["header_fg"])

    # Context
    draw.rectangle([0, 46, W, 78], fill=PALETTE["subhdr_bg"])
    ctx = [("MODEL", "BMAIN"), ("CATEGORY", "<context>"),
           ("TIME", "<context>"), ("CURRENCY", "<context>"), ("ENTITY", "<context>")]
    for i, (k, v) in enumerate(ctx):
        x = 20 + i * 210
        draw.text((x, 54), f"{k}:", font=fB11, fill=PALETTE["text"])
        draw.text((x + 80, 54), v, font=fR11, fill=(0, 80, 160))

    # Objective
    draw.rectangle([0, 78, W, 104], fill=PALETTE["label_bg"])
    draw.text((20, 85),
              "Report Objective:  Shows only MISSING Stock Margin %  (highlighted Red) "
              "of selected entity  |  User Action: Update missing margin %",
              font=fR11, fill=(100, 70, 0))

    # Data-source row
    draw.rectangle([0, 104, W, 126], fill=(240, 240, 240))
    draw.text((20, 110), "Data Sources:", font=fB11, fill=PALETTE["text"])
    for i, (label, src) in enumerate([
            ("Net Sales", "ACCOUNT: SME_SALES / DATASRC: UPLOAD"),
            ("Cost of Goods Sold", "ACCOUNT: SME_COGS / DATASRC: UPLOAD"),
            ("Stock Margin %", "ACCOUNT: SMEPercent / DATASRC: AD_MLC"),
    ]):
        x = 140 + i * 380
        draw.text((x, 110), f"{label}  →  {src}", font=fR9, fill=(60, 60, 60))

    # Column headers
    cols = [
        ("Seller Entity", 200), ("Buyer Entity", 200),
        ("Net Sales\n(SME_SALES)", 160), ("COGS\n(SME_COGS)", 140),
        ("Stock Margin %\n(SMEPercent)", 160), ("Check\n(0=Missing 1=OK)", 170),
    ]
    y_hdr = 126
    draw.rectangle([0, y_hdr, W, y_hdr + 34], fill=PALETTE["section_bg"])
    x = 10
    for label, w in cols:
        for li, ln in enumerate(label.split("\n")):
            draw.text((x + 5, y_hdr + 5 + li * 13), ln, font=fB11, fill="white")
        draw.line([(x + w, y_hdr), (x + w, y_hdr + 34)], fill="white", width=1)
        x += w

    # Sample rows
    rows = [
        ("1090_EntityName_A", "IC001-Trading Partner 1", "1,250,000", "875,000", "30%", "1 ✓"),
        ("1091_EntityName_B", "IC002-Trading Partner 2", "980,000",   "720,000", "",    "0 ✗"),
        ("1092_EntityName_C", "IC001-Trading Partner 1", "0",         "0",       "0",   "1 ✓"),
        ("1093_EntityName_D", "IC003-Trading Partner 3", "450,000",   "315,000", "",    "0 ✗"),
        ("1094_EntityName_E", "IC002-Trading Partner 2", "2,100,000", "1,470,000","40%","1 ✓"),
        ("…",                 "…",                       "…",         "…",       "…",   "…"),
    ]
    y = y_hdr + 34
    col_widths = [c[1] for c in cols]
    for i, row in enumerate(rows):
        bg = (255, 200, 200) if row[5].startswith("0") else (PALETTE["row_a"] if i % 2 == 0 else PALETTE["row_b"])
        draw.rectangle([0, y, W, y + 24], fill=bg)
        x = 10
        for val, cw in zip(row, col_widths):
            draw.text((x + 5, y + 6), str(val)[:26], font=fR9,
                      fill=(180, 0, 0) if val.startswith("0 ✗") else PALETTE["text"])
            draw.line([(x + cw, y), (x + cw, y + 24)], fill=PALETTE["grid"], width=1)
            x += cw
        draw.line([(0, y + 24), (W, y + 24)], fill=PALETTE["grid"], width=1)
        y += 24

    # Key formula
    draw.rectangle([0, y + 10, W, y + 60], fill=(245, 245, 255))
    draw.text((20, y + 15), "Check Formula  (Column M):", font=fB11, fill=PALETTE["header_bg"])
    draw.text((20, y + 32),
              "=IF(AND(NetSales=0, COGS=0, Margin%=0), 1,  IF(OR(Margin%=\"\", Margin%=0), 0, 1))",
              font=fR11, fill=(60, 0, 120))
    draw.text((20, y + 48),
              "Logic:  If all zeros → no transaction (1 = OK)  |  If margin% blank/zero → MISSING (0 = Error)",
              font=fR9, fill=(80, 80, 80))

    draw.rectangle([0, 0, W - 1, H - 1], outline=(100, 100, 100), width=2)
    path = "/home/claude/screenshot_seller.png"
    img.save(path, "PNG")
    return path


def render_buyer_screenshot(ws) -> str:
    """Render the Missing Buyer % sheet layout."""
    W, H = 1400, 760
    img = Image.new("RGB", (W, H), (255, 255, 255))
    draw = ImageDraw.Draw(img)

    fB16 = _font(16, bold=True)
    fB13 = _font(13, bold=True)
    fB11 = _font(11, bold=True)
    fR11 = _font(11)
    fR9  = _font(9)

    # Title
    draw.rectangle([0, 0, W, 46], fill=PALETTE["header_bg"])
    draw.text((20, 12), "BPC EPM — Missing Buyer % Report  (V11007)",
              font=fB16, fill=PALETTE["header_fg"])

    # Context
    draw.rectangle([0, 46, W, 78], fill=PALETTE["subhdr_bg"])
    for i, (k, v) in enumerate([("MODEL","BMAIN"),("CATEGORY","<context>"),
                                  ("TIME","<context>"),("CURRENCY","<context>"),
                                  ("ENTITY","<context>")]):
        x = 20 + i * 210
        draw.text((x, 54), f"{k}:", font=fB11, fill=PALETTE["text"])
        draw.text((x + 80, 54), v, font=fR11, fill=(0, 80, 160))

    # Objective
    draw.rectangle([0, 78, W, 104], fill=PALETTE["label_bg"])
    draw.text((20, 85),
              "Report Objective:  Buyer % by entity & trading partner — "
              "highlighted Red where missing  |  User Action: Update missing Buyer %",
              font=fR11, fill=(100, 70, 0))

    # Account reference table
    draw.rectangle([0, 104, W, 126], fill=(220, 235, 255))
    draw.text((20, 110), "TP Purchase Accounts Reference:", font=fB11, fill=PALETTE["header_bg"])
    accts = ["6701000101 Other Goods", "6701000102 Other Svcs", "6701000103 Goods",
             "6701000104 Services", "6701000105 RP Goods", "…"]
    for i, a in enumerate(accts):
        draw.text((220 + i * 190, 110), a, font=fR9, fill=(40, 40, 40))

    # Column headers
    cols = [
        ("Buyer Entity", 200), ("Seller / TP Entity", 200),
        ("Sales / Purchase\nDescription", 180), ("Flow", 80),
        ("YTD Amount", 130), ("Buyer %", 110), ("Status", 90),
    ]
    y_hdr = 126
    draw.rectangle([0, y_hdr, W, y_hdr + 34], fill=PALETTE["section_bg"])
    x = 10
    for label, w in cols:
        for li, ln in enumerate(label.split("\n")):
            draw.text((x + 5, y_hdr + 5 + li * 13), ln, font=fB11, fill="white")
        draw.line([(x + w, y_hdr), (x + w, y_hdr + 34)], fill="white", width=1)
        x += w

    rows = [
        ("1090 - EntityName A", "IC_TOTAL_THIRD - All",  "TP Purchased-Goods",      "B99", "500,000",   "35%",  "OK"),
        ("1090 - EntityName A", "IC001 - Seller 1",       "TP Purchased-Services",   "B99", "200,000",   "",     "Error"),
        ("1091 - EntityName B", "IC002 - Seller 2",       "TP Purchased-RP Goods",   "B99", "1,200,000", "28%",  "OK"),
        ("1091 - EntityName B", "IC003 - Seller 3",       "TP Purchased-Other Goods","B99", "300,000",   "",     "Error"),
        ("1092 - EntityName C", "IC001 - Seller 1",       "TP Purchased-Brokerage",  "B99", "150,000",   "12%",  "OK"),
        ("…",                   "…",                      "…",                        "…",   "…",         "…",    "…"),
    ]
    y = y_hdr + 34
    col_widths = [c[1] for c in cols]
    for i, row in enumerate(rows):
        is_err = row[6] == "Error"
        bg = (255, 200, 200) if is_err else (PALETTE["row_a"] if i % 2 == 0 else PALETTE["row_b"])
        draw.rectangle([0, y, W, y + 24], fill=bg)
        x = 10
        for val, cw in zip(row, col_widths):
            color = (180, 0, 0) if (is_err and val == "Error") else PALETTE["text"]
            draw.text((x + 5, y + 6), str(val)[:26], font=fR9, fill=color)
            draw.line([(x + cw, y), (x + cw, y + 24)], fill=PALETTE["grid"], width=1)
            x += cw
        draw.line([(0, y + 24), (W, y + 24)], fill=PALETTE["grid"], width=1)
        y += 24

    # Total check indicator
    draw.rectangle([0, y + 6, 400, y + 32], fill=(220, 255, 220))
    draw.text((10, y + 13), "Total Check  =IF(COUNTIF(M:M,\"0\")=0, \"OK\", \"Error\")",
              font=fB11, fill=(0, 100, 0))

    # Formula block
    y2 = y + 40
    draw.rectangle([0, y2, W, y2 + 80], fill=(245, 245, 255))
    draw.text((20, y2 + 8), "Buyer % Retrieval Formula:", font=fB11, fill=PALETTE["header_bg"])
    draw.text((20, y2 + 26),
              "=_xll.EPMRetrieveData(ModelID, BuyerEntity, SellerEntity, \"GCOA\","
              " _xll.EPMMemberProperty(ModelID, FlowMember, \"PARENTH1\"))",
              font=fR9, fill=(60, 0, 120))
    draw.text((20, y2 + 44),
              "Account Expansion: BAS(6701000100)   |   Flow Expansion: BAS(SM_TOT)",
              font=fR9, fill=(80, 80, 80))
    draw.text((20, y2 + 60),
              "Status Logic:  IF Buyer% = 0 or blank  →  Error (highlighted RED)   "
              "ELSE  OK",
              font=fR9, fill=(80, 80, 80))

    draw.rectangle([0, 0, W - 1, H - 1], outline=(100, 100, 100), width=2)
    path = "/home/claude/screenshot_buyer.png"
    img.save(path, "PNG")
    return path


# ──────────────────────────────────────────────────────────────────────────────
# Excel data extraction helpers
# ──────────────────────────────────────────────────────────────────────────────

def _olap_id(formula: str) -> str:
    """Extract member ID from EPMOlapMemberO formula."""
    if not formula or not isinstance(formula, str):
        return ""
    m = re.search(r'\[([A-Z0-9_]+)\]\.\[[A-Z0-9]+\]\.\[([A-Z0-9_]+)\]', formula)
    if m:
        return m.group(2)
    m = re.search(r'"([A-Z0-9_]+)"', formula)
    return m.group(1) if m else str(formula)[:30]


def _tolerance(formula: str) -> str:
    m = re.search(r'>(\d+)', formula or "")
    return f"±{m.group(1)}" if m else ""


def _logic(formula: str) -> str:
    if not formula or not isinstance(formula, str):
        return ""
    if "COUNTIFS" in formula:
        return "Cross-sheet count: flags if matching missing records found"
    if "VLOOKUP" in formula:
        col = re.search(r',(\d+),FALSE', formula)
        return f"VLOOKUP col {col.group(1)} from detail sheet" if col else "VLOOKUP from detail sheet"
    if "SUMIF" in formula and "#REF" in formula:
        return "SUMIF from linked detail sheet (cross-sheet)"
    if re.match(r'=SUM\(J\d+,\s*J\d+\)\-J\d+', formula):
        return "Net Income: Retained Earnings + Current Year P&L − Equity Net Income"
    if re.match(r'=J\d+\-J\d+', formula):
        return "Difference: TOTB − Closing Balance (must equal zero)"
    if "SUM" in formula:
        return "Horizontal SUM across all entity columns (J … XX)"
    return "Custom calculation"


def extract_validations(ws) -> Tuple[List[DimensionInfo], List[MeasureInfo]]:
    """Extract dimensions and measures from Validations sheet."""
    dims: Dict[str, DimensionInfo] = {}

    # Context dimensions
    for row in range(3, 8):
        label = ws[f'C{row}'].value
        formula = ws[f'D{row}'].value
        if label and isinstance(label, str):
            d = DimensionInfo(name=label.strip())
            if isinstance(formula, str) and formula.startswith('='):
                d.context_formula = formula
                d.display_format = "Context-driven (EPMContextMember)"
            else:
                d.display_format = "Static value"
                d.members = [str(formula)] if formula else []
            dims[label.strip()] = d

    # Scan formulas for additional dimensions
    for row in ws.iter_rows(min_row=1, max_row=50):
        for cell in row:
            if not cell.value or not isinstance(cell.value, str):
                continue
            v = cell.value
            if "ENTITY" in v and "ENTITY" not in dims:
                dims["ENTITY"] = DimensionInfo(
                    name="ENTITY",
                    display_format="ID_Description  (e.g. 1090_EntityName)",
                    hierarchies=["PARENTH1"],
                    properties=["CALC", "DIVISIONS"],
                    business_rules=[
                        "If CALC='N' → use member directly",
                        "If CALC='Y' → wrap with BAS(member) for base members only",
                        "EPMDimensionOverride applied for context-based filtering",
                    ],
                )
            if "ACCOUNT" in v:
                if "ACCOUNT" not in dims:
                    dims["ACCOUNT"] = DimensionInfo(
                        name="ACCOUNT",
                        display_format="ID - Description",
                        hierarchies=["PARENTH1", "PARENTH2"],
                        business_rules=["GCOA = Group Chart of Accounts (all accounts aggregate)"],
                    )
                m = re.search(r'\[ACCOUNT\]\.\[PARENTH1\]\.\[([A-Z0-9_]+)\]', v)
                if m:
                    dims["ACCOUNT"].members.append(m.group(1))
            if "BFLOW" in v:
                if "BFLOW" not in dims:
                    dims["BFLOW"] = DimensionInfo(
                        name="BFLOW",
                        display_format="ID - Description  (e.g. B99 - Closing Bal.)",
                        hierarchies=["PARENTH1"],
                        members=["B10", "B99", "TOTB", "ERR"],
                        business_rules=["ERR flow captures validation discrepancies"],
                    )
            if "TPARTNER" in v:
                if "TPARTNER" not in dims:
                    dims["TPARTNER"] = DimensionInfo(
                        name="TPARTNER",
                        display_format="ID-Description  (e.g. IC_TOTAL_THIRD-All IC & Third)",
                        hierarchies=["PARENTH1"],
                        members=["IC_TOTAL_THIRD", "THIRD"],
                    )

    # Measures
    measures: List[MeasureInfo] = []
    for row_idx in range(11, 45):
        code = ws[f'C{row_idx}'].value
        desc = ws[f'D{row_idx}'].value
        check_f = ws[f'E{row_idx}'].value
        val_f = ws[f'F{row_idx}'].value
        acct_f = ws[f'G{row_idx}'].value
        flow_f = ws[f'H{row_idx}'].value
        tp_f = ws[f'I{row_idx}'].value

        if not code or not isinstance(code, str) or not code.startswith('V'):
            continue

        # For composite rows (V11003), capture the sub-formula from col J
        sub_f = ws[f'J{row_idx}'].value

        measures.append(MeasureInfo(
            code=str(code),
            description=str(desc or ""),
            formula=str(sub_f if sub_f and isinstance(sub_f, str) and sub_f.startswith('=')
                        else (check_f or "")),
            validation_formula=str(val_f or ""),
            account=_olap_id(str(acct_f or "")),
            flow=_olap_id(str(flow_f or "")),
            tpartner=_olap_id(str(tp_f or "")) if tp_f else "",
            tolerance=_tolerance(str(val_f or "")),
            business_logic=_logic(
                str(sub_f if sub_f and isinstance(sub_f, str) else (check_f or ""))
            ),
        ))

    return list(dims.values()), measures


def extract_seller(ws) -> Tuple[List[DimensionInfo], List[MeasureInfo]]:
    dims = [
        DimensionInfo("ENTITY",   "ID_Description (e.g. 1090_EntityName)", "Ascending",
                      ["PARENTH1"], ["CALC"],
                      business_rules=["BAS(entity) expansion for base members"]),
        DimensionInfo("TPARTNER", "ID-Description (RIGHT(4) + EPMMemberDesc)",
                      "Ascending", ["PARENTH1"]),
        DimensionInfo("ACCOUNT",  "ID - Description", "Ascending", ["PARENTH1", "PARENTH2"],
                      members=["SME_SALES", "SME_COGS", "SMEPercent"],
                      business_rules=["PARENTH2 hierarchy used for SME account grouping"]),
        DimensionInfo("BFLOW",    "ID - Description", "Ascending", ["PARENTH1"],
                      members=["B99"],
                      business_rules=["B99 (Closing Balance) is the only flow retrieved"]),
        DimensionInfo("DATASRC",  "ID - Description", "Ascending", [],
                      members=["UPLOAD", "AD_MLC"],
                      business_rules=[
                          "Net Sales & COGS pulled from DATASRC=UPLOAD",
                          "Stock Margin % pulled from DATASRC=AD_MLC (manual load)",
                      ]),
    ]
    measures = [
        MeasureInfo(
            code="V11006",
            description="Missing Seller Margin % — flags entities where stock margin% is blank/zero",
            formula="=IF(AND(NetSales=0, COGS=0, Margin%=0), 1, IF(OR(Margin%='', Margin%=0), 0, 1))",
            validation_formula="=IF(COUNTIFS('Missing Seller %'!$F:$F, EntityID, 'Missing Seller %'!$M:$M, '0') > 0, 1, 0)",
            account="SMEPercent / SME_SALES / SME_COGS",
            flow="B99",
            tpartner="IC_TOTAL_THIRD",
            tolerance="0 = Error, 1 = OK",
            business_logic=(
                "Three-way check: "
                "(1) If Sales=COGS=Margin%=0 → no transaction, flag as OK. "
                "(2) If Margin% is blank or zero → MISSING, flag as ERROR (0). "
                "(3) Otherwise → OK (1). "
                "Highlighted RED in the sheet when status = 0."
            ),
        )
    ]
    return dims, measures


def extract_buyer(ws) -> Tuple[List[DimensionInfo], List[MeasureInfo]]:
    dims = [
        DimensionInfo("ENTITY",   "ID - Description (EPMMemberDesc)", "Ascending",
                      ["PARENTH1"], ["CALC"],
                      business_rules=["BAS(entity) expansion via EPMDimensionOverride"]),
        DimensionInfo("TPARTNER", "ID - Description", "Ascending", ["PARENTH1"],
                      members=["IC_TOTAL_THIRD"],
                      business_rules=["Seller TP retrieved via EPMMemberProperty PARENTH1"]),
        DimensionInfo("ACCOUNT",  "ID - Description", "Ascending", ["PARENTH1"],
                      members=["6701000101–6701000110", "GCOA"],
                      business_rules=[
                          "Expansion: BAS(6701000100) covers all TP Purchase accounts",
                          "Account lookup via VLOOKUP(J10, A6:C15, 2, 0)",
                      ]),
        DimensionInfo("BFLOW",    "ID - Description", "Ascending", ["PARENTH1"],
                      members=["B99", "SM_TOT", "SM_DST", "SM_CAP", "SM_ST", "SM_EXP"],
                      business_rules=["Flow expansion: BAS(SM_TOT) for stock margin flows"]),
        DimensionInfo("MEASURES", "ID - Description", "Ascending", [],
                      members=["YTD"],
                      business_rules=["YTD (Year-To-Date) measure used for buyer amount"]),
    ]

    # Dynamic account table from rows 6-15
    acct_rows = []
    for r in range(6, 16):
        desc_v = ws[f'A{r}'].value
        acct_v = ws[f'B{r}'].value
        flow_v = ws[f'C{r}'].value
        if acct_v:
            acct_rows.append((str(acct_v), str(desc_v or ""), str(flow_v or "")))

    measures = [
        MeasureInfo(
            code="V11007",
            description="Missing Buyer Allocation % — flags entities where buyer % is blank/zero",
            formula="=_xll.EPMRetrieveData(ModelID, BuyerEntity, SellerEntity, 'GCOA', EPMMemberProperty(ModelID, FlowMember, 'PARENTH1'))",
            validation_formula="=IF(COUNTIFS('Missing Buyer %'!$H:$H, EntityKey, 'Missing Buyer %'!$M:$M, '0') > 0, 1, 0)",
            account="BAS(6701000100)  [" + ", ".join(a[0] for a in acct_rows) + "]",
            flow="BAS(SM_TOT)  [SM_DST, SM_CAP, SM_ST, SM_EXP]",
            tpartner="IC_TOTAL_THIRD (Seller)",
            tolerance="0 = Error (missing), 1 = OK",
            business_logic=(
                "EPMRetrieveData fetches Buyer % from BPC cube for each "
                "Buyer-Seller-Account-Flow combination. "
                "If Buyer% = 0 or blank → Error. "
                "Total Check: =IF(COUNTIF(M:M,'0')=0, 'OK', 'Error'). "
                "Rows highlighted RED where status = Error."
            ),
        )
    ]
    if acct_rows:
        measures[0].business_logic += (
            f"  |  TP Purchase accounts ({len(acct_rows)}): "
            + ", ".join(f"{a[0]} ({a[1]})" for a in acct_rows[:5]) + "…"
        )
    return dims, measures


# ──────────────────────────────────────────────────────────────────────────────
# Word document generator  (using Node.js docx library)
# ──────────────────────────────────────────────────────────────────────────────

def _js_str(s: str) -> str:
    """Escape a string for safe embedding in a JS template literal."""
    return (s.replace("\\", "\\\\")
             .replace("`", "\\`")
             .replace("${", "\\${")
             .replace("\n", " ")
             .replace('"', '\\"'))


def build_docx_js(
    out_path: str,
    title: str,
    subtitle: str,
    objective: str,
    user_action: str,
    screenshot_path: str,
    dimensions: List[DimensionInfo],
    measures: List[MeasureInfo],
) -> str:
    """Return a Node.js script string that creates the Word document."""

    # Read screenshot as base64
    import base64
    with open(screenshot_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()

    from PIL import Image as PILImage
    with PILImage.open(screenshot_path) as im:
        img_w, img_h = im.size

    # Scale image to fit page width (9360 DXA = 6.5 inches = ~620 px at 96dpi)
    max_emu_w = 8_600_000          # ≈ 5.97 inches
    ratio     = img_h / img_w
    emu_w     = max_emu_w
    emu_h     = int(max_emu_w * ratio)

    # Build dimension rows JS
    def dim_rows_js(dims):
        rows = []
        for d in dims:
            rules_text = " | ".join(d.business_rules) or "—"
            rows.append(f"""
        new TableRow({{
          children: [
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"D9E8F5",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(d.name)}",bold:true,size:20,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1600,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(d.display_format)}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1200,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(d.sorting)}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1400,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(', '.join(d.hierarchies) or '—')}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1400,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(', '.join(d.properties) or '—')}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1960,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(rules_text)}",size:18,font:"Arial"}})]}})]}})  ,
          ]
        }})""")
        return ",\n".join(rows)

    # Build measure rows JS
    def meas_rows_js(measures):
        rows = []
        for i, m in enumerate(measures):
            shade = "F2F2F2" if i % 2 == 0 else "FFFFFF"
            rows.append(f"""
        new TableRow({{
          children: [
            new TableCell({{ width:{{size:900,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.code)}",bold:true,size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:2200,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.description)}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.formula[:80])}",size:16,font:"Courier New"}})]}})]}})  ,
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.validation_formula[:70])}",size:16,font:"Courier New"}})]}})]}})  ,
            new TableCell({{ width:{{size:600,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.tolerance)}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:1260,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.account[:40])}",size:18,font:"Arial"}})]}})]}})  ,
            new TableCell({{ width:{{size:600,type:WidthType.DXA}}, borders, margins,
              shading:{{fill:"{shade}",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(m.flow[:20])}",size:18,font:"Arial"}})]}})]}})  ,
          ]
        }})""")
        return ",\n".join(rows)

    # ── full Node.js script ─────────────────────────────────────────────────
    js = f"""
const {{ Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        ImageRun, Header, AlignmentType, HeadingLevel, BorderStyle,
        WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak }} = require('docx');
const fs = require('fs');

const border  = {{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }};
const borders = {{ top: border, bottom: border, left: border, right: border }};
const margins = {{ top: 60, bottom: 60, left: 100, right: 100 }};

const imgData = Buffer.from("{img_b64}", "base64");

const doc = new Document({{
  styles: {{
    default: {{ document: {{ run: {{ font: "Arial", size: 22 }} }} }},
    paragraphStyles: [
      {{ id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
         run: {{ size: 36, bold: true, color: "00467F", font: "Arial" }},
         paragraph: {{ spacing: {{ before: 240, after: 120 }}, outlineLevel: 0 }} }},
      {{ id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
         run: {{ size: 28, bold: true, color: "0070C0", font: "Arial" }},
         paragraph: {{ spacing: {{ before: 200, after: 100 }}, outlineLevel: 1 }} }},
      {{ id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
         run: {{ size: 24, bold: true, color: "404040", font: "Arial" }},
         paragraph: {{ spacing: {{ before: 160, after: 80 }}, outlineLevel: 2 }} }},
    ]
  }},
  sections: [{{
    properties: {{
      page: {{
        size: {{ width: 15840, height: 12240 }},
        margin: {{ top: 720, right: 720, bottom: 720, left: 720 }}
      }}
    }},
    headers: {{
      default: new Header({{
        children: [new Paragraph({{
          alignment: AlignmentType.RIGHT,
          children: [
            new TextRun({{ text: "{_js_str(title)} — ", size: 18, color: "666666", font: "Arial" }}),
            new TextRun({{ text: "Page ", size: 18, color: "666666", font: "Arial" }}),
            new TextRun({{ children: [PageNumber.CURRENT], size: 18, color: "666666", font: "Arial" }}),
          ]
        }})]
      }})
    }},
    children: [

      // ── Cover / Title ────────────────────────────────────────────────────
      new Paragraph({{ heading: HeadingLevel.HEADING_1,
        children: [new TextRun({{ text: "{_js_str(title)}", bold: true, size: 40, font: "Arial" }})] }}),

      new Paragraph({{ children: [
        new TextRun({{ text: "{_js_str(subtitle)}", size: 24, color: "444444", font: "Arial" }})
      ]}}),

      new Paragraph({{ spacing: {{ before: 80, after: 80 }},
        children: [new TextRun({{ text: "", size: 4 }})] }}),

      // ── Info table (objective / action / model) ──────────────────────────
      new Table({{
        width: {{ size: 14400, type: WidthType.DXA }},
        columnWidths: [2000, 12400],
        rows: [
          new TableRow({{ children: [
            new TableCell({{ width:{{size:2000,type:WidthType.DXA}},
              shading:{{fill:"00467F",type:ShadingType.CLEAR}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"Report Objective",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
            new TableCell({{ width:{{size:12400,type:WidthType.DXA}},
              shading:{{fill:"FFFFCC",type:ShadingType.CLEAR}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(objective)}",size:20,font:"Arial"}})]}})]}}),
          ]}}),
          new TableRow({{ children: [
            new TableCell({{ width:{{size:2000,type:WidthType.DXA}},
              shading:{{fill:"00467F",type:ShadingType.CLEAR}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"User Action",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
            new TableCell({{ width:{{size:12400,type:WidthType.DXA}},
              shading:{{fill:"FFFFCC",type:ShadingType.CLEAR}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"{_js_str(user_action)}",size:20,font:"Arial"}})]}})]}}),
          ]}}),
          new TableRow({{ children: [
            new TableCell({{ width:{{size:2000,type:WidthType.DXA}},
              shading:{{fill:"00467F",type:ShadingType.CLEAR}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"Model / System",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
            new TableCell({{ width:{{size:12400,type:WidthType.DXA}}, borders, margins,
              children:[new Paragraph({{children:[new TextRun({{text:"SAP BPC / EPM  |  Model: BMAIN  |  Version: 1.1",size:20,font:"Arial"}})]}})]}}),
          ]}}),
        ]
      }}),

      new Paragraph({{ spacing: {{ before: 200, after: 100 }},
        children: [new TextRun({{ text: "", size: 4 }})] }}),

      // ── Screenshot ───────────────────────────────────────────────────────
      new Paragraph({{ heading: HeadingLevel.HEADING_2,
        children: [new TextRun({{ text: "1.  Report Layout Screenshot", bold: true, font: "Arial" }})] }}),

      new Paragraph({{ children: [
        new TextRun({{ text: "The image below shows the actual report structure as it appears in the BPC EPM Excel interface.",
          size: 20, font: "Arial", color: "444444" }})
      ]}}),

      new Paragraph({{ spacing: {{ before: 100, after: 100 }},
        children: [
          new ImageRun({{
            data: imgData,
            transformation: {{ width: Math.round({emu_w}/9525), height: Math.round({emu_h}/9525) }},
            type: "png",
          }})
        ]
      }}),

      new Paragraph({{ spacing: {{ before: 200, after: 100 }},
        children: [new TextRun({{ text: "", size: 4 }})] }}),

      // ── Dimensions ───────────────────────────────────────────────────────
      new Paragraph({{ heading: HeadingLevel.HEADING_2,
        children: [new TextRun({{ text: "2.  Dimensions", bold: true, font: "Arial" }})] }}),

      new Paragraph({{ children: [new TextRun({{
        text: "All dimensions used in this report, including display format, sorting, hierarchies, properties and business rules.",
        size: 20, font: "Arial", color: "444444"
      }})]}}),

      new Paragraph({{ spacing: {{ before: 80 }}, children: [new TextRun({{ text: "" }})] }}),

      new Table({{
        width: {{ size: 14400, type: WidthType.DXA }},
        columnWidths: [1800, 1600, 1200, 1400, 1400, 1960],  // sums to 9360 (scaled)
        rows: [
          new TableRow({{
            tableHeader: true,
            children: [
              new TableCell({{ width:{{size:1800,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Dimension",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1600,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Display Format (Key ID/Text)",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1200,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Sorting",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1400,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Hierarchies",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1400,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Properties",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1960,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Business Rules",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
            ]
          }}),
          {dim_rows_js(dimensions)}
        ]
      }}),

      new Paragraph({{ spacing: {{ before: 200, after: 100 }},
        children: [new TextRun({{ text: "", size: 4 }})] }}),

      // ── Measures / KPIs ──────────────────────────────────────────────────
      new Paragraph({{ heading: HeadingLevel.HEADING_2,
        children: [new TextRun({{ text: "3.  Measures / KPIs & Business Rules", bold: true, font: "Arial" }})] }}),

      new Paragraph({{ children: [new TextRun({{
        text: "Each measure below includes its calculation formula, validation rule, tolerance, and business logic.",
        size: 20, font: "Arial", color: "444444"
      }})]}}),

      new Paragraph({{ spacing: {{ before: 80 }}, children: [new TextRun({{ text: "" }})] }}),

      new Table({{
        width: {{ size: 14400, type: WidthType.DXA }},
        columnWidths: [900, 2200, 1800, 1800, 600, 1260, 600],
        rows: [
          new TableRow({{
            tableHeader: true,
            children: [
              new TableCell({{ width:{{size:900,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Code",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:2200,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Description",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1800,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Check Formula",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1800,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Validation Formula",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:600,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Tolerance",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:1260,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Account",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
              new TableCell({{ width:{{size:600,type:WidthType.DXA}},
                shading:{{fill:"0070C0",type:ShadingType.CLEAR}}, borders, margins,
                children:[new Paragraph({{children:[new TextRun({{text:"Flow",bold:true,size:20,color:"FFFFFF",font:"Arial"}})]}})]}}) ,
            ]
          }}),
          {meas_rows_js(measures)}
        ]
      }}),

      // ── Business Logic notes ─────────────────────────────────────────────
      new Paragraph({{ spacing: {{ before: 200, after: 80 }},
        heading: HeadingLevel.HEADING_3,
        children: [new TextRun({{ text: "Detailed Business Logic Notes", bold: true, font: "Arial" }})] }}),

      {''.join(f"""
      new Paragraph({{ spacing: {{ before: 60, after: 40 }},
        children: [
          new TextRun({{ text: "{_js_str(m.code)} — ", bold: true, size: 20, font: "Arial", color: "0070C0" }}),
          new TextRun({{ text: "{_js_str(m.description)}: ", bold: true, size: 20, font: "Arial" }}),
          new TextRun({{ text: "{_js_str(m.business_logic)}", size: 20, font: "Arial" }}),
        ]
      }}),""" for m in measures if m.business_logic)}

    ]
  }}]
}});

Packer.toBuffer(doc).then(buf => {{
  fs.writeFileSync("{_js_str(out_path)}", buf);
  console.log("Created: {_js_str(out_path)}");
}}).catch(err => {{
  console.error("Error:", err);
  process.exit(1);
}});
"""
    return js


# ──────────────────────────────────────────────────────────────────────────────
# Main entry point
# ──────────────────────────────────────────────────────────────────────────────

def main(excel_path: str, output_dir: str = "/mnt/user-data/outputs"):
    os.makedirs(output_dir, exist_ok=True)
    wb = openpyxl.load_workbook(excel_path, data_only=False)
    print(f"Loaded: {excel_path}")

    reports = [
        {
            "sheet":      "Validations",
            "out":        os.path.join(output_dir, "Report1_Validations.docx"),
            "title":      "Report 1: Validations Report",
            "subtitle":   "BPC EPM — Data Validation by Entity (Assets, P&L, Movements)",
            "objective":  'Data validation by entity — "Assets vs Liabilities", "P&L Net Income vs BS Net Income", Balance movements, Error flows.',
            "action":     "Review and request the team to fix any validation highlighted in RED.",
            "extractor":  extract_validations,
            "renderer":   render_validations_screenshot,
        },
        {
            "sheet":      "Missing Seller %",
            "out":        os.path.join(output_dir, "Report2_Missing_Seller_Pct.docx"),
            "title":      "Report 2: Missing Seller Margin % Report",
            "subtitle":   "BPC EPM — V11006: Identifies entities with missing Stock Margin %",
            "objective":  "Shows only MISSING Stock Margin % (highlighted Red) for the selected entity. Covers Net Sales (SME_SALES), COGS (SME_COGS), and Margin % (SMEPercent).",
            "action":     "Review and request the team to update the missing Stock Margin % entries.",
            "extractor":  extract_seller,
            "renderer":   render_seller_screenshot,
        },
        {
            "sheet":      "Missing Buyer %",
            "out":        os.path.join(output_dir, "Report3_Missing_Buyer_Pct.docx"),
            "title":      "Report 3: Missing Buyer Allocation % Report",
            "subtitle":   "BPC EPM — V11007: Identifies entities with missing Buyer Allocation %",
            "objective":  "Shows Buyer % by entity and trading partner. Rows highlighted RED where Buyer % is missing. Covers all TP Purchase accounts (6701000101–6701000110).",
            "action":     "Review and request the team to update the missing Buyer % entries.",
            "extractor":  extract_buyer,
            "renderer":   render_buyer_screenshot,
        },
    ]

    for r in reports:
        sheet_name = r["sheet"]
        if sheet_name not in wb.sheetnames:
            print(f"  ⚠  Sheet '{sheet_name}' not found — skipping.")
            continue

        ws = wb[sheet_name]
        print(f"\n── Processing: {sheet_name} ──")

        # Render screenshot
        print("  Rendering screenshot…")
        img_path = r["renderer"](ws)
        print(f"  Screenshot: {img_path}")

        # Extract data
        print("  Extracting dimensions & measures…")
        dims, measures = r["extractor"](ws)
        print(f"  Dimensions: {len(dims)}  |  Measures: {len(measures)}")

        # Build JS
        js_code = build_docx_js(
            out_path    = r["out"],
            title       = r["title"],
            subtitle    = r["subtitle"],
            objective   = r["objective"],
            user_action = r["action"],
            screenshot_path = img_path,
            dimensions  = dims,
            measures    = measures,
        )

        js_path = f"/home/claude/gen_{sheet_name.replace(' ', '_').replace('%','pct')}.js"
        with open(js_path, "w") as f:
            f.write(js_code)

        # Run Node.js
        print(f"  Generating Word document…")
        result = subprocess.run(
            ["node", js_path],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            print(f"  ✗  Node.js error:\n{result.stderr[:500]}")
        else:
            print(f"  ✓  {result.stdout.strip()}")

    wb.close()
    print("\n══ Done! Files written to:", output_dir)
    for r in reports:
        if os.path.exists(r["out"]):
            size = os.path.getsize(r["out"])
            print(f"   {os.path.basename(r['out'])}  ({size//1024} KB)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 bpc_epm_report_generator.py <excel_file.xlsx> [output_dir]")
        sys.exit(1)
    excel = sys.argv[1]
    outdir = sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/outputs"
    main(excel, outdir)
