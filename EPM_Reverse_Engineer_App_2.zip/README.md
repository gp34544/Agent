# SAP EPM → SAC Report Specification Generator

Reverse-engineer SAP BPC/EPM Excel reports into structured Word specifications for SAC Planning migration.

## Quick Start

### 1. Prerequisites
- **Python 3.9+**
- **Node.js 18+** (required for Word doc generation) — https://nodejs.org

### 2. Setup (run once)
```bash
cd epm_reverse_engineer
python setup_and_run.py
```
This installs all dependencies (openpyxl, boto3, streamlit, docx npm package).

### 3. Run

**Option A — Streamlit UI:**
```bash
streamlit run app.py
```
Then upload your EPM workbook in the browser.

**Option B — Command Line:**
```bash
python run_cli.py <your_file.xlsx> [output_dir]
python run_cli.py Copy_of_Sample_Report_BPC_EPM.xlsx ./output
```

## What It Does

6 specialist agents analyze each **report sheet** (formatting sheets are auto-excluded):

| Agent | Extracts |
|---|---|
| DimensionAgent | BPC dimensions, hierarchies, display modes (Key ID/Text) |
| MeasureAgent | KPIs, measures, calculated members |
| FormulaAgent | EPM functions, local members, custom Excel formulas |
| FormattingAgent | Merged cells, layout info |
| ValidationAgent | Business rules, data quality checks, thresholds |
| SpecificationAgent | Assembles Word doc + migration summary |

## AWS Bedrock (Optional)

If AWS credentials are configured, agents call **Claude (Sonnet)** via Bedrock to:
- Explain business meaning of each dimension, measure, and validation
- Generate SAC Planning migration recommendations
- Produce executive summary with complexity assessment

Without Bedrock, the app works fine using rule-based extraction.

```bash
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=us-east-1
```

## Output

One `.docx` Word specification per report sheet containing:
- Dimensions table with SAC mapping
- Measures/KPIs with business meaning
- Validation rules with SAC implementation advice
- EPM functions catalog
- Local members with SAC recreation approach
- Custom formulas with explanations
- Cross-sheet references
- Migration summary & roadmap

## Files

| File | Purpose |
|---|---|
| `setup_and_run.py` | One-time setup — installs all dependencies |
| `run_cli.py` | Command-line runner |
| `app.py` | Streamlit web UI |
| `excel_parser.py` | Parses EPM workbooks |
| `agents.py` | 6 specialist agents + Bedrock LLM client |
| `doc_generator.py` | Generates Word documents via Node.js |

## Troubleshooting

| Issue | Fix |
|---|---|
| `ModuleNotFoundError: openpyxl` | `pip install openpyxl` |
| `Cannot find module 'docx'` | `npm install docx` (run in project folder) |
| `node: command not found` | Install Node.js from https://nodejs.org |
| `boto3 not installed` | `pip install boto3` (optional, for LLM features) |
| Word docs empty/broken | Check Node.js version: `node --version` (need 18+) |
