"""
setup_and_run.py
Run this FIRST to set up dependencies and verify everything works.
Usage: python setup_and_run.py
"""

import subprocess
import sys
import os
import shutil


def run_cmd(cmd, desc):
    print(f"\n{'='*60}")
    print(f"  {desc}")
    print(f"{'='*60}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  ❌ FAILED: {result.stderr[:300]}")
        return False
    print(f"  ✅ OK")
    return True


def main():
    print("\n" + "=" * 60)
    print("  SAP EPM → SAC Report Spec Generator - Setup")
    print("=" * 60)

    # Step 1: Python dependencies
    print("\n📦 Step 1: Installing Python dependencies...")
    run_cmd(f"{sys.executable} -m pip install openpyxl boto3 streamlit", "pip install openpyxl boto3 streamlit")

    # Step 2: Check Node.js
    print("\n📦 Step 2: Checking Node.js...")
    node_ok = run_cmd("node --version", "Node.js version")
    if not node_ok:
        print("\n  ❌ Node.js is NOT installed!")
        print("  Install from: https://nodejs.org/ (LTS version)")
        print("  Then re-run this script.")
        sys.exit(1)

    # Step 3: Install docx npm package LOCALLY
    print("\n📦 Step 3: Installing docx (Node.js) package locally...")
    project_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(project_dir)

    # Initialize package.json if not present
    if not os.path.exists(os.path.join(project_dir, "package.json")):
        run_cmd("npm init -y", "npm init")

    run_cmd("npm install docx", "npm install docx (local)")

    # Verify docx is importable
    verify = subprocess.run(
        ["node", "-e", "require('docx'); console.log('docx OK')"],
        capture_output=True, text=True, cwd=project_dir
    )
    if verify.returncode != 0:
        print(f"  ❌ docx module not found: {verify.stderr[:200]}")
        print("  Try: npm install -g docx")
        sys.exit(1)
    print("  ✅ docx module verified")

    # Step 4: Verify Python imports
    print("\n📦 Step 4: Verifying Python imports...")
    try:
        sys.path.insert(0, project_dir)
        import openpyxl
        print("  ✅ openpyxl OK")
    except ImportError:
        print("  ❌ openpyxl not found")

    try:
        import boto3
        print("  ✅ boto3 OK")
    except ImportError:
        print("  ⚠️  boto3 not found (LLM features will use fallback mode)")

    # Step 5: Check AWS credentials (optional)
    print("\n📦 Step 5: Checking AWS Bedrock access (optional)...")
    try:
        import boto3
        client = boto3.client("bedrock-runtime", region_name="us-east-1")
        print("  ✅ AWS credentials found")
        print("  ℹ️  LLM-powered analysis will be enabled")
    except Exception as e:
        print(f"  ⚠️  AWS Bedrock not configured: {str(e)[:100]}")
        print("  ℹ️  App will work fine using rule-based extraction (no LLM)")
        print("  ℹ️  To enable LLM: set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION")

    # Summary
    print("\n" + "=" * 60)
    print("  ✅ Setup Complete!")
    print("=" * 60)
    print(f"\n  To run the app:")
    print(f"    cd {project_dir}")
    print(f"    streamlit run app.py")
    print(f"\n  Or to run without Streamlit (CLI mode):")
    print(f"    python run_cli.py <your_epm_file.xlsx>")
    print()


if __name__ == "__main__":
    main()
