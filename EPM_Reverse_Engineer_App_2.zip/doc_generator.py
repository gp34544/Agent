"""
doc_generator.py
Generates Word (.docx) specification documents from agent output.
Uses docx-js (Node.js) for high-quality document creation.

IMPORTANT: Requires Node.js and the 'docx' npm package.
  Install: npm install docx  (run in this project directory)
"""

import json
import subprocess
import os
import sys
import tempfile
from typing import Dict, Any


# ── Resolve project directory (where node_modules lives) ──
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))


def generate_docx(spec: Dict[str, Any], output_path: str) -> str:
    """Generate a .docx specification document for a single sheet."""

    # Use OS-appropriate temp directory
    tmp_dir = tempfile.gettempdir()
    json_path = os.path.join(tmp_dir, "spec_data.json")
    js_path = os.path.join(tmp_dir, "generate_doc.js")

    # Ensure output directory exists
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    # Write spec to temp JSON
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(spec, f, default=str)

    # Build and write the JS script
    # CRITICAL: Use forward slashes in JS even on Windows
    json_path_js = json_path.replace("\\", "/")
    output_path_js = os.path.abspath(output_path).replace("\\", "/")

    js_script = _build_js_script(json_path_js, output_path_js)
    with open(js_path, "w", encoding="utf-8") as f:
        f.write(js_script)

    # Run Node.js from the project directory (so it finds node_modules/docx)
    try:
        result = subprocess.run(
            ["node", js_path],
            capture_output=True, text=True, timeout=60,
            cwd=PROJECT_DIR,  # ← THIS IS THE KEY FIX: run from project dir
        )
    except FileNotFoundError:
        raise RuntimeError(
            "Node.js not found! Install from https://nodejs.org/\n"
            "Then run: npm install docx (in project directory)"
        )

    if result.returncode != 0:
        error_msg = result.stderr[:500] if result.stderr else "Unknown error"
        # Check for common issues
        if "Cannot find module" in error_msg and "docx" in error_msg:
            raise RuntimeError(
                f"Node.js 'docx' module not found!\n"
                f"Fix: cd {PROJECT_DIR} && npm install docx\n"
                f"Original error: {error_msg}"
            )
        raise RuntimeError(f"docx generation failed:\n{error_msg}")

    return output_path


def _build_js_script(json_path: str, output_path: str) -> str:
    return '''
const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
  PageBreak, LevelFormat, Header, Footer, PageNumber
} = require("docx");

const spec = JSON.parse(fs.readFileSync("''' + json_path + '''", "utf-8"));

// ── Helpers ──
const border = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const borders = { top: border, bottom: border, left: border, right: border };
const headerBg = { fill: "2E5090", type: ShadingType.CLEAR };
const altRowBg = { fill: "F2F6FC", type: ShadingType.CLEAR };
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };

function headerCell(text, width) {
  return new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: headerBg, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text, bold: true, color: "FFFFFF", font: "Arial", size: 20 })] })]
  });
}

function dataCell(text, width, shading) {
  const opts = { borders, width: { size: width, type: WidthType.DXA }, margins: cellMargins,
    children: [new Paragraph({ children: [new TextRun({ text: String(text || ""), font: "Arial", size: 18 })] })] };
  if (shading) opts.shading = shading;
  return new TableCell(opts);
}

function sectionHeading(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 150 },
    children: [new TextRun({ text, bold: true, font: "Arial", size: 28, color: "2E5090" })] });
}

function bodyText(text) {
  return new Paragraph({ spacing: { after: 100 },
    children: [new TextRun({ text: String(text || ""), font: "Arial", size: 20 })] });
}

function emptyLine() {
  return new Paragraph({ spacing: { after: 80 }, children: [] });
}

// ── Build Document ──
const children = [];

// Title
children.push(new Paragraph({
  heading: HeadingLevel.HEADING_1, spacing: { after: 200 },
  children: [new TextRun({ text: "Report Specification", bold: true, font: "Arial", size: 36, color: "2E5090" })]
}));

// Meta info table
const metaCols = [3000, 6360];
children.push(new Table({
  width: { size: 9360, type: WidthType.DXA }, columnWidths: metaCols,
  rows: [
    new TableRow({ children: [headerCell("Field", 3000), headerCell("Value", 6360)] }),
    new TableRow({ children: [dataCell("Workbook Name", 3000), dataCell(spec.workbook_name, 6360)] }),
    new TableRow({ children: [dataCell("Sheet/Report Name", 3000, altRowBg), dataCell(spec.sheet_name, 6360, altRowBg)] }),
    new TableRow({ children: [dataCell("Report Objective", 3000), dataCell(spec.report_objective, 6360)] }),
    new TableRow({ children: [dataCell("User Action", 3000, altRowBg), dataCell(spec.user_action, 6360, altRowBg)] }),
  ]
}));
children.push(emptyLine());

// ── Section 1: Dimensions ──
children.push(sectionHeading("1. Dimensions"));
const dims = spec.dimensions || {};
const dimKeys = Object.keys(dims);
if (dimKeys.length > 0) {
  const dimCols = [1500, 1500, 1800, 1000, 1800, 1760];
  const dimRows = [
    new TableRow({ children: [
      headerCell("Dimension", 1500), headerCell("Hierarchies", 1500),
      headerCell("Members", 1800), headerCell("Display", 1000),
      headerCell("Business Purpose", 1800), headerCell("SAC Mapping", 1760)
    ] })
  ];
  dimKeys.forEach((key, i) => {
    const d = dims[key];
    const bg = i % 2 === 1 ? altRowBg : undefined;
    dimRows.push(new TableRow({ children: [
      dataCell(d.name, 1500, bg),
      dataCell((d.hierarchies || []).join(", "), 1500, bg),
      dataCell((d.members || []).slice(0, 4).join(", "), 1800, bg),
      dataCell(d.display_mode || "Key ID", 1000, bg),
      dataCell(d.business_purpose || "", 1800, bg),
      dataCell(d.sac_mapping || "", 1760, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: dimCols, rows: dimRows }));
} else {
  children.push(bodyText("No BPC dimensions detected in this sheet."));
}
children.push(emptyLine());

// ── Section 2: Measures/KPIs ──
children.push(sectionHeading("2. Measures / KPIs"));
const measures = spec.measures || [];
if (measures.length > 0) {
  const mCols = [1200, 1400, 2400, 2000, 2360];
  const mRows = [
    new TableRow({ children: [
      headerCell("Name", 1200), headerCell("Type", 1400),
      headerCell("Description", 2400), headerCell("Business Meaning", 2000),
      headerCell("SAC Equivalent", 2360)
    ] })
  ];
  measures.slice(0, 30).forEach((m, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    const desc = m.description || m.formula || m.check_formula || "";
    mRows.push(new TableRow({ children: [
      dataCell(m.name, 1200, bg), dataCell(m.type, 1400, bg),
      dataCell(String(desc).substring(0, 120), 2400, bg),
      dataCell(m.business_meaning || "", 2000, bg),
      dataCell(m.sac_equivalent || "", 2360, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: mCols, rows: mRows }));
} else {
  children.push(bodyText("No measures or KPIs detected in this sheet."));
}
children.push(emptyLine());

// ── Section 3: Validations ──
children.push(sectionHeading("3. Business Rules / Validations"));
const vals = spec.validations || [];
if (vals.length > 0) {
  const vCols = [1000, 2200, 1200, 2500, 2460];
  const vRows = [
    new TableRow({ children: [
      headerCell("Rule ID", 1000), headerCell("Description", 2200),
      headerCell("Type", 1200), headerCell("Importance", 2500),
      headerCell("SAC Implementation", 2460)
    ] })
  ];
  vals.forEach((v, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    vRows.push(new TableRow({ children: [
      dataCell(v.id, 1000, bg), dataCell(v.description, 2200, bg),
      dataCell(v.rule_type, 1200, bg),
      dataCell(v.importance || "", 2500, bg),
      dataCell(v.sac_implementation || "", 2460, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: vCols, rows: vRows }));
} else {
  children.push(bodyText("No validation rules detected in this sheet."));
}
children.push(emptyLine());

// ── Section 4: EPM Functions ──
children.push(sectionHeading("4. EPM Functions Used"));
const epmFuncs = spec.epm_functions || {};
const epmKeys = Object.keys(epmFuncs);
if (epmKeys.length > 0) {
  const eCols = [3000, 3800, 1000, 1560];
  const eRows = [
    new TableRow({ children: [
      headerCell("Function", 3000), headerCell("Description", 3800),
      headerCell("Count", 1000), headerCell("Sample Cell", 1560)
    ] })
  ];
  epmKeys.forEach((key, i) => {
    const e = epmFuncs[key];
    const bg = i % 2 === 1 ? altRowBg : undefined;
    eRows.push(new TableRow({ children: [
      dataCell(e.function, 3000, bg), dataCell(e.description, 3800, bg),
      dataCell(String(e.usage_count), 1000, bg),
      dataCell((e.sample_cells || []).join(", "), 1560, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: eCols, rows: eRows }));
} else {
  children.push(bodyText("No EPM functions detected in this sheet."));
}
children.push(emptyLine());

// ── Section 5: Local Members ──
children.push(sectionHeading("5. EPM Local Members (Calculated Members)"));
const localMembers = spec.local_members || [];
if (localMembers.length > 0) {
  const lCols = [1500, 800, 2500, 2000, 2560];
  const lRows = [
    new TableRow({ children: [
      headerCell("Name", 1500), headerCell("ID", 800),
      headerCell("Business Logic", 2500), headerCell("SAC Recreation", 2000),
      headerCell("Cell", 2560)
    ] })
  ];
  localMembers.forEach((lm, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    lRows.push(new TableRow({ children: [
      dataCell(lm.name, 1500, bg), dataCell(lm.id, 800, bg),
      dataCell(lm.business_logic || "", 2500, bg),
      dataCell(lm.sac_recreation || "", 2000, bg),
      dataCell(lm.cell, 2560, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: lCols, rows: lRows }));
} else {
  children.push(bodyText("No EPM Local Members detected in this sheet."));
}
children.push(emptyLine());

// ── Section 6: Custom Formulas ──
children.push(sectionHeading("6. Custom Excel Formulas"));
const customFormulas = spec.custom_formulas || [];
if (customFormulas.length > 0) {
  const fCols = [1000, 1400, 3600, 3360];
  const fRows = [
    new TableRow({ children: [
      headerCell("Cell", 1000), headerCell("Type", 1400),
      headerCell("Formula", 3600), headerCell("Explanation", 3360)
    ] })
  ];
  customFormulas.slice(0, 25).forEach((cf, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    fRows.push(new TableRow({ children: [
      dataCell(cf.cell, 1000, bg), dataCell(cf.type, 1400, bg),
      dataCell(String(cf.formula).substring(0, 150), 3600, bg),
      dataCell(cf.explanation || "", 3360, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: fCols, rows: fRows }));
} else {
  children.push(bodyText("No significant custom formulas detected."));
}
children.push(emptyLine());

// ── Section 7: Cross-Sheet References ──
children.push(sectionHeading("7. Cross-Sheet References"));
const crossRefs = spec.cross_sheet_references || [];
if (crossRefs.length > 0) {
  const crCols = [1500, 2200, 5660];
  const crRows = [
    new TableRow({ children: [
      headerCell("From Cell", 1500), headerCell("Target Sheet", 2200), headerCell("Formula", 5660)
    ] })
  ];
  crossRefs.slice(0, 15).forEach((cr, i) => {
    const bg = i % 2 === 1 ? altRowBg : undefined;
    crRows.push(new TableRow({ children: [
      dataCell(cr.from_cell, 1500, bg), dataCell(cr.target_sheet, 2200, bg),
      dataCell(String(cr.formula).substring(0, 180), 5660, bg),
    ] }));
  });
  children.push(new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: crCols, rows: crRows }));
} else {
  children.push(bodyText("No cross-sheet references detected."));
}

// ── Section 8: Migration Summary ──
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(sectionHeading("8. SAC Planning Migration Summary"));

const ms = spec.migration_summary || {};
if (ms.executive_summary) {
  children.push(bodyText("Executive Summary: " + ms.executive_summary));
  children.push(emptyLine());
  children.push(bodyText("Complexity: " + (ms.complexity || "N/A") + " - " + (ms.complexity_justification || "")));
  children.push(emptyLine());

  if (ms.migration_steps && ms.migration_steps.length > 0) {
    children.push(bodyText("Migration Steps:"));
    ms.migration_steps.forEach((step, i) => {
      children.push(bodyText("  " + (i + 1) + ". " + step));
    });
    children.push(emptyLine());
  }

  if (ms.risks && ms.risks.length > 0) {
    children.push(bodyText("Key Risks:"));
    ms.risks.forEach(r => { children.push(bodyText("  - " + r)); });
  }
} else if (spec.migration_summary_narrative) {
  children.push(bodyText(spec.migration_summary_narrative));
} else {
  children.push(bodyText("Migration summary not available. Enable AWS Bedrock for LLM-powered analysis."));
}

// ── Build Doc ──
const doc = new Document({
  styles: {
    default: { document: { run: { font: "Arial", size: 20 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 240, after: 200 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: "2E5090" },
        paragraph: { spacing: { before: 200, after: 150 }, outlineLevel: 1 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "SAP EPM to SAC Migration - Report Specification", italics: true, font: "Arial", size: 16, color: "888888" })]
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "Page ", font: "Arial", size: 16 }),
            new TextRun({ children: [PageNumber.CURRENT], font: "Arial", size: 16 }),
          ]
        })]
      })
    },
    children
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("''' + output_path + '''", buffer);
  console.log("OK");
}).catch(err => {
  console.error("Error:", err.message || err);
  process.exit(1);
});
'''


def generate_all_specs(all_specs: Dict[str, Dict], output_dir: str) -> Dict[str, str]:
    """Generate a Word doc for each sheet specification."""
    os.makedirs(output_dir, exist_ok=True)
    generated = {}

    for sheet_name, spec in all_specs.items():
        safe_name = sheet_name.replace(" ", "_").replace("%", "Pct").replace("/", "_")
        output_path = os.path.join(output_dir, f"Spec_{safe_name}.docx")
        try:
            generate_docx(spec, output_path)
            generated[sheet_name] = output_path
            print(f"  ✅ {sheet_name}: {output_path}")
        except Exception as e:
            generated[sheet_name] = f"ERROR: {e}"
            print(f"  ❌ {sheet_name}: {e}")

    return generated
