"""
excel_parser.py
Parses SAP BPC/EPM Excel workbooks and extracts raw cell data, formulas,
merged cells, and structural information for downstream agents.
"""

import openpyxl
from openpyxl.utils import get_column_letter
import re
from dataclasses import dataclass, field
from typing import List, Dict, Any


@dataclass
class CellInfo:
    address: str
    value: Any
    is_formula: bool = False
    formula_text: str = ""
    sheet_name: str = ""


@dataclass
class SheetData:
    name: str
    max_row: int
    max_col: int
    cells: List[CellInfo] = field(default_factory=list)
    merged_ranges: List[str] = field(default_factory=list)
    formula_cells: List[CellInfo] = field(default_factory=list)
    epm_cells: List[CellInfo] = field(default_factory=list)


@dataclass
class WorkbookData:
    filename: str
    sheet_names: List[str] = field(default_factory=list)
    sheets: Dict[str, SheetData] = field(default_factory=dict)


def parse_workbook(filepath: str) -> WorkbookData:
    """Parse an EPM workbook and return structured data."""
    wb = openpyxl.load_workbook(filepath, data_only=False)
    workbook_data = WorkbookData(filename=filepath.split("/")[-1].split("\\")[-1])
    workbook_data.sheet_names = wb.sheetnames

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        sheet = SheetData(
            name=sheet_name,
            max_row=ws.max_row or 0,
            max_col=ws.max_column or 0,
            merged_ranges=[str(r) for r in ws.merged_cells.ranges],
        )
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=ws.max_column):
            for cell in row:
                val = cell.value
                if val is None:
                    continue
                addr = f"{get_column_letter(cell.column)}{cell.row}"
                val_str = str(val)
                is_formula = val_str.startswith("=")
                has_epm = "_xll." in val_str or "EPM" in val_str
                cell_info = CellInfo(
                    address=addr, value=val, is_formula=is_formula,
                    formula_text=val_str if is_formula else "", sheet_name=sheet_name,
                )
                sheet.cells.append(cell_info)
                if is_formula:
                    sheet.formula_cells.append(cell_info)
                if has_epm:
                    sheet.epm_cells.append(cell_info)
        workbook_data.sheets[sheet_name] = sheet

    wb.close()
    return workbook_data


def get_epm_functions(workbook_data: WorkbookData) -> Dict[str, List[str]]:
    """Extract all unique EPM functions used per sheet."""
    result = {}
    pattern = re.compile(r"_xll\.[\w.]+")
    for name, sheet in workbook_data.sheets.items():
        funcs = set()
        for cell in sheet.epm_cells:
            matches = pattern.findall(str(cell.value))
            funcs.update(matches)
        if funcs:
            result[name] = sorted(funcs)
    return result
