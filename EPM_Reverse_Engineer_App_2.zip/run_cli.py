"""
run_cli.py
Command-line runner for EPM reverse engineering.
Usage: python run_cli.py <path_to_epm_file.xlsx> [output_dir]
"""

import sys
import os
import logging
import zipfile

# Fix imports: add this script's directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from excel_parser import parse_workbook
from agents import Orchestrator
from doc_generator import generate_all_specs


def main():
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

    if len(sys.argv) < 2:
        print("Usage: python run_cli.py <path_to_epm_file.xlsx> [output_dir]")
        print("Example: python run_cli.py my_report.xlsx ./output")
        sys.exit(1)

    input_file = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "./output"

    if not os.path.exists(input_file):
        print(f"❌ File not found: {input_file}")
        sys.exit(1)

    # Step 1: Parse
    print(f"\n📂 Parsing: {input_file}")
    wb = parse_workbook(input_file)
    print(f"   Found {len(wb.sheet_names)} sheets: {wb.sheet_names}")

    # Step 2: Run agents (only report sheets)
    print(f"\n🤖 Running agents...")
    orchestrator = Orchestrator()
    all_specs = orchestrator.process_workbook(wb)
    print(f"   Generated {len(all_specs)} report specifications")

    # Step 3: Generate Word docs
    print(f"\n📄 Generating Word documents in: {output_dir}")
    generated = generate_all_specs(all_specs, output_dir)

    # Step 4: Create ZIP
    success = {k: v for k, v in generated.items() if not str(v).startswith("ERROR")}
    if success:
        zip_path = os.path.join(output_dir, "All_Report_Specifications.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for name, path in success.items():
                zf.write(path, os.path.basename(path))
        print(f"\n📦 ZIP: {zip_path}")

    print(f"\n✅ Done! {len(success)}/{len(generated)} specifications generated.")


if __name__ == "__main__":
    main()
