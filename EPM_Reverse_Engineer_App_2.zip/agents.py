"""
agents.py
Agent-based architecture for reverse engineering SAP BPC/EPM reports.
Each agent uses Claude (via AWS Bedrock) to intelligently interpret
extracted EPM artifacts and produce business-meaningful specifications.

Architecture mirrors Google ADK pattern:
  - Each agent has a name, description, and run() method
  - Each agent calls Claude via Bedrock for intelligent interpretation
  - Orchestrator coordinates agents, filters formatting sheets, assembles results

Requirements:
  pip install boto3 openpyxl
  AWS credentials configured (env vars, ~/.aws/credentials, or IAM role)
"""

import re
import json
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from excel_parser import WorkbookData, SheetData, CellInfo

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Bedrock LLM Client
# ─────────────────────────────────────────────

class BedrockLLMClient:
    """
    Wrapper for calling Claude on AWS Bedrock.
    Handles initialization, retries, and fallback if Bedrock is unavailable.
    """

    # Update this to your preferred Claude model on Bedrock
    DEFAULT_MODEL_ID = "anthropic.claude-sonnet-4-20250514-v1:0"

    def __init__(self, region_name: str = "us-east-1", model_id: str = None):
        self.model_id = model_id or self.DEFAULT_MODEL_ID
        self.region_name = region_name
        self.client = None
        self.available = False
        self._init_client()

    def _init_client(self):
        """Initialize Bedrock runtime client. Gracefully handles missing credentials."""
        try:
            import boto3
            self.client = boto3.client(
                service_name="bedrock-runtime",
                region_name=self.region_name,
            )
            self.available = True
            logger.info(f"Bedrock client initialized: model={self.model_id}, region={self.region_name}")
        except ImportError:
            logger.warning("boto3 not installed. Install with: pip install boto3")
            self.available = False
        except Exception as e:
            logger.warning(f"Bedrock client init failed: {e}. Agents will use fallback mode.")
            self.available = False

    def invoke(self, system_prompt: str, user_prompt: str, max_tokens: int = 2048) -> str:
        """
        Call Claude via Bedrock. Returns response text.
        Falls back to empty string if Bedrock is unavailable.
        """
        if not self.available:
            return ""

        try:
            body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": max_tokens,
                "system": system_prompt,
                "messages": [
                    {"role": "user", "content": user_prompt}
                ],
            })

            response = self.client.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=body,
            )

            response_body = json.loads(response["body"].read())
            return response_body.get("content", [{}])[0].get("text", "")

        except Exception as e:
            logger.error(f"Bedrock invocation failed: {e}")
            return ""


# ─────────────────────────────────────────────
# Base Agent
# ─────────────────────────────────────────────

@dataclass
class AgentResult:
    agent_name: str
    sheet_name: str
    data: Dict[str, Any] = field(default_factory=dict)


class BaseAgent:
    """Base class for all agents with LLM access."""
    name: str = "BaseAgent"
    description: str = "Base agent"

    def __init__(self, llm: BedrockLLMClient):
        self.llm = llm

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        raise NotImplementedError

    def _ask_llm(self, system_prompt: str, user_prompt: str, max_tokens: int = 2048) -> str:
        """Call LLM with fallback handling."""
        return self.llm.invoke(system_prompt, user_prompt, max_tokens)

    def _parse_llm_json(self, llm_response: str) -> Any:
        """Safely parse LLM response as JSON, handling markdown fences."""
        if not llm_response:
            return None
        cleaned = llm_response.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r'^```\w*\n?', '', cleaned)
            cleaned = re.sub(r'\n?```$', '', cleaned)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            return None


# ─────────────────────────────────────────────
# Agent 1: Dimension Agent
# ─────────────────────────────────────────────

class DimensionAgent(BaseAgent):
    """Extracts dimensions, hierarchies, display modes and uses LLM for SAC mapping."""
    name = "DimensionAgent"
    description = "Extracts BPC dimensions, hierarchies, and display settings"

    KNOWN_DIMENSIONS = [
        "ENTITY", "ACCOUNT", "CATEGORY", "TIME", "TPARTNER",
        "BFLOW", "FLOW", "MODEL", "DATASRC", "CURRENCY",
        "MEASURES", "INTCO", "AUDIT_TRAIL",
    ]

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        dimensions = {}

        # Pattern 1: EPMOlapMemberO
        olap_pattern = re.compile(
            r'EPMOlapMemberO\(\s*"?\[(\w+)\]\.\[(\w+)\]\.\[([^\]]+)\]"?'
        )
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in olap_pattern.finditer(val):
                dim_name, hierarchy, member = match.group(1), match.group(2), match.group(3)
                if dim_name not in dimensions:
                    dimensions[dim_name] = {
                        "name": dim_name, "hierarchies": set(),
                        "members": [], "display_mode": "Key ID",
                        "sorting": "Not specified", "cell_references": [],
                    }
                dimensions[dim_name]["hierarchies"].add(hierarchy)
                dimensions[dim_name]["members"].append(member)
                dimensions[dim_name]["cell_references"].append(cell.address)

        # Pattern 2: EPMContextMember
        ctx_pattern = re.compile(r'EPMContextMember\(\s*"?(\$?\w+\$?\w*)"?,\s*(\w+)\)')
        for cell in sheet.epm_cells:
            for match in ctx_pattern.finditer(str(cell.value)):
                dim_name = match.group(2)
                if dim_name in self.KNOWN_DIMENSIONS and dim_name not in dimensions:
                    dimensions[dim_name] = {
                        "name": dim_name, "hierarchies": set(),
                        "members": [], "display_mode": "Key ID",
                        "sorting": "Not specified", "cell_references": [cell.address],
                    }

        # Pattern 3: Explicit dimension labels
        for cell in sheet.cells:
            val = str(cell.value).strip().upper()
            if val in self.KNOWN_DIMENSIONS and val not in dimensions:
                dimensions[val] = {
                    "name": val, "hierarchies": set(), "members": [],
                    "display_mode": "Key ID", "sorting": "Not specified",
                    "cell_references": [cell.address],
                }

        # Check EPMMemberDesc for Text display
        for cell in sheet.epm_cells:
            val = str(cell.value)
            if "EPMMemberDesc" in val:
                for d in dimensions.values():
                    if any(ref in val for ref in d.get("cell_references", [])):
                        d["display_mode"] = "Key ID + Text"

        # Serialize sets, dedupe members, filter to known dims
        for d in dimensions.values():
            d["hierarchies"] = sorted(d["hierarchies"])
            d["members"] = list(dict.fromkeys(d["members"]))[:20]
        dimensions = {k: v for k, v in dimensions.items() if k in self.KNOWN_DIMENSIONS}

        # ── LLM: SAC mapping advice ──
        if dimensions:
            dim_summary = json.dumps(
                {k: {"hierarchies": v["hierarchies"], "members": v["members"][:5],
                     "display_mode": v["display_mode"]} for k, v in dimensions.items()},
                indent=2
            )
            llm_response = self._ask_llm(
                system_prompt="You are an SAP BPC/EPM expert helping migrate reports to SAC Planning. Respond only in JSON.",
                user_prompt=(
                    f"Sheet '{sheet.name}' uses these BPC dimensions:\n{dim_summary}\n\n"
                    "For each dimension provide: business_purpose (1 sentence), "
                    "hierarchy_usage (1 sentence), sac_mapping (specific SAC recommendation).\n"
                    "Return JSON object keyed by dimension name."
                ),
                max_tokens=1500,
            )
            enrichment = self._parse_llm_json(llm_response)
            if enrichment and isinstance(enrichment, dict):
                for dim_name, info in enrichment.items():
                    if dim_name in dimensions:
                        dimensions[dim_name]["business_purpose"] = info.get("business_purpose", "")
                        dimensions[dim_name]["hierarchy_usage"] = info.get("hierarchy_usage", "")
                        dimensions[dim_name]["sac_mapping"] = info.get("sac_mapping", "")
            elif llm_response:
                result.data["llm_dimension_analysis"] = llm_response

        result.data["dimensions"] = dimensions
        return result


# ─────────────────────────────────────────────
# Agent 2: Measure/KPI Agent
# ─────────────────────────────────────────────

class MeasureAgent(BaseAgent):
    """Extracts measures/KPIs and uses LLM to explain business meaning."""
    name = "MeasureAgent"
    description = "Extracts measures, KPIs with LLM business context"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        measures = []

        # OLAP Measures
        for cell in sheet.epm_cells:
            val = str(cell.value)
            if "[MEASURES]" in val:
                m = re.search(r'\[MEASURES\]\.\[\]\.\[(\w+)\]', val)
                if m:
                    measures.append({"name": m.group(1), "type": "OLAP Measure",
                                     "cell": cell.address, "formula": val})

        # EPMRetrieveData
        for cell in sheet.epm_cells:
            if "EPMRetrieveData" in str(cell.value):
                measures.append({"name": f"Retrieved Data at {cell.address}",
                                 "type": "EPM Data Retrieval",
                                 "cell": cell.address, "formula": str(cell.value)})

        # Validation KPIs
        for cell in sheet.cells:
            val = str(cell.value)
            if re.match(r'^V\d{4,6}$', val):
                row_num = int(re.search(r'\d+', cell.address).group())
                desc = self._find_cell_value(sheet, f"D{row_num}")
                check = self._find_cell_value(sheet, f"E{row_num}")
                vformula = self._find_cell_value(sheet, f"F{row_num}")
                measures.append({"name": val, "type": "Validation KPI", "cell": cell.address,
                                 "description": desc, "check_formula": check,
                                 "validation_formula": vformula})

        # Column header measures
        kw = ["net sales", "cost of goods", "margin", "revenue", "closing",
              "opening", "balance", "total", "ytd"]
        for cell in sheet.cells:
            val = str(cell.value).lower()
            if any(k in val for k in kw):
                row = int(re.search(r'\d+', cell.address).group())
                if row <= 30:
                    measures.append({"name": str(cell.value),
                                     "type": "Report Column/Measure", "cell": cell.address})

        # ── LLM: business meaning ──
        if measures:
            summary = [{"name": m["name"], "type": m["type"],
                        "description": m.get("description", ""),
                        "formula": m.get("formula", m.get("check_formula", ""))[:150]}
                       for m in measures[:20]]
            llm_response = self._ask_llm(
                system_prompt="You are an SAP BPC expert. Explain measures in financial consolidation context. JSON only.",
                user_prompt=(
                    f"Sheet '{sheet.name}' measures:\n{json.dumps(summary, indent=2)}\n\n"
                    "For each: business_meaning (1-2 sentences), calculation_logic (plain English), "
                    "sac_equivalent (calculated member/data action/formula).\n"
                    "Return JSON array with: name, business_meaning, calculation_logic, sac_equivalent"
                ),
                max_tokens=2000,
            )
            enrichment = self._parse_llm_json(llm_response)
            if enrichment and isinstance(enrichment, list):
                emap = {e["name"]: e for e in enrichment if "name" in e}
                for m in measures:
                    if m["name"] in emap:
                        e = emap[m["name"]]
                        m["business_meaning"] = e.get("business_meaning", "")
                        m["calculation_logic"] = e.get("calculation_logic", "")
                        m["sac_equivalent"] = e.get("sac_equivalent", "")
            elif llm_response:
                result.data["llm_measures_analysis"] = llm_response

        result.data["measures"] = measures
        return result

    def _find_cell_value(self, sheet: SheetData, address: str) -> str:
        for c in sheet.cells:
            if c.address == address:
                return str(c.value)[:200]
        return ""


# ─────────────────────────────────────────────
# Agent 3: Formula Agent
# ─────────────────────────────────────────────

class FormulaAgent(BaseAgent):
    """Extracts EPM formulas and uses LLM to explain complex logic."""
    name = "FormulaAgent"
    description = "Extracts EPM functions, local members with LLM explanations"

    EPM_DESCRIPTIONS = {
        "_xll.EPMOlapMemberO": "Retrieves OLAP member from BPC model with hierarchy placement",
        "_xll.EPMContextMember": "Gets current context member for a dimension",
        "_xll.EPMMemberDesc": "Returns the text description of a member ID",
        "_xll.EPMMemberProperty": "Retrieves a property value of a member",
        "_xll.EPMDimensionOverride": "Overrides dimension selection for specific report area",
        "_xll.EPMModelCubeID": "Returns the model/cube identifier",
        "_xll.EPMRetrieveData": "Retrieves data values from BPC model",
        "_xll.EPMReadOnlyData": "Marks data range as read-only",
        "_xll.FPMXLClient.TechnicalCategory.EPMLocalMember": "Defines a local calculated member",
    }

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)

        # EPM Functions
        epm_functions = {}
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in re.finditer(r'(_xll\.[\w.]+)', val):
                fn = match.group(1)
                if fn not in epm_functions:
                    epm_functions[fn] = {"function": fn, "description": self.EPM_DESCRIPTIONS.get(fn, "EPM function"),
                                         "usage_count": 0, "sample_cells": [], "sample_formulas": []}
                epm_functions[fn]["usage_count"] += 1
                if len(epm_functions[fn]["sample_cells"]) < 3:
                    epm_functions[fn]["sample_cells"].append(cell.address)
                    epm_functions[fn]["sample_formulas"].append(val[:200])

        # Local Members
        local_members = []
        lm_pattern = re.compile(r'EPMLocalMember\(\s*"([^"]*)",\s*"(\d+)",\s*"(\d+)"\s*\)')
        for cell in sheet.epm_cells:
            val = str(cell.value)
            for match in lm_pattern.finditer(val):
                local_members.append({"name": match.group(1), "id": match.group(2),
                                      "connection": match.group(3), "cell": cell.address,
                                      "full_formula": val[:200]})

        # Custom Formulas
        custom_formulas = []
        for cell in sheet.formula_cells:
            val = str(cell.value)
            if "_xll." not in val and val.startswith("="):
                if any(f in val.upper() for f in ["SUMIF", "VLOOKUP", "COUNTIF", "IF(", "IFERROR", "SUM(", "ABS("]):
                    ftype = "Conditional Aggregation" if any(x in val.upper() for x in ["SUMIF", "COUNTIF"]) \
                        else "Lookup" if any(x in val.upper() for x in ["VLOOKUP", "INDEX"]) \
                        else "Conditional Logic" if "IF(" in val.upper() \
                        else "Aggregation" if "SUM(" in val.upper() else "Calculation"
                    custom_formulas.append({"cell": cell.address, "formula": val[:300], "type": ftype})

        # Cross-sheet refs
        cross_refs = []
        for cell in sheet.formula_cells:
            val = str(cell.value)
            if "!" in val and "'" in val:
                for ref in re.findall(r"'([^']+)'!", val):
                    cross_refs.append({"from_cell": cell.address, "target_sheet": ref, "formula": val[:200]})

        # ── LLM: explain local members ──
        if local_members:
            lm_summary = [{"name": lm["name"], "id": lm["id"],
                           "formula": lm["full_formula"][:150]} for lm in local_members[:15]]
            llm_response = self._ask_llm(
                system_prompt="You are an SAP BPC expert. Explain Local Members and SAC equivalents. JSON only.",
                user_prompt=(
                    f"Sheet '{sheet.name}' local members:\n{json.dumps(lm_summary, indent=2)}\n\n"
                    "For each: business_logic (what it calculates), "
                    "sac_recreation (how to recreate in SAC: calculated member/restricted member/data action).\n"
                    "Return JSON array with: name, business_logic, sac_recreation"
                ),
                max_tokens=1500,
            )
            enrichment = self._parse_llm_json(llm_response)
            if enrichment and isinstance(enrichment, list):
                emap = {e["name"]: e for e in enrichment if "name" in e}
                for lm in local_members:
                    if lm["name"] in emap:
                        lm["business_logic"] = emap[lm["name"]].get("business_logic", "")
                        lm["sac_recreation"] = emap[lm["name"]].get("sac_recreation", "")
            elif llm_response:
                result.data["llm_local_member_analysis"] = llm_response

        # ── LLM: explain complex formulas ──
        complex = [f for f in custom_formulas if len(f["formula"]) > 50][:10]
        if complex:
            llm_response = self._ask_llm(
                system_prompt="You are an SAP BPC expert. Explain Excel formulas and SAC equivalents. JSON only.",
                user_prompt=(
                    f"Formulas in '{sheet.name}':\n{json.dumps(complex, indent=2)}\n\n"
                    "For each: explanation (plain English), sac_approach (SAC equivalent).\n"
                    "Return JSON array with: cell, explanation, sac_approach"
                ),
                max_tokens=1500,
            )
            enrichment = self._parse_llm_json(llm_response)
            if enrichment and isinstance(enrichment, list):
                emap = {e["cell"]: e for e in enrichment if "cell" in e}
                for cf in custom_formulas:
                    if cf["cell"] in emap:
                        cf["explanation"] = emap[cf["cell"]].get("explanation", "")
                        cf["sac_approach"] = emap[cf["cell"]].get("sac_approach", "")

        result.data["epm_functions"] = epm_functions
        result.data["local_members"] = local_members
        result.data["custom_formulas"] = custom_formulas[:50]
        result.data["cross_sheet_references"] = cross_refs
        return result


# ─────────────────────────────────────────────
# Agent 4: Formatting Agent (lightweight, no LLM)
# ─────────────────────────────────────────────

class FormattingAgent(BaseAgent):
    """Extracts layout info for report sheets (not formatting sheets)."""
    name = "FormattingAgent"
    description = "Extracts layout and merged cell info"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        result.data["merged_cells"] = sheet.merged_ranges
        result.data["is_formatting_sheet"] = False
        result.data["formatting_rules"] = []
        result.data["member_formats"] = []
        return result


# ─────────────────────────────────────────────
# Agent 5: Validation/Business Rule Agent
# ─────────────────────────────────────────────

class ValidationAgent(BaseAgent):
    """Extracts validations and uses LLM for business significance."""
    name = "ValidationAgent"
    description = "Extracts validation rules with LLM business interpretation"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        result = AgentResult(agent_name=self.name, sheet_name=sheet.name)
        validations = []

        for cell in sheet.cells:
            val = str(cell.value)
            if re.match(r'^V\d{4,6}$', val):
                row_num = int(re.search(r'\d+', cell.address).group())
                v = {"id": val, "description": "", "check_formula": "",
                     "validation_formula": "", "fs_item": "", "flow": "",
                     "tpartner": "", "threshold": "", "rule_type": "Restrictive"}
                for c in sheet.cells:
                    cr = int(re.search(r'\d+', c.address).group())
                    if cr != row_num: continue
                    col = re.match(r'[A-Z]+', c.address).group()
                    if col == "D": v["description"] = str(c.value)
                    elif col == "E": v["check_formula"] = str(c.value)[:200]
                    elif col == "F":
                        v["validation_formula"] = str(c.value)[:200]
                        t = re.findall(r'>(\d+)|<(-?\d+)', str(c.value))
                        if t: v["threshold"] = str(t)
                    elif col == "G": v["fs_item"] = str(c.value)[:100]
                    elif col == "H": v["flow"] = str(c.value)[:100]
                    elif col == "I": v["tpartner"] = str(c.value)[:100]

                desc = v["description"].lower()
                if "missing" in desc: v["rule_type"] = "Exception/Warning"
                elif "reverse" in desc or "negative" in desc: v["rule_type"] = "Data Quality Check"
                elif "=" in desc and any(w in desc for w in ["asset", "balance", "net income"]):
                    v["rule_type"] = "Balance Validation"
                elif "movement" in desc or "not equals" in desc:
                    v["rule_type"] = "Movement Reconciliation"
                validations.append(v)

        # ── LLM: business significance ──
        if validations:
            vs = [{"id": v["id"], "description": v["description"], "rule_type": v["rule_type"],
                   "check": v.get("check_formula", "")[:100]} for v in validations[:20]]
            llm_response = self._ask_llm(
                system_prompt="You are an SAP BPC consolidation expert. Explain validation significance. JSON only.",
                user_prompt=(
                    f"Sheet '{sheet.name}' validations:\n{json.dumps(vs, indent=2)}\n\n"
                    "For each: importance (why critical in consolidation), data_issue (what it catches), "
                    "sac_implementation (data action/allocation/input control).\n"
                    "Return JSON array with: id, importance, data_issue, sac_implementation"
                ),
                max_tokens=2500,
            )
            enrichment = self._parse_llm_json(llm_response)
            if enrichment and isinstance(enrichment, list):
                emap = {e["id"]: e for e in enrichment if "id" in e}
                for v in validations:
                    if v["id"] in emap:
                        e = emap[v["id"]]
                        v["importance"] = e.get("importance", "")
                        v["data_issue"] = e.get("data_issue", "")
                        v["sac_implementation"] = e.get("sac_implementation", "")
            elif llm_response:
                result.data["llm_validation_analysis"] = llm_response

        result.data["validations"] = validations
        result.data["exceptions"] = []
        result.data["report_objective"] = self._find_field(sheet, "report objective")
        result.data["user_action"] = self._find_field(sheet, "user action")
        return result

    def _find_field(self, sheet: SheetData, label: str) -> str:
        for cell in sheet.cells:
            if str(cell.value).strip().lower() == label:
                row = int(re.search(r'\d+', cell.address).group())
                for c in sheet.cells:
                    cr = int(re.search(r'\d+', c.address).group())
                    if cr == row and c.address != cell.address:
                        v = str(c.value)
                        if v.lower() != label: return v
        return "Not specified"


# ─────────────────────────────────────────────
# Agent 6: Specification Agent (LLM executive summary)
# ─────────────────────────────────────────────

class SpecificationAgent(BaseAgent):
    """Assembles all outputs and uses LLM for executive summary + migration roadmap."""
    name = "SpecificationAgent"
    description = "Assembles findings with LLM-powered migration summary"

    def run(self, sheet: SheetData, workbook: WorkbookData) -> AgentResult:
        return AgentResult(agent_name=self.name, sheet_name=sheet.name)

    def assemble(self, sheet_name, workbook_name, dim_result, measure_result,
                 formula_result, format_result, validation_result) -> Dict[str, Any]:

        dims = dim_result.data.get("dimensions", {})
        measures = measure_result.data.get("measures", [])
        vals = validation_result.data.get("validations", [])
        lms = formula_result.data.get("local_members", [])
        epms = formula_result.data.get("epm_functions", {})

        spec = {
            "workbook_name": workbook_name,
            "sheet_name": sheet_name,
            "report_objective": validation_result.data.get("report_objective", "N/A"),
            "user_action": validation_result.data.get("user_action", "N/A"),
            "dimensions": dims,
            "measures": measures,
            "epm_functions": epms,
            "local_members": lms,
            "custom_formulas": formula_result.data.get("custom_formulas", []),
            "cross_sheet_references": formula_result.data.get("cross_sheet_references", []),
            "formatting": {
                "is_formatting_sheet": False,
                "rules": format_result.data.get("formatting_rules", []),
                "member_formats": format_result.data.get("member_formats", []),
                "merged_cells": format_result.data.get("merged_cells", []),
            },
            "validations": vals,
            "exceptions": validation_result.data.get("exceptions", []),
        }

        # ── LLM: executive summary + migration roadmap ──
        si = {
            "sheet": sheet_name, "dims": list(dims.keys()),
            "num_measures": len(measures), "num_validations": len(vals),
            "num_local_members": len(lms), "epm_functions": list(epms.keys()),
            "objective": spec["report_objective"][:200],
        }
        llm_response = self._ask_llm(
            system_prompt="You are an SAP BPC to SAC migration expert. Provide migration analysis. JSON only.",
            user_prompt=(
                f"Analysis summary:\n{json.dumps(si, indent=2)}\n\n"
                "Generate: executive_summary (3-4 sentences), complexity (Low/Medium/High), "
                "complexity_justification, migration_steps (array of steps), risks (array).\n"
                "Return as JSON object."
            ),
            max_tokens=1500,
        )
        enrichment = self._parse_llm_json(llm_response)
        if enrichment and isinstance(enrichment, dict):
            spec["migration_summary"] = enrichment
        elif llm_response:
            spec["migration_summary_narrative"] = llm_response
        else:
            # Fallback template
            spec["migration_summary"] = {
                "executive_summary": (
                    f"Report '{sheet_name}' uses {len(dims)} dimensions, "
                    f"{len(measures)} measures, {len(vals)} validations, "
                    f"and {len(lms)} local members."
                ),
                "complexity": "Medium" if len(vals) < 15 else "High",
                "complexity_justification": "Based on validation count and EPM function complexity.",
                "migration_steps": [
                    "Create SAC model with equivalent dimensions",
                    "Map BPC hierarchies to SAC hierarchies",
                    "Recreate local members as SAC calculated members",
                    "Implement validations as SAC data actions",
                    "Build SAC story with equivalent layout",
                ],
                "risks": [
                    "EPM Local Members may need redesign",
                    "Cross-sheet logic needs consolidation",
                    "ActiveX controls have no SAC equivalent",
                ],
            }

        return spec


# ─────────────────────────────────────────────
# Orchestrator
# ─────────────────────────────────────────────

class Orchestrator:
    """
    Coordinates agents. Key behaviors:
    - Shared Bedrock LLM client for all agents
    - FILTERS OUT formatting sheets (only report/data sheets in output)
    """

    FORMATTING_PATTERNS = ["epmformat", "frmt_", "frmt ", "formatting"]

    def __init__(self, aws_region: str = "us-east-1", model_id: str = None):
        self.llm = BedrockLLMClient(region_name=aws_region, model_id=model_id)
        self.dim_agent = DimensionAgent(self.llm)
        self.measure_agent = MeasureAgent(self.llm)
        self.formula_agent = FormulaAgent(self.llm)
        self.format_agent = FormattingAgent(self.llm)
        self.validation_agent = ValidationAgent(self.llm)
        self.spec_agent = SpecificationAgent(self.llm)

    def is_formatting_sheet(self, name: str) -> bool:
        return any(p in name.lower().strip() for p in self.FORMATTING_PATTERNS)

    def process_workbook(self, workbook: WorkbookData) -> Dict[str, Dict]:
        """Run agents on REPORT sheets only. Formatting sheets are excluded."""
        all_specs = {}
        skipped = []

        for sheet_name, sheet in workbook.sheets.items():
            if self.is_formatting_sheet(sheet_name):
                skipped.append(sheet_name)
                logger.info(f"SKIP formatting sheet: {sheet_name}")
                continue

            logger.info(f"Processing report: {sheet_name}")
            dim_r = self.dim_agent.run(sheet, workbook)
            mea_r = self.measure_agent.run(sheet, workbook)
            for_r = self.formula_agent.run(sheet, workbook)
            fmt_r = self.format_agent.run(sheet, workbook)
            val_r = self.validation_agent.run(sheet, workbook)

            spec = self.spec_agent.assemble(
                sheet_name, workbook.filename,
                dim_r, mea_r, for_r, fmt_r, val_r,
            )
            all_specs[sheet_name] = spec

        logger.info(f"Done: {len(all_specs)} reports processed, {len(skipped)} formatting sheets skipped: {skipped}")
        return all_specs
