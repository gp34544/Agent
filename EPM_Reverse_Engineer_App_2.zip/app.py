"""
app.py
Streamlit frontend for SAP EPM Report Reverse Engineering Tool.
Upload an EPM Excel workbook -> get Word specification documents per sheet.

Run: streamlit run app.py
"""

import streamlit as st
import os
import sys
import zipfile
import tempfile

# ── Fix imports: ensure this script's directory is in Python path ──
APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from excel_parser import parse_workbook, get_epm_functions
from agents import Orchestrator
from doc_generator import generate_all_specs


# ── Page Config ──
st.set_page_config(
    page_title="SAP EPM → SAC Report Spec Generator",
    page_icon="📊",
    layout="wide",
)

st.markdown("""
<style>
    .metric-box {
        background: linear-gradient(135deg, #2E5090, #4A90D9);
        color: white; padding: 1.2rem; border-radius: 10px; text-align: center;
    }
    .metric-box h3 { color: white; margin: 0; font-size: 2rem; }
    .metric-box p { color: #ddd; margin: 0; font-size: 0.85rem; }
    .agent-card {
        background: #f8f9fa; border-left: 4px solid #2E5090;
        padding: 1rem; margin: 0.5rem 0; border-radius: 0 8px 8px 0;
    }
</style>
""", unsafe_allow_html=True)


# ── Header ──
st.markdown("## 📊 SAP EPM → SAC Report Specification Generator")
st.caption("Reverse-engineer SAP BPC/EPM Excel reports into structured specifications for SAC Planning migration")

# ── Sidebar ──
with st.sidebar:
    st.header("⚙️ How It Works")
    st.markdown("""
    **6 Specialized Agents** analyze your EPM workbook:

    1. **DimensionAgent** — BPC dimensions, hierarchies
    2. **MeasureAgent** — KPIs, measures, calculations
    3. **FormulaAgent** — EPM functions, local members
    4. **FormattingAgent** — Layout and merged cells
    5. **ValidationAgent** — Business rules, data checks
    6. **SpecificationAgent** — Assembles Word doc

    **Formatting sheets are automatically excluded.**
    """)
    st.divider()

    st.markdown("**AWS Bedrock (optional)**")
    aws_region = st.text_input("AWS Region", value="us-east-1")
    model_id = st.text_input("Model ID", value="anthropic.claude-sonnet-4-20250514-v1:0")
    st.caption("Leave defaults if no Bedrock access — app uses rule-based fallback.")

# ── File Upload ──
st.markdown("### 📁 Upload EPM Workbook")
uploaded_file = st.file_uploader(
    "Drop your SAP BPC/EPM Excel file here",
    type=["xlsx", "xlsm"],
)

if uploaded_file is not None:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    with st.spinner("🔍 Parsing workbook..."):
        workbook_data = parse_workbook(tmp_path)

    # ── Metrics ──
    st.markdown("---")
    st.markdown("### 📈 Workbook Overview")

    total_epm = sum(len(s.epm_cells) for s in workbook_data.sheets.values())
    epm_funcs = get_epm_functions(workbook_data)
    unique_funcs = set()
    for funcs in epm_funcs.values():
        unique_funcs.update(funcs)

    orchestrator = Orchestrator(aws_region=aws_region, model_id=model_id)
    report_sheets = [s for s in workbook_data.sheet_names if not orchestrator.is_formatting_sheet(s)]
    fmt_sheets = [s for s in workbook_data.sheet_names if orchestrator.is_formatting_sheet(s)]

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="metric-box"><h3>{len(report_sheets)}</h3><p>Report Sheets</p></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-box"><h3>{len(fmt_sheets)}</h3><p>Formatting (skipped)</p></div>', unsafe_allow_html=True)
    with c3:
        st.markdown(f'<div class="metric-box"><h3>{total_epm}</h3><p>EPM Cells</p></div>', unsafe_allow_html=True)
    with c4:
        st.markdown(f'<div class="metric-box"><h3>{len(unique_funcs)}</h3><p>EPM Functions</p></div>', unsafe_allow_html=True)

    # ── Sheet Selection ──
    st.markdown("---")
    st.markdown("### 📋 Report Sheets (formatting sheets auto-excluded)")

    if fmt_sheets:
        st.info(f"🔇 Auto-excluded formatting sheets: {', '.join(fmt_sheets)}")

    selected = st.multiselect("Select report sheets to process:", report_sheets, default=report_sheets)

    # ── Process ──
    st.markdown("---")
    if st.button("🚀 Generate Specifications", type="primary", use_container_width=True):
        if not selected:
            st.warning("Select at least one sheet.")
        else:
            filtered = {k: v for k, v in workbook_data.sheets.items() if k in selected}
            orig = workbook_data.sheets
            workbook_data.sheets = filtered

            with st.spinner("🤖 Running agents..."):
                all_specs = orchestrator.process_workbook(workbook_data)

            workbook_data.sheets = orig

            bedrock_status = "✅ LLM-enriched" if orchestrator.llm.available else "ℹ️ Rule-based (no Bedrock)"
            st.caption(f"Analysis mode: {bedrock_status}")

            output_dir = tempfile.mkdtemp()
            with st.spinner("📄 Generating Word documents..."):
                generated = generate_all_specs(all_specs, output_dir)

            # ── Results ──
            st.markdown("---")
            success = {k: v for k, v in generated.items() if not str(v).startswith("ERROR")}
            st.success(f"✅ Generated {len(success)} / {len(generated)} specifications")

            for name, path in generated.items():
                if str(path).startswith("ERROR"):
                    st.error(f"❌ {name}: {path}")
                else:
                    with open(path, "rb") as f:
                        safe = name.replace(" ", "_").replace("%", "Pct")
                        st.download_button(f"📄 {name}", f.read(), f"Spec_{safe}.docx",
                                           "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                           key=f"dl_{safe}")

            if len(success) > 1:
                st.markdown("---")
                zip_path = os.path.join(output_dir, "All_Specs.zip")
                with zipfile.ZipFile(zip_path, "w") as zf:
                    for name, path in success.items():
                        zf.write(path, f"Spec_{name.replace(' ', '_').replace('%', 'Pct')}.docx")
                with open(zip_path, "rb") as f:
                    st.download_button("📦 Download All (ZIP)", f.read(),
                                       "EPM_Report_Specifications.zip", "application/zip",
                                       type="primary", use_container_width=True)

            # ── Preview ──
            st.markdown("---")
            st.markdown("### 🔎 Preview")
            preview = st.selectbox("Sheet:", list(all_specs.keys()))
            if preview:
                spec = all_specs[preview]
                t1, t2, t3, t4, t5 = st.tabs(["Dimensions", "Measures", "EPM Functions", "Validations", "Local Members"])

                with t1:
                    for d in (spec.get("dimensions") or {}).values():
                        st.markdown(f'<div class="agent-card"><b>{d["name"]}</b> | {", ".join(d.get("hierarchies",[]))} | {d.get("display_mode","")}<br/>{d.get("business_purpose","")}</div>', unsafe_allow_html=True)

                with t2:
                    for m in (spec.get("measures") or [])[:15]:
                        st.markdown(f'<div class="agent-card"><b>{m["name"]}</b> ({m["type"]})<br/>{m.get("business_meaning", m.get("description",""))}</div>', unsafe_allow_html=True)

                with t3:
                    for ef in (spec.get("epm_functions") or {}).values():
                        st.markdown(f'<div class="agent-card"><b>{ef["function"]}</b> x{ef["usage_count"]}<br/>{ef["description"]}</div>', unsafe_allow_html=True)

                with t4:
                    for v in (spec.get("validations") or []):
                        st.markdown(f'<div class="agent-card"><b>{v["id"]}</b> [{v.get("rule_type","")}]<br/>{v["description"]}<br/><i>{v.get("importance","")}</i></div>', unsafe_allow_html=True)

                with t5:
                    for lm in (spec.get("local_members") or []):
                        st.markdown(f'<div class="agent-card"><b>{lm["name"] or "(unnamed)"}</b> (ID:{lm["id"]})<br/>{lm.get("business_logic","")}</div>', unsafe_allow_html=True)

    try:
        os.unlink(tmp_path)
    except:
        pass

else:
    st.markdown("---")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**Input:** SAP BPC/EPM Excel (.xlsx)")
    with c2:
        st.markdown("**Extracts:** Dimensions, KPIs, Validations, EPM functions, Local members")
    with c3:
        st.markdown("**Output:** One Word (.docx) spec per report sheet")
