#!/usr/bin/env python3
"""
SAP EPM Report Analyzer - Multi-Workbook Version
Generates separate analysis reports for each workbook (excluding formatting sheets)
in the template format with report layout screenshots
"""

import openpyxl
from openpyxl.utils import get_column_letter
import json
import os
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import io
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH


class ExcelExtractor:
    """Extract comprehensive details from Excel workbook"""
    
    def __init__(self, file_path):
        self.file_path = file_path
        self.workbook = openpyxl.load_workbook(file_path, data_only=False, keep_vba=True)
        self.data_wb = openpyxl.load_workbook(file_path, data_only=True)
        
    def is_formatting_sheet(self, sheet_name):
        """Check if sheet is a formatting sheet"""
        formatting_keywords = ['FRMT', 'FORMAT', 'FORMATTING', 'EPMFormatting', 'Instructions']
        return any(keyword.upper() in sheet_name.upper() for keyword in formatting_keywords)
    
    def get_workbook_sheets(self):
        """Get all non-formatting sheets grouped by workbook/report"""
        sheets_by_workbook = {}
        
        for sheet_name in self.workbook.sheetnames:
            if self.is_formatting_sheet(sheet_name):
                continue
                
            # Group sheets by prefix or put in default workbook
            if '_' in sheet_name:
                workbook_name = sheet_name.split('_')[0]
            else:
                workbook_name = 'Main Report'
            
            if workbook_name not in sheets_by_workbook:
                sheets_by_workbook[workbook_name] = []
            sheets_by_workbook[workbook_name].append(sheet_name)
        
        return sheets_by_workbook
    
    def extract_sheet_details(self, sheet_name):
        """Extract details from a specific sheet"""
        sheet = self.workbook[sheet_name]
        data_sheet = self.data_wb[sheet_name]
        
        sheet_info = {
            'name': sheet_name,
            'dimensions': f"{sheet.dimensions}",
            'formulas': [],
            'epm_functions': [],
            'local_members': [],
            'data_validations': [],
            'conditional_formatting': [],
            'comments': [],
            'merged_cells': [str(r) for r in sheet.merged_cells.ranges],
            'data_sample': []
        }
        
        # Extract formulas and EPM-specific functions
        for row in sheet.iter_rows():
            for cell in row:
                if cell.value and isinstance(cell.value, str):
                    if cell.value.startswith('='):
                        formula_info = {
                            'cell': cell.coordinate,
                            'formula': cell.value,
                            'calculated_value': str(data_sheet[cell.coordinate].value or '')[:100]
                        }
                        sheet_info['formulas'].append(formula_info)
                        
                        # Check for EPM functions
                        formula_upper = cell.value.upper()
                        if any(epm_func in formula_upper for epm_func in 
                               ['EPM', 'EVDRE', 'EVGET', 'EVPRF', 'EVGTS', 'EVSEN', 
                                'EPMCONTEXTMEMBER', 'EPMMEMBERPROPERTY', 'EPMDIMENSIONOVERRIDE',
                                'EPMOLAPMEMBERO', 'EPMLOCALMEMBER']):
                            sheet_info['epm_functions'].append(formula_info)
                        
                        # Check for LocalMember specifically
                        if 'EPMLOCALMEMBER' in formula_upper or 'LOCALMEMBER' in formula_upper:
                            sheet_info['local_members'].append(formula_info)
                
                # Extract comments
                if cell.comment:
                    sheet_info['comments'].append({
                        'cell': cell.coordinate,
                        'comment': cell.comment.text
                    })
        
        # Extract data validations
        for dv in sheet.data_validations.dataValidation:
            sheet_info['data_validations'].append({
                'sqref': str(dv.sqref),
                'type': dv.type,
                'formula1': str(dv.formula1) if dv.formula1 else ''
            })
        
        # Extract sample data (first 15 rows)
        for i, row in enumerate(sheet.iter_rows(max_row=15, values_only=True)):
            if i < 15:
                sheet_info['data_sample'].append([str(cell)[:50] if cell is not None else '' for cell in row])
        
        return sheet_info
    
    def create_report_screenshot(self, sheet_name, output_path, max_width=1200, max_height=800):
        """Create a professional screenshot of the report layout"""
        sheet = self.workbook[sheet_name]
        data_sheet = self.data_wb[sheet_name]
        
        # Calculate dimensions
        cell_width = 100
        cell_height = 25
        max_cols = min(15, sheet.max_column)
        max_rows = min(30, sheet.max_row)
        
        # Ensure minimum size
        if max_cols < 1:
            max_cols = 1
        if max_rows < 1:
            max_rows = 1
        
        img_width = min(cell_width * max_cols, max_width)
        img_height = min(cell_height * max_rows, max_height)
        
        # Ensure minimum image size
        if img_width < 100:
            img_width = 100
        if img_height < 100:
            img_height = 100
        
        # Create image
        img = Image.new('RGB', (img_width, img_height), 'white')
        draw = ImageDraw.Draw(img)
        
        # Draw grid and cell values
        for row_idx in range(max_rows):
            for col_idx in range(max_cols):
                x1 = col_idx * cell_width
                y1 = row_idx * cell_height
                x2 = x1 + cell_width
                y2 = y1 + cell_height
                
                # Bounds check
                if x2 > img_width:
                    x2 = img_width
                if y2 > img_height:
                    y2 = img_height
                if x1 >= x2 or y1 >= y2:
                    continue
                
                # Draw cell border
                draw.rectangle([x1, y1, x2, y2], outline='gray', width=1)
                
                try:
                    cell = sheet.cell(row_idx + 1, col_idx + 1)
                    value = data_sheet.cell(row_idx + 1, col_idx + 1).value
                    
                    # Highlight cells with formulas
                    if cell.value and isinstance(cell.value, str) and cell.value.startswith('='):
                        draw.rectangle([x1, y1, x2, y2], fill='lightyellow')
                    
                    # Draw cell value
                    if value:
                        text = str(value)[:15]
                        draw.text((x1 + 3, y1 + 6), text, fill='black')
                except:
                    pass
        
        img.save(output_path)
        return output_path


class SAPEPMAgent:
    """SAP EPM Expert Agent"""
    
    def analyze_workbook_data(self, workbook_name, sheets_data):
        """Analyze data for a specific workbook"""
        
        analysis = {
            'workbook_name': workbook_name,
            'sheets': [s['name'] for s in sheets_data],
            'dimensions': self._identify_dimensions(sheets_data),
            'epm_functions': self._analyze_epm_functions(sheets_data),
            'local_members': self._analyze_local_members(sheets_data),
            'measures': self._identify_measures(sheets_data),
            'business_rules': self._identify_business_rules(sheets_data),
            'custom_formulas': self._identify_custom_formulas(sheets_data),
            'vba_automation': {'has_vba': False, 'note': 'VBA analysis per workbook not applicable'},
            'report_summary': self._generate_summary(sheets_data)
        }
        
        return analysis
    
    def _identify_dimensions(self, sheets_data):
        """Identify EPM dimensions"""
        dimensions = []
        dimension_functions = [
            'EPMCONTEXTMEMBER', 'EPMDIMENSIONOVERRIDE', 'EPMMEMBERPROPERTY',
            'EPMOLAPMEMBERO', 'EPMLOCALMEMBER'
        ]
        
        for sheet in sheets_data:
            for epm_func in sheet['epm_functions']:
                formula = epm_func['formula'].upper()
                for dim_func in dimension_functions:
                    if dim_func in formula:
                        dimensions.append({
                            'sheet': sheet['name'],
                            'cell': epm_func['cell'],
                            'function': dim_func,
                            'formula': epm_func['formula'][:200]
                        })
        
        return dimensions
    
    def _analyze_epm_functions(self, sheets_data):
        """Analyze EPM-specific functions"""
        epm_summary = {
            'total': 0,
            'by_type': {},
            'details': []
        }
        
        for sheet in sheets_data:
            for epm_func in sheet['epm_functions']:
                epm_summary['total'] += 1
                
                formula = epm_func['formula'].upper()
                for func_type in ['EVDRE', 'EVGET', 'EVPRF', 'EPMCONTEXTMEMBER', 
                                 'EPMDIMENSIONOVERRIDE', 'EPMOLAPMEMBERO', 'EPMLOCALMEMBER']:
                    if func_type in formula:
                        epm_summary['by_type'][func_type] = epm_summary['by_type'].get(func_type, 0) + 1
                
                epm_summary['details'].append({
                    'sheet': sheet['name'],
                    'cell': epm_func['cell'],
                    'formula': epm_func['formula'][:150]
                })
        
        return epm_summary
    
    def _analyze_local_members(self, sheets_data):
        """Analyze EPMLocalMember usage"""
        local_members = []
        
        for sheet in sheets_data:
            for lm in sheet['local_members']:
                local_members.append({
                    'sheet': sheet['name'],
                    'cell': lm['cell'],
                    'formula': lm['formula'],
                    'value': lm.get('calculated_value', '')
                })
        
        return local_members
    
    def _identify_measures(self, sheets_data):
        """Identify measures and KPIs"""
        measures = []
        
        for sheet in sheets_data:
            for formula in sheet['formulas']:
                if any(func in formula['formula'].upper() for func in 
                       ['SUM', 'AVERAGE', 'COUNT', 'MAX', 'MIN']):
                    measures.append({
                        'sheet': sheet['name'],
                        'cell': formula['cell'],
                        'formula': formula['formula'][:100]
                    })
        
        return measures
    
    def _identify_business_rules(self, sheets_data):
        """Identify business rules"""
        rules = []
        
        for sheet in sheets_data:
            for formula in sheet['formulas']:
                if any(keyword in formula['formula'].upper() for keyword in 
                       ['IF', 'SUMIF', 'VLOOKUP', 'INDEX', 'MATCH']):
                    rules.append({
                        'sheet': sheet['name'],
                        'cell': formula['cell'],
                        'rule': formula['formula'][:150]
                    })
        
        return rules
    
    def _identify_custom_formulas(self, sheets_data):
        """Identify custom formulas"""
        custom = []
        
        for sheet in sheets_data:
            for formula in sheet['formulas']:
                if len(formula['formula']) > 80 or formula['formula'].count('(') > 3:
                    custom.append({
                        'sheet': sheet['name'],
                        'cell': formula['cell'],
                        'formula': formula['formula'][:200]
                    })
        
        return custom
    
    def _generate_summary(self, sheets_data):
        """Generate summary statistics"""
        total_formulas = sum(len(s['formulas']) for s in sheets_data)
        total_epm = sum(len(s['epm_functions']) for s in sheets_data)
        
        return {
            'total_sheets': len(sheets_data),
            'total_formulas': total_formulas,
            'total_epm_functions': total_epm
        }


class TemplateReportGenerator:
    """Generate Word document in template format"""
    
    def __init__(self, analysis_data, screenshot_path):
        self.analysis = analysis_data
        self.screenshot_path = screenshot_path
    
    def generate_report(self, output_path):
        """Generate report in template format"""
        doc = Document()
        
        # Set default font
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Arial'
        font.size = Pt(11)
        
        # Title
        title = doc.add_heading(f'Report: {self.analysis["workbook_name"]} - BPC EPM Analysis', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Subtitle
        subtitle = doc.add_paragraph('SAP BPC / EPM · Validation Report')
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        subtitle_run = subtitle.runs[0]
        subtitle_run.font.size = Pt(12)
        subtitle_run.font.italic = True
        
        doc.add_paragraph()
        
        # Report metadata table
        doc.add_heading('Report Overview', 1)
        table = doc.add_table(rows=3, cols=2)
        table.style = 'Light Grid Accent 1'
        
        table.cell(0, 0).text = 'Report Name'
        table.cell(0, 1).text = self.analysis['workbook_name']
        
        table.cell(1, 0).text = 'Sheets Analyzed'
        table.cell(1, 1).text = ', '.join(self.analysis['sheets'])
        
        table.cell(2, 0).text = 'Total EPM Functions'
        table.cell(2, 1).text = str(self.analysis['epm_functions']['total'])
        
        doc.add_paragraph()
        
        # Section 1: Report Layout Screenshot
        doc.add_heading('1. Report Layout Screenshot', 1)
        doc.add_paragraph(
            'Full report structure as rendered in BPC EPM Excel add-in, showing dimension context, '
            'entity columns, validation rows, and aggregation.'
        )
        
        if self.screenshot_path and os.path.exists(self.screenshot_path):
            try:
                doc.add_picture(self.screenshot_path, width=Inches(6.5))
            except Exception as e:
                doc.add_paragraph(f'[Screenshot error: {str(e)[:50]}]')
        else:
            doc.add_paragraph('[Screenshot not available]')
        
        doc.add_paragraph()
        
        # Section 2: Dimensions
        doc.add_heading('2. Dimensions - Display Format · Sorting · Hierarchies · Business Rules', 1)
        doc.add_paragraph(
            f'Total dimensions identified: {len(self.analysis["dimensions"])}'
        )
        
        if self.analysis['dimensions']:
            # Create dimensions table
            dims_table = doc.add_table(rows=1, cols=4)
            dims_table.style = 'Light Grid Accent 1'
            
            # Header row
            hdr_cells = dims_table.rows[0].cells
            hdr_cells[0].text = 'Sheet'
            hdr_cells[1].text = 'Cell'
            hdr_cells[2].text = 'Function'
            hdr_cells[3].text = 'Formula Preview'
            
            # Data rows
            for dim in self.analysis['dimensions'][:20]:
                row_cells = dims_table.add_row().cells
                row_cells[0].text = dim['sheet']
                row_cells[1].text = dim['cell']
                row_cells[2].text = dim['function']
                row_cells[3].text = dim['formula'][:50] + '...'
        else:
            doc.add_paragraph('No dimension-specific EPM functions detected.')
        
        doc.add_paragraph()
        
        # Section 3: EPMLocalMember
        doc.add_heading('3. EPMLocalMember - Custom Virtual Members', 1)
        doc.add_paragraph(
            'EPMLocalMember creates ephemeral, in-memory members for validation rows. '
            'They are never written to BPC.'
        )
        
        if self.analysis['local_members']:
            doc.add_paragraph(f'Total LocalMembers found: {len(self.analysis["local_members"])}')
            
            lm_table = doc.add_table(rows=1, cols=4)
            lm_table.style = 'Light Grid Accent 1'
            
            hdr_cells = lm_table.rows[0].cells
            hdr_cells[0].text = 'Sheet'
            hdr_cells[1].text = 'Cell'
            hdr_cells[2].text = 'Formula'
            hdr_cells[3].text = 'Value'
            
            for lm in self.analysis['local_members'][:15]:
                row_cells = lm_table.add_row().cells
                row_cells[0].text = lm['sheet']
                row_cells[1].text = lm['cell']
                row_cells[2].text = lm['formula'][:60] + '...'
                row_cells[3].text = str(lm.get('value', ''))[:30]
        else:
            doc.add_paragraph('No EPMLocalMember functions detected.')
        
        doc.add_paragraph()
        
        # Section 4: EPM Functions Summary
        doc.add_heading('4. EPM Functions Summary', 1)
        
        epm_data = self.analysis['epm_functions']
        doc.add_paragraph(f"Total EPM Functions: {epm_data['total']}")
        
        if epm_data['by_type']:
            doc.add_paragraph('Function Type Distribution:')
            for func_type, count in epm_data['by_type'].items():
                doc.add_paragraph(f'  • {func_type}: {count} occurrence(s)', style='List Bullet')
        
        doc.add_paragraph()
        
        # Section 5: Measures and KPIs
        doc.add_heading('5. Measures and KPIs', 1)
        
        if self.analysis['measures']:
            doc.add_paragraph(f"Total measures identified: {len(self.analysis['measures'])}")
            
            for i, measure in enumerate(self.analysis['measures'][:10], 1):
                p = doc.add_paragraph()
                p.add_run(f"{i}. ").bold = True
                p.add_run(f"Sheet: {measure['sheet']} | Cell: {measure['cell']}\n")
                p.add_run(f"   Formula: {measure['formula']}")
        else:
            doc.add_paragraph('No aggregated measures detected.')
        
        doc.add_paragraph()
        
        # Section 6: Business Rules
        doc.add_heading('6. Business Rules and Logic', 1)
        
        if self.analysis['business_rules']:
            doc.add_paragraph(f"Total business rules identified: {len(self.analysis['business_rules'])}")
            
            for i, rule in enumerate(self.analysis['business_rules'][:10], 1):
                p = doc.add_paragraph()
                p.add_run(f"{i}. ").bold = True
                p.add_run(f"Sheet: {rule['sheet']} | Cell: {rule['cell']}\n")
                p.add_run(f"   Rule: {rule['rule']}")
        else:
            doc.add_paragraph('No complex business rules detected.')
        
        doc.add_paragraph()
        
        # Section 7: Custom Formulas
        doc.add_heading('7. Custom Formulas and Customizations', 1)
        
        if self.analysis['custom_formulas']:
            doc.add_paragraph(f"Total complex formulas: {len(self.analysis['custom_formulas'])}")
            
            for i, cf in enumerate(self.analysis['custom_formulas'][:8], 1):
                p = doc.add_paragraph()
                p.add_run(f"{i}. ").bold = True
                p.add_run(f"Sheet: {cf['sheet']} | Cell: {cf['cell']}\n")
                p.add_run(f"   Formula: {cf['formula']}")
        else:
            doc.add_paragraph('No complex custom formulas detected.')
        
        doc.add_paragraph()
        
        # Section 8: Summary
        doc.add_heading('8. Summary and Statistics', 1)
        
        summary = self.analysis['report_summary']
        doc.add_paragraph(f"• Total Sheets Analyzed: {summary['total_sheets']}")
        doc.add_paragraph(f"• Total Formulas: {summary['total_formulas']}")
        doc.add_paragraph(f"• Total EPM Functions: {summary['total_epm_functions']}")
        
        # Save document
        doc.save(output_path)
        return output_path


def main():
    """Main execution function"""
    
    input_file = "/mnt/user-data/uploads/Copy_of_Sample_Report_BPC_EPM.xlsx"
    
    if not os.path.exists(input_file):
        print(f"Error: File not found: {input_file}")
        return []
    
    print("=" * 80)
    print("SAP EPM Multi-Workbook Analyzer")
    print("Generates separate reports per workbook in template format")
    print("=" * 80)
    print(f"\nAnalyzing file: {input_file}\n")
    
    # Extract Excel details
    print("Step 1: Extracting Excel details...")
    extractor = ExcelExtractor(input_file)
    sheets_by_workbook = extractor.get_workbook_sheets()
    
    print(f"  ✓ Found {len(sheets_by_workbook)} workbook(s):")
    for wb_name, sheets in sheets_by_workbook.items():
        print(f"     - {wb_name}: {len(sheets)} sheet(s)")
    
    # Process each workbook
    agent = SAPEPMAgent()
    output_files = []
    
    for workbook_name, sheet_names in sheets_by_workbook.items():
        print(f"\nProcessing workbook: {workbook_name}")
        
        # Extract sheet details
        sheets_data = []
        for sheet_name in sheet_names:
            sheet_info = extractor.extract_sheet_details(sheet_name)
            sheets_data.append(sheet_info)
            print(f"  ✓ Extracted: {sheet_name}")
        
        # Create screenshot for first sheet
        screenshot_path = f"/home/claude/screenshot_{workbook_name}.png"
        try:
            extractor.create_report_screenshot(sheet_names[0], screenshot_path)
            print(f"  ✓ Screenshot created")
        except Exception as e:
            print(f"  ✗ Screenshot failed: {str(e)[:50]}")
            screenshot_path = None
        
        # Analyze with agent
        print(f"  ✓ Analyzing with SAP EPM Agent...")
        analysis = agent.analyze_workbook_data(workbook_name, sheets_data)
        
        # Generate report
        output_filename = f"BPC_EPM_Analysis_{workbook_name.replace(' ', '_')}.docx"
        output_path = f"/mnt/user-data/outputs/{output_filename}"
        
        print(f"  ✓ Generating report...")
        generator = TemplateReportGenerator(analysis, screenshot_path)
        generator.generate_report(output_path)
        
        output_files.append(output_path)
        print(f"  ✓ Report saved: {output_filename}")
    
    print("\n" + "=" * 80)
    print("Analysis Complete!")
    print("=" * 80)
    print(f"\nGenerated {len(output_files)} report(s):")
    for output_file in output_files:
        print(f"  • {os.path.basename(output_file)}")
    
    return output_files


if __name__ == "__main__":
    outputs = main()
    sys.exit(0)
