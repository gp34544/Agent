"""
Excel Visible Sheets Screenshot Tool
Takes screenshots of ONLY visible (non-hidden) sheets as they appear in Excel
"""

import os
import sys
from datetime import datetime


def take_excel_screenshots(excel_file_path, output_folder=None):
    """Take screenshots of visible Excel sheets using xlwings"""

    # Setup output folder
    if output_folder is None:
        output_folder = os.path.join(
            os.path.dirname(excel_file_path),
            "sheet_screenshots"
        )

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
        print(f"✓ Created output folder: {output_folder}")

    # Check for xlwings
    try:
        import xlwings as xw
    except ImportError:
        print("\n✗ Error: xlwings library not found")
        print("Install it with: pip3 install xlwings")
        print("\nNote: This method requires Microsoft Excel to be installed on your Mac")
        return False

    # Check for PIL/Pillow
    try:
        from PIL import ImageGrab
    except ImportError:
        print("\n✗ Error: Pillow library not found")
        print("Install it with: pip3 install pillow")
        return False

    print("\n" + "=" * 80)
    print("📸 EXCEL SCREENSHOT TOOL - VISIBLE SHEETS ONLY")
    print("=" * 80)

    try:
        # Open Excel workbook (invisible mode)
        print(f"\n📂 Opening: {os.path.basename(excel_file_path)}")
        app = xw.App(visible=False)
        wb = app.books.open(excel_file_path)

        # Get all sheets and filter for visible ones
        all_sheets = wb.sheets
        visible_sheets = [sheet for sheet in all_sheets if sheet.visible]
        hidden_sheets = [sheet for sheet in all_sheets if not sheet.visible]

        print(f"\n📊 Sheet Analysis:")
        print(f"   • Total sheets: {len(all_sheets)}")
        print(f"   • Visible sheets: {len(visible_sheets)}")
        print(f"   • Hidden sheets: {len(hidden_sheets)}")

        if not visible_sheets:
            print("\n⚠ Warning: No visible sheets found!")
            wb.close()
            app.quit()
            return False

        print(f"\n🎯 Processing {len(visible_sheets)} visible sheets:")
        print("-" * 80)

        screenshot_count = 0
        import time

        for idx, sheet in enumerate(visible_sheets, 1):
            sheet_name = sheet.name
            print(f"\n   [{idx}/{len(visible_sheets)}] 📸 {sheet_name}")

            try:
                # Activate the sheet
                sheet.activate()
                time.sleep(0.5)  # Wait for sheet to activate

                # Get the used range
                used_range = sheet.used_range

                if used_range is None:
                    print(f"      ⚠ Sheet is empty, skipping...")
                    continue

                # Generate safe filename
                safe_name = "".join(
                    c if c.isalnum() or c in (' ', '-', '_') else '_'
                    for c in sheet_name
                )
                screenshot_path = os.path.join(
                    output_folder,
                    f"{safe_name}.png"
                )

                # Use xlwings to_png method (Mac-compatible)
                try:
                    # Take screenshot of the used range
                    used_range.to_png(screenshot_path)

                    # Get file size
                    if os.path.exists(screenshot_path):
                        file_size = os.path.getsize(screenshot_path)
                        size_kb = file_size / 1024

                        print(f"      ✓ Saved: {os.path.basename(screenshot_path)} ({size_kb:.1f} KB)")
                        screenshot_count += 1
                    else:
                        print(f"      ✗ Failed to save screenshot")

                except AttributeError:
                    # Fallback: Save entire sheet as picture
                    print(f"      ℹ Using alternative method...")

                    # Make sheet visible temporarily
                    sheet.activate()
                    time.sleep(0.5)

                    # Take screenshot using PIL
                    import subprocess

                    # Use Mac's screencapture utility
                    temp_screenshot = os.path.join(output_folder, f"temp_{safe_name}.png")

                    # This is a fallback - won't work perfectly but better than nothing
                    print(f"      ⚠ Screenshot method not fully supported on this system")
                    print(f"      Please use: File > Save As > PDF or take manual screenshots")

            except Exception as e:
                print(f"      ✗ Error: {str(e)}")
                continue

        # Close workbook and quit Excel
        wb.close()
        app.quit()

        print("\n" + "=" * 80)
        print(f"✓ COMPLETED: {screenshot_count}/{len(visible_sheets)} screenshots saved")
        print("=" * 80)
        print(f"\n📁 Screenshots location: {output_folder}")

        # List all screenshots
        screenshots = sorted([f for f in os.listdir(output_folder) if f.endswith('.png')])
        if screenshots:
            print(f"\n📋 Files created ({len(screenshots)}):")
            for screenshot in screenshots:
                print(f"   • {screenshot}")

        return True

    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()

        # Try to cleanup
        try:
            wb.close()
            app.quit()
        except:
            pass

        return False


def main():
    """Main execution function"""
    # Excel file to process
    excel_file = "Copy of Sample Report BPC EPM.xlsx"

    # Get the script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(script_dir, excel_file)

    # Check if file exists
    if not os.path.exists(excel_path):
        print(f"\n✗ Error: Excel file not found at {excel_path}")
        print(f"Please ensure '{excel_file}' is in the same folder as this script.")
        return

    print("\n" + "=" * 80)
    print("EXCEL SCREENSHOT TOOL - VISIBLE SHEETS ONLY")
    print("=" * 80)
    print(f"\nTarget file: {excel_file}")
    print(f"Full path: {excel_path}")

    print("\n⚠️  REQUIREMENTS:")
    print("   1. Microsoft Excel must be installed on your Mac")
    print("   2. xlwings library: pip3 install xlwings")
    print("   3. Pillow library: pip3 install pillow")

    input("\nPress Enter to start screenshot capture...")

    # Take screenshots
    success = take_excel_screenshots(excel_path)

    if success:
        print("\n✅ All done! Check the sheet_screenshots folder.")
    else:
        print("\n❌ Screenshot capture failed.")
        print("\nTroubleshooting:")
        print("1. Ensure Microsoft Excel is installed")
        print("2. Install required libraries:")
        print("   pip3 install xlwings pillow")
        print("3. Close Excel if it's already running")


if __name__ == "__main__":
    main()
