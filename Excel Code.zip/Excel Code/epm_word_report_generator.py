"""
EPM Word Report Generator
Creates detailed reconstruction documentation for EPM reports
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


class EPMWordReportGenerator:
    """Generates EPM report reconstruction documentation in Word format"""

    def __init__(self):
        """Initialize the generator"""
        self.default_font = "Calibri"
        self.heading_font = "Arial"

    def create_epm_reconstruction_doc(
        self,
        analysis_data: Dict,
        output_path: str,
        include_screenshot: bool = True
    ) -> bool:
        """
        Create Word document for EPM report reconstruction

        Args:
            analysis_data: EPM analysis results from Claude
            output_path: Output file path
            include_screenshot: Include screenshot image

        Returns:
            Success status
        """
        try:
            print(f"\n📄 Creating EPM reconstruction doc: {os.path.basename(output_path)}")

            doc = Document()
            self._setup_document_styles(doc)

            # Title page
            self._add_epm_title_page(doc, analysis_data)
            doc.add_page_break()

            # Table of contents placeholder
            self._add_toc_placeholder(doc)
            doc.add_page_break()

            # Screenshot section
            if include_screenshot:
                self._add_screenshot_section(doc, analysis_data)
                doc.add_page_break()

            # Main EPM analysis sections
            self._add_epm_analysis_sections(doc, analysis_data)

            # Technical details
            self._add_technical_appendix(doc, analysis_data)

            # Footer
            self._add_footer(doc, analysis_data)

            # Save
            doc.save(output_path)

            file_size = os.path.getsize(output_path) / 1024
            print(f"   ✓ Document saved ({file_size:.1f} KB)")

            return True

        except Exception as e:
            print(f"   ✗ Error: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    def _setup_document_styles(self, doc: Document):
        """Setup custom styles"""
        styles = doc.styles

        # Normal style
        style_normal = styles['Normal']
        style_normal.font.name = self.default_font
        style_normal.font.size = Pt(11)

        # Heading styles
        for i in range(1, 4):
            style = styles[f'Heading {i}']
            style.font.name = self.heading_font
            style.font.bold = True
            style.font.color.rgb = RGBColor(0, 51, 102)

    def _add_epm_title_page(self, doc: Document, analysis_data: Dict):
        """Add professional title page for EPM report"""
        sheet_name = analysis_data.get('sheet_name', 'Unknown Report')
        timestamp = analysis_data.get('analysis_timestamp', datetime.now().isoformat())

        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            formatted_date = dt.strftime("%B %d, %Y")
        except:
            formatted_date = timestamp

        # Main title
        title = doc.add_heading('EPM REPORT', level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title.runs[0].font.size = Pt(36)
        title.runs[0].font.color.rgb = RGBColor(0, 51, 102)
        title.runs[0].font.bold = True

        # Subtitle
        subtitle = doc.add_heading('REVERSE ENGINEERING & RECONSTRUCTION GUIDE', level=0)
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        subtitle.runs[0].font.size = Pt(18)
        subtitle.runs[0].font.color.rgb = RGBColor(100, 100, 100)

        doc.add_paragraph()
        doc.add_paragraph()

        # Report name
        report_para = doc.add_paragraph()
        report_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = report_para.add_run(f'"{sheet_name}"')
        run.font.size = Pt(24)
        run.font.bold = True
        run.font.color.rgb = RGBColor(192, 0, 0)

        doc.add_paragraph()
        doc.add_paragraph()

        # Info box
        info = doc.add_paragraph()
        info.alignment = WD_ALIGN_PARAGRAPH.CENTER
        lines = [
            f"Analysis Date: {formatted_date}",
            "Analyzed by: Claude 4.5 Sonnet",
            "Purpose: EPM Report Reconstruction",
            ""
        ]
        for line in lines:
            run = info.add_run(line + '\n')
            run.font.size = Pt(12)
            run.font.color.rgb = RGBColor(80, 80, 80)

        # Metadata
        metadata = analysis_data.get('metadata', {})

        doc.add_paragraph()
        separator = doc.add_paragraph("═" * 60)
        separator.alignment = WD_ALIGN_PARAGRAPH.CENTER
        separator.runs[0].font.color.rgb = RGBColor(0, 51, 102)
        separator.runs[0].font.size = Pt(14)

        stats = doc.add_paragraph()
        stats.alignment = WD_ALIGN_PARAGRAPH.CENTER
        stat_lines = [
            f"Total Cells: {metadata.get('cell_count', 0):,} | ",
            f"Formulas: {metadata.get('formula_count', 0)} | ",
            f"EPM Functions: {metadata.get('epm_function_count', 0)}"
        ]
        for line in stat_lines:
            run = stats.add_run(line)
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(100, 100, 100)

    def _add_toc_placeholder(self, doc: Document):
        """Add table of contents placeholder"""
        doc.add_heading('Table of Contents', level=1)

        toc_para = doc.add_paragraph()
        toc_para.add_run("1. Report Screenshot\n")
        toc_para.add_run("2. Report/Workbook Identification\n")
        toc_para.add_run("3. Dimensions Analysis\n")
        toc_para.add_run("4. Measures/KPIs Analysis\n")
        toc_para.add_run("5. Formulas and Business Logic\n")
        toc_para.add_run("6. EPM Functions Usage\n")
        toc_para.add_run("7. Report Structure\n")
        toc_para.add_run("8. Reconstruction Blueprint\n")
        toc_para.add_run("9. Technical Appendix\n")

        note = doc.add_paragraph()
        note.add_run("Note: Update table of contents in Word by right-clicking and selecting 'Update Field'").italic = True
        note.runs[0].font.size = Pt(9)
        note.runs[0].font.color.rgb = RGBColor(128, 128, 128)

    def _add_screenshot_section(self, doc: Document, analysis_data: Dict):
        """Add screenshot section"""
        metadata = analysis_data.get('metadata', {})
        screenshot_path = metadata.get('screenshot_path')

        doc.add_heading('1. Report Screenshot', level=1)

        if screenshot_path and os.path.exists(screenshot_path):
            doc.add_paragraph(
                f"Visual representation of the '{analysis_data.get('sheet_name')}' EPM report:"
            )
            doc.add_paragraph()

            try:
                doc.add_picture(screenshot_path, width=Inches(6.5))
                print(f"   ✓ Screenshot embedded: {os.path.basename(screenshot_path)}")
            except Exception as e:
                doc.add_paragraph(f"[Screenshot unavailable: {str(e)}]")
                print(f"   ⚠ Screenshot error: {str(e)}")
        else:
            doc.add_paragraph("[No screenshot available for this report]")

    def _add_epm_analysis_sections(self, doc: Document, analysis_data: Dict):
        """Add main EPM analysis sections"""

        full_analysis = analysis_data.get('epm_analysis', '')

        # Define the sections we want to extract and their numbering
        sections_map = [
            ('REPORT/WORKBOOK IDENTIFICATION', '2'),
            ('DIMENSIONS ANALYSIS', '3'),
            ('MEASURES/KPIs ANALYSIS', '4'),
            ('FORMULAS AND BUSINESS LOGIC', '5'),
            ('EPM FUNCTIONS USAGE', '6'),
            ('REPORT STRUCTURE', '7'),
            ('DATA FLOW & DEPENDENCIES', '8'),
            ('RECONSTRUCTION BLUEPRINT', '9'),
        ]

        for section_name, section_num in sections_map:
            content = self._extract_section_content(full_analysis, section_name)

            if content:
                # Add heading
                heading_text = f"{section_num}. {section_name.title()}"
                doc.add_heading(heading_text, level=1)

                # Parse and add content
                self._add_formatted_content(doc, content)

                doc.add_paragraph()  # Spacing
            else:
                # Add section even if empty
                heading_text = f"{section_num}. {section_name.title()}"
                doc.add_heading(heading_text, level=1)
                doc.add_paragraph("[Analysis pending or not applicable]")

    def _add_formatted_content(self, doc: Document, content: str):
        """Add formatted content with proper styling"""

        # Split content into paragraphs
        paragraphs = content.split('\n\n')

        for para_text in paragraphs:
            if not para_text.strip():
                continue

            # Check for question headers (Q:)
            if para_text.strip().startswith('**Q:') or para_text.strip().startswith('Q:'):
                # This is a question - make it a heading
                question = para_text.strip().replace('**Q:', '').replace('Q:', '').replace('**', '').strip()
                doc.add_heading(question, level=3)
                continue

            # Check for subsection headers (##)
            if para_text.strip().startswith('##'):
                heading_text = para_text.strip().replace('##', '').strip()
                doc.add_heading(heading_text, level=2)
                continue

            # Check for lists
            lines = para_text.split('\n')

            is_list = False
            for line in lines:
                line_stripped = line.strip()

                if not line_stripped:
                    continue

                # Bullet points
                if line_stripped.startswith(('-', '•', '*', '–')):
                    cleaned = line_stripped.lstrip('-•*– ').strip()

                    # Check for bold key-value pairs
                    if '**' in cleaned:
                        para = doc.add_paragraph(style='List Bullet')
                        self._add_bold_formatted_text(para, cleaned)
                    else:
                        doc.add_paragraph(cleaned, style='List Bullet')
                    is_list = True

                # Numbered lists
                elif len(line_stripped) > 0 and line_stripped[0].isdigit() and '. ' in line_stripped[:4]:
                    cleaned = line_stripped.split('. ', 1)[1] if '. ' in line_stripped else line_stripped

                    if '**' in cleaned:
                        para = doc.add_paragraph(style='List Number')
                        self._add_bold_formatted_text(para, cleaned)
                    else:
                        doc.add_paragraph(cleaned, style='List Number')
                    is_list = True

                # Regular text with bold formatting
                elif '**' in line_stripped:
                    para = doc.add_paragraph()
                    self._add_bold_formatted_text(para, line_stripped)

                # Regular paragraph
                else:
                    if not is_list:
                        doc.add_paragraph(line_stripped)
                    else:
                        # Continuation of list item
                        pass

    def _add_bold_formatted_text(self, paragraph, text: str):
        """Add text with bold formatting for **text**"""
        parts = text.split('**')

        for i, part in enumerate(parts):
            if i % 2 == 0:
                # Regular text
                if part:
                    paragraph.add_run(part)
            else:
                # Bold text
                if part:
                    run = paragraph.add_run(part)
                    run.bold = True
                    run.font.color.rgb = RGBColor(0, 51, 102)

    def _add_technical_appendix(self, doc: Document, analysis_data: Dict):
        """Add technical appendix with extracted formulas"""

        doc.add_page_break()
        doc.add_heading('10. Technical Appendix', level=1)

        # EPM Formulas
        epm_formulas = analysis_data.get('epm_formulas_extracted', {})

        doc.add_heading('A. EPM Functions Extracted', level=2)

        sections = [
            ('EPM_FUNCTIONS', 'All EPM Functions'),
            ('EPM_DIMENSION_OVERRIDES', 'Dimension Overrides'),
            ('EPM_MEMBER_OFFSETS', 'Member Offsets'),
            ('EPM_LOCAL_MEMBERS', 'Local Members'),
            ('CUSTOM_FORMULAS', 'Custom Excel Formulas'),
        ]

        for key, title in sections:
            formulas = epm_formulas.get(key, [])

            if formulas:
                doc.add_heading(f'{title} ({len(formulas)})', level=3)

                # Create table
                table = doc.add_table(rows=1, cols=2)
                table.style = 'Light Grid Accent 1'

                # Header
                table.rows[0].cells[0].text = "Cell"
                table.rows[0].cells[1].text = "Formula"

                for cell in table.rows[0].cells:
                    for paragraph in cell.paragraphs:
                        for run in paragraph.runs:
                            run.font.bold = True

                # Add formulas (limit to 50 for readability)
                for formula_data in formulas[:50]:
                    row = table.add_row()
                    row.cells[0].text = formula_data.get('cell', '')
                    row.cells[1].text = formula_data.get('formula', '')

                if len(formulas) > 50:
                    doc.add_paragraph(f"... and {len(formulas) - 50} more formulas")

                doc.add_paragraph()

        # VBA Summary
        doc.add_heading('B. VBA Macros Summary', level=2)
        vba_summary = analysis_data.get('vba_summary', 'No VBA information available')
        doc.add_paragraph(vba_summary)

        # Metadata
        doc.add_heading('C. Technical Metadata', level=2)
        metadata = analysis_data.get('metadata', {})

        table = doc.add_table(rows=6, cols=2)
        table.style = 'Light Grid Accent 1'

        table.rows[0].cells[0].text = "Property"
        table.rows[0].cells[1].text = "Value"

        table.rows[1].cells[0].text = "Sheet Dimensions"
        table.rows[1].cells[1].text = str(metadata.get('dimensions', 'N/A'))

        table.rows[2].cells[0].text = "Total Cells"
        table.rows[2].cells[1].text = f"{metadata.get('cell_count', 0):,}"

        table.rows[3].cells[0].text = "Total Formulas"
        table.rows[3].cells[1].text = str(metadata.get('formula_count', 0))

        table.rows[4].cells[0].text = "EPM Functions"
        table.rows[4].cells[1].text = str(metadata.get('epm_function_count', 0))

        table.rows[5].cells[0].text = "Merged Cells"
        table.rows[5].cells[1].text = str(metadata.get('merged_cells_count', 0))

        for cell in table.rows[0].cells:
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.font.bold = True

    def _add_footer(self, doc: Document, analysis_data: Dict):
        """Add footer"""
        section = doc.sections[0]
        footer = section.footer

        footer_para = footer.paragraphs[0]
        footer_para.text = f"EPM Report Reconstruction Guide | Generated by Claude 4.5 Sonnet | {datetime.now().strftime('%B %d, %Y')}"
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_para.runs[0].font.size = Pt(9)
        footer_para.runs[0].font.color.rgb = RGBColor(128, 128, 128)

    def _extract_section_content(self, full_text: str, section_name: str) -> str:
        """Extract section content from full analysis"""

        # Find section
        patterns = [
            f"## {section_name}",
            f"**{section_name}**",
            section_name,
        ]

        text_lower = full_text.lower()
        section_lower = section_name.lower()

        section_start = -1
        for pattern in patterns:
            idx = full_text.find(pattern)
            if idx != -1:
                section_start = idx + len(pattern)
                break

        if section_start == -1:
            idx = text_lower.find(section_lower)
            if idx != -1:
                section_start = idx + len(section_name)
            else:
                return ""

        # Find next section
        remaining = full_text[section_start:]

        next_patterns = ['## ', '\n\n**']
        section_end = len(remaining)

        for pattern in next_patterns:
            idx = remaining.find(pattern, 10)  # Skip first few chars
            if idx != -1 and idx < section_end:
                section_end = idx

        return remaining[:section_end].strip()

    def generate_all_epm_docs(
        self,
        analysis_json_path: str,
        output_folder: Optional[str] = None,
        include_screenshots: bool = True
    ) -> List[str]:
        """Generate EPM reconstruction docs for all reports"""

        print("\n" + "=" * 80)
        print("📝 EPM WORD REPORT GENERATOR")
        print("=" * 80)

        if not os.path.exists(analysis_json_path):
            raise FileNotFoundError(f"Analysis file not found: {analysis_json_path}")

        print(f"\nLoading: {os.path.basename(analysis_json_path)}")
        with open(analysis_json_path, 'r', encoding='utf-8') as f:
            analysis_results = json.load(f)

        if output_folder is None:
            output_folder = os.path.join(
                os.path.dirname(analysis_json_path),
                "epm_reconstruction_docs"
            )

        os.makedirs(output_folder, exist_ok=True)
        print(f"Output folder: {output_folder}")

        analyses = analysis_results.get('analyses', [])
        print(f"\n📊 Generating {len(analyses)} EPM reconstruction documents...")
        print("-" * 80)

        generated_docs = []

        for idx, analysis in enumerate(analyses, 1):
            sheet_name = analysis.get('sheet_name', f'Report_{idx}')
            print(f"\n[{idx}/{len(analyses)}] {sheet_name}")

            safe_name = "".join(
                c if c.isalnum() or c in (' ', '-', '_') else '_'
                for c in sheet_name
            )

            output_path = os.path.join(
                output_folder,
                f"{safe_name}_EPM_Reconstruction.docx"
            )

            success = self.create_epm_reconstruction_doc(
                analysis_data=analysis,
                output_path=output_path,
                include_screenshot=include_screenshots
            )

            if success:
                generated_docs.append(output_path)

        print("\n" + "=" * 80)
        print(f"✓ GENERATION COMPLETE: {len(generated_docs)} documents created")
        print("=" * 80)
        print(f"\n📁 Documents location: {output_folder}")

        if generated_docs:
            print(f"\n📋 Generated documents ({len(generated_docs)}):")
            for doc_path in generated_docs:
                file_size = os.path.getsize(doc_path) / 1024
                print(f"   • {os.path.basename(doc_path)} ({file_size:.1f} KB)")

        return generated_docs


def main():
    """Main execution"""
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    analysis_json = os.path.join(
        script_dir,
        excel_file.replace('.xlsx', '_epm_analysis.json')
    )

    if not os.path.exists(analysis_json):
        print(f"\n✗ Error: Analysis file not found: {analysis_json}")
        print("\n💡 Run epm_report_analyzer.py first!")
        return

    try:
        from docx import Document
        print("\n✓ python-docx ready")
    except ImportError:
        print("\n✗ Error: Install with: pip install python-docx")
        return

    print("\n" + "=" * 80)
    print("📝 EPM WORD REPORT GENERATOR")
    print("=" * 80)
    print(f"\nAnalysis file: {os.path.basename(analysis_json)}")

    input("\nPress Enter to generate EPM reconstruction documents...")

    try:
        generator = EPMWordReportGenerator()
        docs = generator.generate_all_epm_docs(
            analysis_json_path=analysis_json,
            include_screenshots=True
        )

        print(f"\n✅ SUCCESS! {len(docs)} EPM reconstruction documents generated")

    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
