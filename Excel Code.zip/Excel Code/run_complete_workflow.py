"""
Complete Workflow Runner
Runs all steps of the Excel report analysis pipeline
"""

import os
import sys
from datetime import datetime


def print_banner(text):
    """Print a formatted banner"""
    print("\n" + "=" * 80)
    print(text.center(80))
    print("=" * 80)


def check_dependencies():
    """Check if all required libraries are installed"""
    print("\n🔍 Checking dependencies...")

    required_packages = {
        'openpyxl': 'Excel file processing',
        'xlwings': 'Excel automation',
        'PIL': 'Image processing (Pillow)',
        'anthropic': 'Claude API',
        'docx': 'Word document generation (python-docx)'
    }

    missing = []

    for package, description in required_packages.items():
        try:
            __import__(package)
            print(f"   ✓ {package} - {description}")
        except ImportError:
            print(f"   ✗ {package} - {description} [MISSING]")
            missing.append(package)

    if missing:
        print("\n❌ Missing dependencies!")
        print("\nInstall them with:")
        print("   pip install -r requirements.txt")
        return False

    print("\n✅ All dependencies installed!")
    return True


def check_api_key():
    """Check if Anthropic API key is set"""
    print("\n🔑 Checking API key...")

    api_key = os.environ.get("ANTHROPIC_API_KEY")

    if not api_key:
        print("   ✗ ANTHROPIC_API_KEY not set")
        print("\n❌ API key required!")
        print("\nSet your API key:")
        print("   macOS/Linux: export ANTHROPIC_API_KEY='your-key-here'")
        print("   Windows: set ANTHROPIC_API_KEY=your-key-here")
        print("\nGet your API key from: https://console.anthropic.com/")
        return False

    print(f"   ✓ API key found: {api_key[:8]}...{api_key[-4:]}")
    return True


def run_step(step_number, step_name, script_name, required=True):
    """Run a single step of the workflow"""
    print_banner(f"STEP {step_number}: {step_name}")

    script_path = os.path.join(os.path.dirname(__file__), script_name)

    if not os.path.exists(script_path):
        print(f"\n✗ Error: {script_name} not found!")
        if required:
            return False
        return True

    print(f"\nRunning: {script_name}")
    print("-" * 80)

    try:
        # Import and run the script's main function
        if script_name == 'EPMReport_Extraction_Enhanced.py':
            from EPMReport_Extraction_Enhanced import EnhancedExcelExtractor

            excel_file = "Copy of Sample Report BPC EPM.xlsx"
            excel_path = os.path.join(os.path.dirname(__file__), excel_file)

            if not os.path.exists(excel_path):
                print(f"✗ Error: {excel_file} not found")
                return False

            extractor = EnhancedExcelExtractor(excel_path, extract_hidden=True, extract_visible=True)
            results = extractor.extract_all()

            print(f"\n✓ Step {step_number} completed successfully!")
            return True

        elif script_name == 'EPMReport_Screenshot_Visible.py':
            from EPMReport_Screenshot_Visible import take_excel_screenshots

            excel_file = "Copy of Sample Report BPC EPM.xlsx"
            excel_path = os.path.join(os.path.dirname(__file__), excel_file)

            if not os.path.exists(excel_path):
                print(f"✗ Error: {excel_file} not found")
                return False

            success = take_excel_screenshots(excel_path)

            if success:
                print(f"\n✓ Step {step_number} completed successfully!")
                return True
            else:
                print(f"\n⚠ Step {step_number} completed with warnings")
                if not required:
                    return True
                return False

        elif script_name == 'report_analysis_agent.py':
            from report_analysis_agent import ReportAnalysisAgent

            excel_file = "Copy of Sample Report BPC EPM.xlsx"
            excel_path = os.path.join(os.path.dirname(__file__), excel_file)

            if not os.path.exists(excel_path):
                print(f"✗ Error: {excel_file} not found")
                return False

            api_key = os.environ.get("ANTHROPIC_API_KEY")
            agent = ReportAnalysisAgent(api_key=api_key)
            analyses = agent.analyze_all_reports(excel_path)

            print(f"\n✓ Step {step_number} completed successfully!")
            return True

        elif script_name == 'word_document_generator.py':
            from word_document_generator import WordDocumentGenerator

            excel_file = "Copy of Sample Report BPC EPM.xlsx"
            analysis_json = os.path.join(
                os.path.dirname(__file__),
                excel_file.replace('.xlsx', '_claude_analysis.json')
            )

            if not os.path.exists(analysis_json):
                print(f"✗ Error: Analysis file not found")
                return False

            generator = WordDocumentGenerator()
            docs = generator.generate_all_documents(
                analysis_json_path=analysis_json,
                include_screenshots=True
            )

            print(f"\n✓ Step {step_number} completed successfully!")
            return True

    except Exception as e:
        print(f"\n✗ Error in step {step_number}: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Main workflow execution"""
    print("\n")
    print("╔" + "═" * 78 + "╗")
    print("║" + "EXCEL REPORT ANALYSIS - COMPLETE WORKFLOW".center(78) + "║")
    print("║" + "Powered by Claude 4.5 Sonnet".center(78) + "║")
    print("╚" + "═" * 78 + "╝")

    start_time = datetime.now()

    # Pre-flight checks
    print_banner("PRE-FLIGHT CHECKS")

    if not check_dependencies():
        sys.exit(1)

    if not check_api_key():
        sys.exit(1)

    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    excel_path = os.path.join(os.path.dirname(__file__), excel_file)

    if not os.path.exists(excel_path):
        print(f"\n✗ Error: Excel file not found: {excel_file}")
        print(f"   Expected location: {excel_path}")
        sys.exit(1)

    print(f"\n✓ Excel file found: {excel_file}")

    print("\n" + "=" * 80)
    input("\n⏳ Press Enter to start the complete workflow...\n")

    # Run all steps
    steps = [
        (1, "Extract Excel Data", "EPMReport_Extraction_Enhanced.py", True),
        (2, "Capture Screenshots", "EPMReport_Screenshot_Visible.py", False),
        (3, "Analyze with Claude AI", "report_analysis_agent.py", True),
        (4, "Generate Word Documents", "word_document_generator.py", True),
    ]

    failed_steps = []

    for step_num, step_name, script_name, required in steps:
        success = run_step(step_num, step_name, script_name, required)

        if not success:
            if required:
                print(f"\n❌ Critical step {step_num} failed!")
                print(f"   Cannot continue workflow.")
                sys.exit(1)
            else:
                print(f"\n⚠ Optional step {step_num} failed but continuing...")
                failed_steps.append(step_name)

    # Summary
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()

    print_banner("WORKFLOW COMPLETE")

    print("\n✅ All steps completed successfully!")
    print(f"\n⏱️  Total time: {duration:.1f} seconds")

    if failed_steps:
        print(f"\n⚠️  Some optional steps had warnings:")
        for step in failed_steps:
            print(f"   • {step}")

    print("\n📁 Output files created:")
    print("   • Excel extraction results (JSON, HTML, TXT)")
    print("   • Sheet screenshots (PNG files)")
    print("   • Claude AI analysis (JSON)")
    print("   • Professional Word documents (DOCX)")

    print("\n📂 Check these folders:")
    script_dir = os.path.dirname(__file__)
    print(f"   • Main directory: {script_dir}")
    print(f"   • Screenshots: {os.path.join(script_dir, 'sheet_screenshots')}")
    print(f"   • Word reports: {os.path.join(script_dir, 'word_reports')}")

    print("\n" + "=" * 80)
    print("🎉 Thank you for using Excel Report Analysis Agent!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Workflow interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
