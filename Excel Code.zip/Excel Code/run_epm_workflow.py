"""
EPM Report Reverse Engineering - Complete Workflow
Runs all steps to analyze and document EPM reports for reconstruction
"""

import os
import sys
from datetime import datetime


def print_banner(text):
    """Print formatted banner"""
    print("\n" + "=" * 80)
    print(text.center(80))
    print("=" * 80)


def main():
    """Main EPM workflow execution"""

    print("\n")
    print("╔" + "═" * 78 + "╗")
    print("║" + "EPM REPORT REVERSE ENGINEERING WORKFLOW".center(78) + "║")
    print("║" + "Extract • Analyze • Document • Reconstruct".center(78) + "║")
    print("║" + "Powered by Claude 4.5 Sonnet".center(78) + "║")
    print("╚" + "═" * 78 + "╝")

    start_time = datetime.now()

    # Check dependencies
    print_banner("PRE-FLIGHT CHECKS")

    print("\n🔍 Checking dependencies...")

    required = {
        'openpyxl': 'Excel processing',
        'xlwings': 'Excel automation',
        'PIL': 'Image processing',
        'anthropic': 'Claude API',
        'docx': 'Word documents'
    }

    missing = []
    for package, desc in required.items():
        try:
            __import__(package)
            print(f"   ✓ {package} - {desc}")
        except ImportError:
            print(f"   ✗ {package} - {desc} [MISSING]")
            missing.append(package)

    if missing:
        print("\n❌ Missing dependencies!")
        print("Install: pip install -r requirements.txt")
        sys.exit(1)

    print("\n✅ All dependencies installed")

    # Check API key
    print("\n🔑 Checking API key...")
    api_key = os.environ.get("ANTHROPIC_API_KEY")

    if not api_key:
        print("   ✗ ANTHROPIC_API_KEY not set")
        print("\n❌ API key required!")
        print("\nSet your key:")
        print("   export ANTHROPIC_API_KEY='your-key-here'")
        print("\nGet key from: https://console.anthropic.com/")
        sys.exit(1)

    print(f"   ✓ API key found: {api_key[:8]}...{api_key[-4:]}")

    # Check Excel file
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    excel_path = os.path.join(os.path.dirname(__file__), excel_file)

    if not os.path.exists(excel_path):
        print(f"\n✗ Excel file not found: {excel_file}")
        sys.exit(1)

    print(f"\n✓ Excel file found: {excel_file}")

    print("\n" + "=" * 80)
    input("\n⏳ Press Enter to start EPM reverse engineering workflow...\n")

    # STEP 1: Extract Excel data
    print_banner("STEP 1: EXTRACT EXCEL DATA")
    print("\nRunning: EPMReport_Extraction_Enhanced.py")
    print("-" * 80)

    try:
        from EPMReport_Extraction_Enhanced import EnhancedExcelExtractor

        extractor = EnhancedExcelExtractor(excel_path, extract_hidden=True, extract_visible=True)
        results = extractor.extract_all()

        print(f"\n✓ Step 1 completed")

    except Exception as e:
        print(f"\n✗ Step 1 failed: {str(e)}")
        sys.exit(1)

    # STEP 2: Capture screenshots
    print_banner("STEP 2: CAPTURE REPORT SCREENSHOTS")
    print("\nRunning: EPMReport_Screenshot_Visible.py")
    print("-" * 80)

    try:
        from EPMReport_Screenshot_Visible import take_excel_screenshots

        success = take_excel_screenshots(excel_path)

        if success:
            print(f"\n✓ Step 2 completed")
        else:
            print(f"\n⚠ Step 2 completed with warnings (continuing)")

    except Exception as e:
        print(f"\n⚠ Step 2 warning: {str(e)} (continuing)")

    # STEP 3: EPM Analysis
    print_banner("STEP 3: EPM REVERSE ENGINEERING ANALYSIS")
    print("\nRunning: epm_report_analyzer.py")
    print("Model: Claude 4.5 Sonnet")
    print("-" * 80)

    try:
        from epm_report_analyzer import EPMReportAnalyzer

        analyzer = EPMReportAnalyzer(api_key=api_key)
        analyses = analyzer.analyze_all_epm_reports(excel_path)

        print(f"\n✓ Step 3 completed: {len(analyses)} reports analyzed")

    except Exception as e:
        print(f"\n✗ Step 3 failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    # STEP 4: Generate reconstruction docs
    print_banner("STEP 4: GENERATE RECONSTRUCTION DOCUMENTS")
    print("\nRunning: epm_word_report_generator.py")
    print("-" * 80)

    try:
        from epm_word_report_generator import EPMWordReportGenerator

        analysis_json = excel_path.replace('.xlsx', '_epm_analysis.json')

        generator = EPMWordReportGenerator()
        docs = generator.generate_all_epm_docs(
            analysis_json_path=analysis_json,
            include_screenshots=True
        )

        print(f"\n✓ Step 4 completed: {len(docs)} documents generated")

    except Exception as e:
        print(f"\n✗ Step 4 failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    # Summary
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()

    print_banner("WORKFLOW COMPLETE")

    print("\n✅ EPM Reverse Engineering completed successfully!")
    print(f"\n⏱️  Total time: {duration:.1f} seconds")

    print("\n📁 Generated outputs:")
    print("   ✓ Excel extraction (JSON, HTML, TXT)")
    print("   ✓ Report screenshots (PNG)")
    print("   ✓ EPM analysis (JSON)")
    print("   ✓ Reconstruction documents (DOCX)")

    script_dir = os.path.dirname(__file__)
    print("\n📂 Output locations:")
    print(f"   • Main files: {script_dir}")
    print(f"   • Screenshots: {os.path.join(script_dir, 'sheet_screenshots')}")
    print(f"   • Reconstruction docs: {os.path.join(script_dir, 'epm_reconstruction_docs')}")

    print("\n📄 Each Word document contains:")
    print("   1. Report/Workbook Identification")
    print("   2. Dimensions Analysis (attributes, hierarchies, sorting)")
    print("   3. Measures/KPIs Analysis (calculations, formats)")
    print("   4. Formulas & Business Logic")
    print("   5. EPM Functions Usage")
    print("   6. Report Structure")
    print("   7. Reconstruction Blueprint")
    print("   8. Technical Appendix (formulas, VBA, metadata)")

    print("\n" + "=" * 80)
    print("🎉 EPM Reports ready for reconstruction!")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Workflow interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
