"""
Enhanced Excel Report Extraction Script
Extracts all details and generates formatted HTML report
"""

import openpyxl
from openpyxl.utils import get_column_letter
import json
import os
from datetime import datetime


class EnhancedExcelExtractor:
    def __init__(self, excel_file_path, extract_hidden=True, extract_visible=True):
        self.excel_file_path = excel_file_path
        self.extract_hidden = extract_hidden
        self.extract_visible = extract_visible
        self.workbook = openpyxl.load_workbook(excel_file_path, data_only=False, keep_vba=True)
        self.extraction_data = {
            "file_name": os.path.basename(excel_file_path),
            "extraction_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "sheets": {},
            "sheet_visibility": {}
        }

    def extract_all(self):
        """Extract all information from the Excel file"""
        print(f"Starting extraction from: {self.excel_file_path}")
        print("=" * 80)

        self.extract_workbook_properties()
        self.extract_vba_macros()
        self.extract_all_sheets()
        self.save_results()

        print("\n" + "=" * 80)
        print("✓ Extraction completed successfully!")

        return self.extraction_data

    def extract_workbook_properties(self):
        """Extract workbook-level properties"""
        print("\n[1] Extracting Workbook Properties...")

        props = self.workbook.properties
        self.extraction_data["workbook_properties"] = {
            "title": props.title,
            "subject": props.subject,
            "creator": props.creator,
            "created": str(props.created),
            "modified": str(props.modified),
            "last_modified_by": props.lastModifiedBy,
            "category": props.category,
            "keywords": props.keywords,
            "description": props.description,
            "sheet_names": self.workbook.sheetnames,
            "total_sheets": len(self.workbook.sheetnames)
        }

        print(f"   ✓ Total sheets: {len(self.workbook.sheetnames)}")

    def extract_vba_macros(self):
        """Extract VBA macros if present"""
        print("\n[2] Extracting VBA Macros...")

        if self.workbook.vba_archive:
            self.extraction_data["vba_macros"] = {
                "has_macros": True,
                "vba_archive_present": True
            }

            try:
                vba_files = self.workbook.vba_archive.namelist()
                self.extraction_data["vba_macros"]["vba_files"] = vba_files
                print(f"   ✓ VBA macros found! Files in archive: {len(vba_files)}")

                vba_project_file = None
                for filename in vba_files:
                    if 'vbaProject.bin' in filename:
                        vba_project_file = filename
                        break

                if vba_project_file:
                    vba_data = self.workbook.vba_archive.read(vba_project_file)
                    vba_size = len(vba_data) if vba_data else 0
                    self.extraction_data["vba_macros"]["vba_project_size_bytes"] = vba_size
                    print(f"   ✓ VBA project file size: {vba_size:,} bytes")
                else:
                    print(f"   ℹ VBA archive present but vbaProject.bin not found")

            except Exception as e:
                print(f"   ⚠ Warning: Could not extract VBA binary: {str(e)}")
                self.extraction_data["vba_macros"]["extraction_error"] = str(e)
        else:
            self.extraction_data["vba_macros"] = {
                "has_macros": False
            }
            print("   ℹ No VBA macros found")

    def extract_all_sheets(self):
        """Extract data from all sheets"""
        print("\n[3] Extracting Sheet Data...")

        visible_sheets = []
        hidden_sheets = []

        for sheet_name in self.workbook.sheetnames:
            sheet = self.workbook[sheet_name]
            is_visible = sheet.sheet_state == 'visible'
            self.extraction_data["sheet_visibility"][sheet_name] = {
                "state": sheet.sheet_state,
                "is_visible": is_visible
            }

            if is_visible:
                visible_sheets.append(sheet_name)
            else:
                hidden_sheets.append(sheet_name)

        print(f"\n   📊 Sheet Summary:")
        print(f"      • Total sheets: {len(self.workbook.sheetnames)}")
        print(f"      • Visible sheets: {len(visible_sheets)}")
        print(f"      • Hidden sheets: {len(hidden_sheets)}")

        for sheet_name in self.workbook.sheetnames:
            sheet = self.workbook[sheet_name]
            is_visible = sheet.sheet_state == 'visible'

            if is_visible and not self.extract_visible:
                continue
            if not is_visible and not self.extract_hidden:
                continue

            visibility_icon = "👁️" if is_visible else "🔒"
            print(f"\n   {visibility_icon} Processing: '{sheet_name}' ({'visible' if is_visible else 'hidden'})")

            sheet_data = self.extract_sheet_data(sheet, sheet_name)
            self.extraction_data["sheets"][sheet_name] = sheet_data

    def extract_sheet_data(self, sheet, sheet_name):
        """Extract data from a single sheet"""
        sheet_data = {
            "sheet_name": sheet_name,
            "dimensions": str(sheet.dimensions),
            "max_row": sheet.max_row,
            "max_column": sheet.max_column,
            "cells": {},
            "formulas": {},
            "merged_cells": [],
            "data_validations": [],
            "conditional_formatting": {},
            "sheet_properties": {
                "sheet_state": sheet.sheet_state,
            }
        }

        # Extract merged cells
        if sheet.merged_cells:
            sheet_data["merged_cells"] = [str(merged_cell) for merged_cell in sheet.merged_cells.ranges]
            print(f"      • Merged cells: {len(sheet_data['merged_cells'])}")

        # Extract conditional formatting
        if sheet.conditional_formatting:
            try:
                for range_string, rules in sheet.conditional_formatting._cf_rules.items():
                    range_key = str(range_string)
                    sheet_data["conditional_formatting"][range_key] = [
                        {
                            "type": str(rule.type) if hasattr(rule, 'type') else None,
                            "priority": rule.priority if hasattr(rule, 'priority') else None,
                        }
                        for rule in rules
                    ]
                print(f"      • Conditional formatting: {len(sheet_data['conditional_formatting'])}")
            except Exception as e:
                sheet_data["conditional_formatting"] = {}

        # Extract cell data
        cell_count = 0
        formula_count = 0

        for row in sheet.iter_rows():
            for cell in row:
                if cell.value is not None or cell.has_style:
                    cell_ref = f"{get_column_letter(cell.column)}{cell.row}"

                    cell_info = {
                        "value": str(cell.value) if cell.value is not None else None,
                        "data_type": cell.data_type,
                        "number_format": cell.number_format,
                    }

                    if cell.data_type == 'f':
                        formula_count += 1
                        sheet_data["formulas"][cell_ref] = str(cell.value)
                        cell_info["is_formula"] = True

                    sheet_data["cells"][cell_ref] = cell_info
                    cell_count += 1

        print(f"      • Cells with data: {cell_count:,}")
        print(f"      • Formulas: {formula_count}")

        return sheet_data

    def save_results(self):
        """Save extraction results"""
        print("\n[4] Saving Results...")

        # Save JSON
        output_json = self.excel_file_path.replace('.xlsx', '_extraction_results.json')
        with open(output_json, 'w', encoding='utf-8') as f:
            json.dump(self.extraction_data, indent=2, fp=f, default=str)
        print(f"   ✓ JSON saved: {os.path.basename(output_json)}")

        # Generate HTML report
        self.generate_html_report()

        # Generate formatted text report
        self.generate_text_report()

    def generate_html_report(self):
        """Generate a beautiful HTML report"""
        output_html = self.excel_file_path.replace('.xlsx', '_report.html')

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excel Extraction Report - {self.extraction_data['file_name']}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
            padding: 20px;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}

        h1 {{
            color: #2c3e50;
            margin-bottom: 10px;
            font-size: 2.5em;
            border-bottom: 4px solid #3498db;
            padding-bottom: 15px;
        }}

        h2 {{
            color: #34495e;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.8em;
            border-left: 5px solid #3498db;
            padding-left: 15px;
        }}

        h3 {{
            color: #555;
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 1.3em;
        }}

        .meta-info {{
            background: #ecf0f1;
            padding: 20px;
            border-radius: 5px;
            margin: 20px 0;
        }}

        .meta-info p {{
            margin: 8px 0;
            font-size: 0.95em;
        }}

        .meta-info strong {{
            color: #2c3e50;
            min-width: 150px;
            display: inline-block;
        }}

        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}

        .stat-card {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}

        .stat-card.green {{
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
        }}

        .stat-card.blue {{
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }}

        .stat-card.orange {{
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        }}

        .stat-number {{
            font-size: 3em;
            font-weight: bold;
            margin: 10px 0;
        }}

        .stat-label {{
            font-size: 1.1em;
            opacity: 0.9;
        }}

        .sheet-list {{
            list-style: none;
        }}

        .sheet-item {{
            background: #fff;
            border: 1px solid #ddd;
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            transition: all 0.3s;
        }}

        .sheet-item:hover {{
            border-color: #3498db;
            box-shadow: 0 2px 8px rgba(52, 152, 219, 0.2);
        }}

        .sheet-item.visible {{
            border-left: 5px solid #27ae60;
        }}

        .sheet-item.hidden {{
            border-left: 5px solid #e74c3c;
            opacity: 0.8;
        }}

        .sheet-name {{
            font-size: 1.2em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }}

        .sheet-details {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 10px;
            font-size: 0.9em;
        }}

        .detail-item {{
            background: #f8f9fa;
            padding: 8px 12px;
            border-radius: 4px;
        }}

        .detail-label {{
            color: #7f8c8d;
            font-size: 0.85em;
            display: block;
        }}

        .detail-value {{
            color: #2c3e50;
            font-weight: 600;
            font-size: 1.1em;
        }}

        .formulas-section {{
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
            border-left: 3px solid #3498db;
        }}

        .formula-item {{
            font-family: 'Courier New', monospace;
            background: white;
            padding: 8px;
            margin: 5px 0;
            border-radius: 3px;
            font-size: 0.9em;
            border: 1px solid #e0e0e0;
        }}

        .formula-ref {{
            color: #e74c3c;
            font-weight: bold;
            margin-right: 10px;
        }}

        .formula-text {{
            color: #27ae60;
        }}

        .badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.85em;
            font-weight: 600;
            margin-left: 10px;
        }}

        .badge.visible {{
            background: #d4edda;
            color: #155724;
        }}

        .badge.hidden {{
            background: #f8d7da;
            color: #721c24;
        }}

        .vba-section {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }}

        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }}

        th {{
            background: #3498db;
            color: white;
            font-weight: 600;
        }}

        tr:hover {{
            background: #f5f5f5;
        }}

        .footer {{
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ecf0f1;
            text-align: center;
            color: #7f8c8d;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 Excel Extraction Report</h1>

        <div class="meta-info">
            <p><strong>File Name:</strong> {self.extraction_data['file_name']}</p>
            <p><strong>Extraction Date:</strong> {self.extraction_data['extraction_date']}</p>
            <p><strong>Creator:</strong> {self.extraction_data['workbook_properties'].get('creator', 'N/A')}</p>
            <p><strong>Last Modified:</strong> {self.extraction_data['workbook_properties'].get('modified', 'N/A')}</p>
            <p><strong>Modified By:</strong> {self.extraction_data['workbook_properties'].get('last_modified_by', 'N/A')}</p>
        </div>

        <h2>📈 Statistics Overview</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Total Sheets</div>
                <div class="stat-number">{len(self.extraction_data['sheets'])}</div>
            </div>
            <div class="stat-card green">
                <div class="stat-label">Total Cells</div>
                <div class="stat-number">{sum(len(sheet['cells']) for sheet in self.extraction_data['sheets'].values()):,}</div>
            </div>
            <div class="stat-card blue">
                <div class="stat-label">Total Formulas</div>
                <div class="stat-number">{sum(len(sheet['formulas']) for sheet in self.extraction_data['sheets'].values())}</div>
            </div>
            <div class="stat-card orange">
                <div class="stat-label">VBA Macros</div>
                <div class="stat-number">{'YES' if self.extraction_data['vba_macros'].get('has_macros') else 'NO'}</div>
            </div>
        </div>
"""

        # Add VBA section if macros exist
        if self.extraction_data['vba_macros'].get('has_macros'):
            vba_files = self.extraction_data['vba_macros'].get('vba_files', [])
            html_content += f"""
        <h2>🔧 VBA Macros</h2>
        <div class="vba-section">
            <p><strong>VBA Archive Present:</strong> Yes</p>
            <p><strong>Total VBA Files:</strong> {len(vba_files)}</p>
            <p><strong>VBA Project Size:</strong> {self.extraction_data['vba_macros'].get('vba_project_size_bytes', 0):,} bytes</p>
        </div>
"""

        # Add visibility summary
        visible_count = sum(1 for v in self.extraction_data['sheet_visibility'].values() if v['is_visible'])
        hidden_count = len(self.extraction_data['sheet_visibility']) - visible_count

        html_content += f"""
        <h2>👁️ Sheet Visibility</h2>
        <div class="meta-info">
            <p><strong>Visible Sheets:</strong> {visible_count}</p>
            <p><strong>Hidden Sheets:</strong> {hidden_count}</p>
        </div>
"""

        # Add sheets details
        html_content += """
        <h2>📑 Sheet Details</h2>
        <ul class="sheet-list">
"""

        for sheet_name, sheet_data in self.extraction_data['sheets'].items():
            is_visible = self.extraction_data['sheet_visibility'][sheet_name]['is_visible']
            visibility_class = 'visible' if is_visible else 'hidden'
            visibility_badge = 'VISIBLE' if is_visible else 'HIDDEN'

            html_content += f"""
            <li class="sheet-item {visibility_class}">
                <div class="sheet-name">
                    {sheet_name}
                    <span class="badge {visibility_class}">{visibility_badge}</span>
                </div>
                <div class="sheet-details">
                    <div class="detail-item">
                        <span class="detail-label">Dimensions</span>
                        <span class="detail-value">{sheet_data.get('dimensions', 'N/A')}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Max Row</span>
                        <span class="detail-value">{sheet_data.get('max_row', 0):,}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Max Column</span>
                        <span class="detail-value">{sheet_data.get('max_column', 0)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Cells with Data</span>
                        <span class="detail-value">{len(sheet_data.get('cells', {})):,}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Formulas</span>
                        <span class="detail-value">{len(sheet_data.get('formulas', {}))}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Merged Cells</span>
                        <span class="detail-value">{len(sheet_data.get('merged_cells', []))}</span>
                    </div>
                </div>
"""

            # Add formulas if present
            formulas = sheet_data.get('formulas', {})
            if formulas:
                html_content += """
                <div class="formulas-section">
                    <h3>📐 Formulas:</h3>
"""
                # Limit to first 20 formulas for display
                for cell_ref, formula in list(formulas.items())[:20]:
                    formula_display = formula[:100] + "..." if len(formula) > 100 else formula
                    html_content += f"""
                    <div class="formula-item">
                        <span class="formula-ref">{cell_ref}:</span>
                        <span class="formula-text">{formula_display}</span>
                    </div>
"""
                if len(formulas) > 20:
                    html_content += f"""
                    <p style="margin-top: 10px; color: #7f8c8d; font-style: italic;">
                        ... and {len(formulas) - 20} more formulas
                    </p>
"""
                html_content += """
                </div>
"""

            html_content += """
            </li>
"""

        html_content += """
        </ul>

        <div class="footer">
            <p>Generated by Excel Extraction Tool | {}</p>
        </div>
    </div>
</body>
</html>
""".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

        with open(output_html, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"   ✓ HTML report saved: {os.path.basename(output_html)}")

    def generate_text_report(self):
        """Generate formatted text report"""
        output_txt = self.excel_file_path.replace('.xlsx', '_summary_report.txt')

        with open(output_txt, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write("EXCEL EXTRACTION SUMMARY REPORT\n")
            f.write("=" * 80 + "\n\n")

            f.write(f"File: {self.extraction_data['file_name']}\n")
            f.write(f"Extraction Date: {self.extraction_data['extraction_date']}\n\n")

            f.write("WORKBOOK PROPERTIES:\n")
            f.write("-" * 80 + "\n")
            props = self.extraction_data.get("workbook_properties", {})
            for key, value in props.items():
                if key != "sheet_names":
                    f.write(f"  {key}: {value}\n")

            f.write("\nSTATISTICS:\n")
            f.write("-" * 80 + "\n")
            total_cells = sum(len(sheet['cells']) for sheet in self.extraction_data['sheets'].values())
            total_formulas = sum(len(sheet['formulas']) for sheet in self.extraction_data['sheets'].values())
            f.write(f"  Total Sheets: {len(self.extraction_data['sheets'])}\n")
            f.write(f"  Total Cells: {total_cells:,}\n")
            f.write(f"  Total Formulas: {total_formulas}\n")
            f.write(f"  VBA Macros: {'Yes' if self.extraction_data['vba_macros'].get('has_macros') else 'No'}\n")

        print(f"   ✓ Text summary saved: {os.path.basename(output_txt)}")


def main():
    """Main execution function"""
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(script_dir, excel_file)

    if not os.path.exists(excel_path):
        print(f"✗ Error: Excel file not found at {excel_path}")
        return

    print("\n" + "=" * 80)
    print("📊 ENHANCED EXCEL EXTRACTION TOOL")
    print("=" * 80)
    print(f"\nTarget file: {excel_file}")

    try:
        import openpyxl
        print("✓ openpyxl library is installed\n")
    except ImportError:
        print("\n✗ Error: openpyxl library is not installed")
        print("Install it with: pip install openpyxl")
        return

    try:
        extractor = EnhancedExcelExtractor(excel_path, extract_hidden=True, extract_visible=True)
        results = extractor.extract_all()

        print("\n" + "=" * 80)
        print("📈 EXTRACTION STATISTICS")
        print("=" * 80)
        print(f"Total sheets processed: {len(results['sheets'])}")
        print(f"Total cells: {sum(len(sheet['cells']) for sheet in results['sheets'].values()):,}")
        print(f"Total formulas: {sum(len(sheet['formulas']) for sheet in results['sheets'].values())}")
        print(f"VBA Macros: {'Yes' if results.get('vba_macros', {}).get('has_macros') else 'No'}")

    except Exception as e:
        print(f"\n✗ Error during extraction: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
