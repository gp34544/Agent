"""
Report Analysis Agent
Uses Claude 4.5 Sonnet to analyze Excel reports and screenshots
Generates comprehensive analysis for Word document generation
"""

import os
import json
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import anthropic


class ReportAnalysisAgent:
    """Agent that analyzes Excel reports using Claude 4.5 Sonnet"""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the analysis agent

        Args:
            api_key: Anthropic API key (if None, will look for ANTHROPIC_API_KEY env var)
        """
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Anthropic API key required. Set ANTHROPIC_API_KEY environment variable "
                "or pass api_key parameter."
            )

        self.client = anthropic.Anthropic(api_key=self.api_key)
        self.model = "claude-sonnet-4-5-20250929"

    def encode_image(self, image_path: str) -> Tuple[str, str]:
        """
        Encode image to base64

        Args:
            image_path: Path to the image file

        Returns:
            Tuple of (base64_data, media_type)
        """
        with open(image_path, "rb") as image_file:
            image_data = base64.standard_b64encode(image_file.read()).decode("utf-8")

        # Determine media type from extension
        ext = Path(image_path).suffix.lower()
        media_type_map = {
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.webp': 'image/webp'
        }
        media_type = media_type_map.get(ext, 'image/png')

        return image_data, media_type

    def analyze_single_report(
        self,
        sheet_name: str,
        excel_data: Dict,
        screenshot_path: Optional[str] = None
    ) -> Dict:
        """
        Analyze a single Excel report sheet

        Args:
            sheet_name: Name of the sheet being analyzed
            excel_data: Extracted Excel data for this sheet
            screenshot_path: Path to screenshot image (optional)

        Returns:
            Dictionary containing analysis results
        """
        print(f"\n🔍 Analyzing sheet: '{sheet_name}'")

        # Prepare the analysis prompt
        prompt = self._create_analysis_prompt(sheet_name, excel_data)

        # Build message content
        message_content = []

        # Add screenshot if available
        if screenshot_path and os.path.exists(screenshot_path):
            print(f"   📸 Including screenshot: {os.path.basename(screenshot_path)}")
            image_data, media_type = self.encode_image(screenshot_path)
            message_content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": image_data,
                }
            })

        # Add text prompt
        message_content.append({
            "type": "text",
            "text": prompt
        })

        # Call Claude API
        try:
            print(f"   🤖 Querying Claude 4.5 Sonnet...")
            response = self.client.messages.create(
                model=self.model,
                max_tokens=4096,
                messages=[
                    {
                        "role": "user",
                        "content": message_content
                    }
                ]
            )

            analysis_text = response.content[0].text
            print(f"   ✓ Analysis complete ({len(analysis_text)} characters)")

            # Parse the structured response
            analysis_result = self._parse_analysis_response(
                sheet_name,
                analysis_text,
                excel_data,
                screenshot_path
            )

            return analysis_result

        except Exception as e:
            print(f"   ✗ Error during analysis: {str(e)}")
            return {
                "sheet_name": sheet_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def _create_analysis_prompt(self, sheet_name: str, excel_data: Dict) -> str:
        """Create comprehensive analysis prompt"""

        # Extract key information
        dimensions = excel_data.get('dimensions', 'Unknown')
        cell_count = len(excel_data.get('cells', {}))
        formula_count = len(excel_data.get('formulas', {}))
        merged_cells = len(excel_data.get('merged_cells', []))

        # Sample some cell data (first 50 cells for context)
        cells = excel_data.get('cells', {})
        sample_cells = dict(list(cells.items())[:50])

        prompt = f"""You are an expert financial and business analyst. Analyze this Excel report sheet and provide a comprehensive analysis.

**SHEET INFORMATION:**
- Sheet Name: {sheet_name}
- Dimensions: {dimensions}
- Total Cells with Data: {cell_count:,}
- Number of Formulas: {formula_count}
- Merged Cells: {merged_cells}

**SAMPLE DATA (First 50 cells):**
{json.dumps(sample_cells, indent=2)}

**ANALYSIS REQUIRED:**
Please provide a detailed analysis in the following structured format:

1. **EXECUTIVE SUMMARY**
   - Brief overview of what this report contains
   - Main purpose and audience
   - Key timeframes or periods covered

2. **DATA STRUCTURE ANALYSIS**
   - Report type (financial statement, KPI dashboard, data table, etc.)
   - Main sections identified
   - Data organization and hierarchy
   - Any notable formatting or structure patterns

3. **KEY METRICS & INSIGHTS**
   - Identify the most important metrics/KPIs
   - Highlight any trends, patterns, or anomalies
   - Notable values or calculations
   - Any red flags or items requiring attention

4. **FORMULAS & CALCULATIONS**
   - Summary of calculation methodologies
   - Complex formulas identified
   - Data dependencies and relationships

5. **BUSINESS CONTEXT**
   - What business questions does this report answer?
   - Who would use this report and why?
   - How does this fit into business operations?

6. **RECOMMENDATIONS**
   - Suggested improvements or optimizations
   - Potential data quality issues
   - Areas for further investigation

Please provide clear, professional analysis suitable for inclusion in a formal business report."""

        return prompt

    def _parse_analysis_response(
        self,
        sheet_name: str,
        analysis_text: str,
        excel_data: Dict,
        screenshot_path: Optional[str]
    ) -> Dict:
        """Parse and structure the analysis response"""

        return {
            "sheet_name": sheet_name,
            "analysis_timestamp": datetime.now().isoformat(),
            "claude_model": self.model,

            # Full analysis text
            "full_analysis": analysis_text,

            # Metadata
            "metadata": {
                "dimensions": excel_data.get('dimensions'),
                "cell_count": len(excel_data.get('cells', {})),
                "formula_count": len(excel_data.get('formulas', {})),
                "merged_cells_count": len(excel_data.get('merged_cells', [])),
                "has_screenshot": screenshot_path is not None and os.path.exists(screenshot_path),
                "screenshot_path": screenshot_path if screenshot_path and os.path.exists(screenshot_path) else None
            },

            # Excel data reference
            "excel_data": excel_data,
        }

    def analyze_all_reports(
        self,
        excel_file_path: str,
        extraction_results_path: Optional[str] = None,
        screenshots_folder: Optional[str] = None
    ) -> List[Dict]:
        """
        Analyze all visible (non-hidden) sheets from an Excel file

        Args:
            excel_file_path: Path to the Excel file
            extraction_results_path: Path to JSON extraction results (optional)
            screenshots_folder: Path to folder containing screenshots (optional)

        Returns:
            List of analysis results for each sheet
        """
        print("\n" + "=" * 80)
        print("📊 REPORT ANALYSIS AGENT - Claude 4.5 Sonnet")
        print("=" * 80)
        print(f"\nExcel File: {os.path.basename(excel_file_path)}")

        # Load extraction results
        if extraction_results_path is None:
            extraction_results_path = excel_file_path.replace('.xlsx', '_extraction_results.json')

        if not os.path.exists(extraction_results_path):
            raise FileNotFoundError(
                f"Extraction results not found: {extraction_results_path}\n"
                f"Please run EPMReport_Extraction_Enhanced.py first."
            )

        print(f"Loading: {os.path.basename(extraction_results_path)}")
        with open(extraction_results_path, 'r', encoding='utf-8') as f:
            extraction_data = json.load(f)

        # Determine screenshots folder
        if screenshots_folder is None:
            screenshots_folder = os.path.join(
                os.path.dirname(excel_file_path),
                "sheet_screenshots"
            )

        # Get all sheets, filter for visible ones only
        all_sheets = extraction_data.get('sheets', {})
        sheet_visibility = extraction_data.get('sheet_visibility', {})

        visible_sheets = [
            sheet_name for sheet_name in all_sheets.keys()
            if sheet_visibility.get(sheet_name, {}).get('is_visible', False)
        ]

        print(f"\n📋 Found {len(visible_sheets)} visible sheets to analyze")
        print(f"   (Skipping {len(all_sheets) - len(visible_sheets)} hidden sheets)")
        print("-" * 80)

        # Analyze each visible sheet
        all_analyses = []

        for idx, sheet_name in enumerate(visible_sheets, 1):
            print(f"\n[{idx}/{len(visible_sheets)}] Processing: '{sheet_name}'")

            sheet_data = all_sheets[sheet_name]

            # Find corresponding screenshot
            screenshot_path = self._find_screenshot(sheet_name, screenshots_folder)

            # Analyze the sheet
            analysis = self.analyze_single_report(
                sheet_name=sheet_name,
                excel_data=sheet_data,
                screenshot_path=screenshot_path
            )

            all_analyses.append(analysis)

        print("\n" + "=" * 80)
        print(f"✓ ANALYSIS COMPLETE: {len(all_analyses)} reports analyzed")
        print("=" * 80)

        # Save all analyses to JSON
        output_path = excel_file_path.replace('.xlsx', '_claude_analysis.json')
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                'file_name': os.path.basename(excel_file_path),
                'analysis_timestamp': datetime.now().isoformat(),
                'model': self.model,
                'total_reports': len(all_analyses),
                'analyses': all_analyses
            }, f, indent=2, default=str)

        print(f"\n💾 Analysis results saved: {os.path.basename(output_path)}")

        return all_analyses

    def _find_screenshot(self, sheet_name: str, screenshots_folder: str) -> Optional[str]:
        """Find screenshot file for a given sheet name"""

        if not os.path.exists(screenshots_folder):
            return None

        # Create safe filename from sheet name (same logic as screenshot tool)
        safe_name = "".join(
            c if c.isalnum() or c in (' ', '-', '_') else '_'
            for c in sheet_name
        )

        screenshot_path = os.path.join(screenshots_folder, f"{safe_name}.png")

        if os.path.exists(screenshot_path):
            return screenshot_path

        return None


def main():
    """Main execution function"""

    # Configuration
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(script_dir, excel_file)

    # Check if file exists
    if not os.path.exists(excel_path):
        print(f"\n✗ Error: Excel file not found at {excel_path}")
        return

    # Check for API key
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("\n✗ Error: ANTHROPIC_API_KEY environment variable not set")
        print("\nTo set your API key:")
        print("  macOS/Linux: export ANTHROPIC_API_KEY='your-api-key-here'")
        print("  Windows: set ANTHROPIC_API_KEY=your-api-key-here")
        print("\nGet your API key from: https://console.anthropic.com/")
        return

    print("\n" + "=" * 80)
    print("🤖 REPORT ANALYSIS AGENT")
    print("=" * 80)
    print(f"\nTarget file: {excel_file}")
    print(f"Model: Claude 4.5 Sonnet")
    print(f"API Key: {api_key[:8]}...{api_key[-4:]}")

    # Check dependencies
    try:
        import anthropic
        print("\n✓ Anthropic SDK installed")
    except ImportError:
        print("\n✗ Error: anthropic library not installed")
        print("Install it with: pip install anthropic")
        return

    input("\nPress Enter to start analysis...")

    try:
        # Create agent
        agent = ReportAnalysisAgent(api_key=api_key)

        # Analyze all reports
        analyses = agent.analyze_all_reports(excel_path)

        print(f"\n✅ SUCCESS! {len(analyses)} reports analyzed.")
        print("\nNext step: Run word_document_generator.py to create Word documents")

    except FileNotFoundError as e:
        print(f"\n✗ Error: {str(e)}")
        print("\n💡 Make sure to run EPMReport_Extraction_Enhanced.py first!")

    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
