"""
Word Document Generator
Creates professional Word documents from Claude analysis results
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


class WordDocumentGenerator:
    """Generates professional Word documents from analysis results"""

    def __init__(self):
        """Initialize the Word document generator"""
        self.default_font = "Calibri"
        self.heading_font = "Arial"

    def create_document_for_report(
        self,
        analysis_data: Dict,
        output_path: str,
        include_screenshot: bool = True
    ) -> bool:
        """
        Create a Word document for a single report analysis

        Args:
            analysis_data: Analysis results from Claude
            output_path: Path where to save the document
            include_screenshot: Whether to include screenshot image

        Returns:
            True if successful, False otherwise
        """
        try:
            print(f"\n📄 Creating document: {os.path.basename(output_path)}")

            # Create new document
            doc = Document()

            # Set up styles
            self._setup_document_styles(doc)

            # Add content
            self._add_title_page(doc, analysis_data)
            doc.add_page_break()

            self._add_executive_summary_section(doc, analysis_data)

            self._add_screenshot_section(doc, analysis_data, include_screenshot)

            self._add_detailed_analysis_section(doc, analysis_data)

            self._add_metadata_section(doc, analysis_data)

            self._add_footer(doc, analysis_data)

            # Save document
            doc.save(output_path)

            file_size = os.path.getsize(output_path) / 1024  # KB
            print(f"   ✓ Document saved ({file_size:.1f} KB)")

            return True

        except Exception as e:
            print(f"   ✗ Error creating document: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    def _setup_document_styles(self, doc: Document):
        """Set up custom styles for the document"""

        styles = doc.styles

        # Modify Normal style
        style_normal = styles['Normal']
        style_normal.font.name = self.default_font
        style_normal.font.size = Pt(11)

        # Modify Heading styles
        for i in range(1, 4):
            style_heading = styles[f'Heading {i}']
            style_heading.font.name = self.heading_font
            style_heading.font.bold = True
            style_heading.font.color.rgb = RGBColor(0, 51, 102)  # Dark blue

    def _add_title_page(self, doc: Document, analysis_data: Dict):
        """Add a professional title page"""

        sheet_name = analysis_data.get('sheet_name', 'Unknown Report')
        timestamp = analysis_data.get('analysis_timestamp', datetime.now().isoformat())

        # Parse timestamp
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            formatted_date = dt.strftime("%B %d, %Y at %I:%M %p")
        except:
            formatted_date = timestamp

        # Add title
        title = doc.add_heading(sheet_name, level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title.runs[0].font.size = Pt(28)
        title.runs[0].font.color.rgb = RGBColor(0, 51, 102)

        # Add spacing
        doc.add_paragraph()
        doc.add_paragraph()

        # Add subtitle
        subtitle = doc.add_paragraph("Excel Report Analysis")
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        subtitle.runs[0].font.size = Pt(18)
        subtitle.runs[0].font.color.rgb = RGBColor(100, 100, 100)

        doc.add_paragraph()
        doc.add_paragraph()
        doc.add_paragraph()

        # Add analysis info box
        info_para = doc.add_paragraph()
        info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

        info_text = f"""
Analyzed by: Claude 4.5 Sonnet
Analysis Date: {formatted_date}
Report Type: Financial & Business Intelligence
        """.strip()

        for line in info_text.split('\n'):
            info_para.add_run(line + '\n').font.size = Pt(12)

        # Add separator
        doc.add_paragraph()
        doc.add_paragraph()
        separator = doc.add_paragraph("━" * 50)
        separator.alignment = WD_ALIGN_PARAGRAPH.CENTER
        separator.runs[0].font.color.rgb = RGBColor(0, 51, 102)

        # Add metadata summary
        metadata = analysis_data.get('metadata', {})
        doc.add_paragraph()

        summary_para = doc.add_paragraph()
        summary_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

        summary_lines = [
            f"Total Cells: {metadata.get('cell_count', 0):,}",
            f"Formulas: {metadata.get('formula_count', 0)}",
            f"Merged Cells: {metadata.get('merged_cells_count', 0)}",
        ]

        for line in summary_lines:
            run = summary_para.add_run(line + ' | ')
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(100, 100, 100)

    def _add_executive_summary_section(self, doc: Document, analysis_data: Dict):
        """Add executive summary section"""

        doc.add_heading('Executive Summary', level=1)

        full_analysis = analysis_data.get('full_analysis', '')

        # Try to extract executive summary from full analysis
        summary_text = self._extract_section(full_analysis, 'EXECUTIVE SUMMARY')

        if summary_text:
            doc.add_paragraph(summary_text)
        else:
            doc.add_paragraph(
                "This report contains a comprehensive analysis of the Excel sheet, "
                "including data structure, key metrics, formulas, and business context."
            )

    def _add_screenshot_section(
        self,
        doc: Document,
        analysis_data: Dict,
        include_screenshot: bool
    ):
        """Add screenshot section if available"""

        metadata = analysis_data.get('metadata', {})
        screenshot_path = metadata.get('screenshot_path')

        if include_screenshot and screenshot_path and os.path.exists(screenshot_path):
            doc.add_page_break()
            doc.add_heading('Report Screenshot', level=1)

            doc.add_paragraph(
                f"Visual representation of the '{analysis_data.get('sheet_name')}' sheet:"
            )

            try:
                # Add image with appropriate sizing
                doc.add_picture(screenshot_path, width=Inches(6.5))
                print(f"   ✓ Screenshot included: {os.path.basename(screenshot_path)}")
            except Exception as e:
                doc.add_paragraph(f"[Screenshot could not be embedded: {str(e)}]")
                print(f"   ⚠ Could not embed screenshot: {str(e)}")

    def _add_detailed_analysis_section(self, doc: Document, analysis_data: Dict):
        """Add detailed analysis sections"""

        doc.add_page_break()
        doc.add_heading('Detailed Analysis', level=1)

        full_analysis = analysis_data.get('full_analysis', '')

        # Define sections to extract
        sections = [
            'DATA STRUCTURE ANALYSIS',
            'KEY METRICS & INSIGHTS',
            'FORMULAS & CALCULATIONS',
            'BUSINESS CONTEXT',
            'RECOMMENDATIONS'
        ]

        for section_name in sections:
            section_content = self._extract_section(full_analysis, section_name)

            if section_content:
                doc.add_heading(section_name.title(), level=2)

                # Add content with proper formatting
                paragraphs = section_content.split('\n\n')
                for para_text in paragraphs:
                    if para_text.strip():
                        # Check if it's a bullet point or numbered list
                        if para_text.strip().startswith(('-', '•', '*')):
                            # Bullet list
                            for line in para_text.split('\n'):
                                if line.strip():
                                    cleaned = line.strip().lstrip('-•* ')
                                    doc.add_paragraph(cleaned, style='List Bullet')
                        elif para_text.strip()[0].isdigit() and '.' in para_text.strip()[:3]:
                            # Numbered list
                            for line in para_text.split('\n'):
                                if line.strip():
                                    cleaned = line.strip()
                                    # Remove number prefix if present
                                    if '. ' in cleaned[:4]:
                                        cleaned = cleaned.split('. ', 1)[1] if len(cleaned.split('. ', 1)) > 1 else cleaned
                                    doc.add_paragraph(cleaned, style='List Number')
                        else:
                            doc.add_paragraph(para_text.strip())

                doc.add_paragraph()  # Add spacing

    def _add_metadata_section(self, doc: Document, analysis_data: Dict):
        """Add technical metadata section"""

        doc.add_page_break()
        doc.add_heading('Technical Details', level=1)

        metadata = analysis_data.get('metadata', {})

        # Create a table for metadata
        table = doc.add_table(rows=5, cols=2)
        table.style = 'Light Grid Accent 1'

        # Header row
        table.rows[0].cells[0].text = "Property"
        table.rows[0].cells[1].text = "Value"

        # Data rows
        table.rows[1].cells[0].text = "Sheet Dimensions"
        table.rows[1].cells[1].text = str(metadata.get('dimensions', 'N/A'))

        table.rows[2].cells[0].text = "Total Cells with Data"
        table.rows[2].cells[1].text = f"{metadata.get('cell_count', 0):,}"

        table.rows[3].cells[0].text = "Formula Count"
        table.rows[3].cells[1].text = str(metadata.get('formula_count', 0))

        table.rows[4].cells[0].text = "Merged Cells"
        table.rows[4].cells[1].text = str(metadata.get('merged_cells_count', 0))

        # Make header bold
        for cell in table.rows[0].cells:
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.font.bold = True

    def _add_footer(self, doc: Document, analysis_data: Dict):
        """Add footer with generation info"""

        section = doc.sections[0]
        footer = section.footer

        footer_para = footer.paragraphs[0]
        footer_para.text = f"Generated by Claude 4.5 Sonnet Analysis Agent | {datetime.now().strftime('%B %d, %Y')}"
        footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer_para.runs[0].font.size = Pt(9)
        footer_para.runs[0].font.color.rgb = RGBColor(128, 128, 128)

    def _extract_section(self, full_text: str, section_name: str) -> str:
        """Extract a specific section from the full analysis text"""

        # Try to find section with various formatting
        patterns = [
            f"**{section_name}**",
            f"{section_name}:",
            f"## {section_name}",
            f"# {section_name}",
            section_name
        ]

        text_lower = full_text.lower()
        section_lower = section_name.lower()

        # Find section start
        section_start = -1
        for pattern in patterns:
            idx = full_text.find(pattern)
            if idx != -1:
                section_start = idx + len(pattern)
                break

        if section_start == -1:
            # Try case-insensitive search
            idx = text_lower.find(section_lower)
            if idx != -1:
                section_start = idx + len(section_name)
            else:
                return ""

        # Find next section or end
        remaining_text = full_text[section_start:]

        # Look for next major section (numbered or **HEADER**)
        next_section_patterns = [
            '\n\n**',
            '\n## ',
            '\n# ',
        ]

        section_end = len(remaining_text)
        for pattern in next_section_patterns:
            idx = remaining_text.find(pattern)
            if idx != -1 and idx < section_end:
                section_end = idx

        extracted = remaining_text[:section_end].strip()

        return extracted

    def generate_all_documents(
        self,
        analysis_json_path: str,
        output_folder: Optional[str] = None,
        include_screenshots: bool = True
    ) -> List[str]:
        """
        Generate Word documents for all analyzed reports

        Args:
            analysis_json_path: Path to Claude analysis JSON file
            output_folder: Folder to save documents (default: word_reports)
            include_screenshots: Whether to include screenshot images

        Returns:
            List of paths to generated documents
        """
        print("\n" + "=" * 80)
        print("📝 WORD DOCUMENT GENERATOR")
        print("=" * 80)

        # Load analysis results
        if not os.path.exists(analysis_json_path):
            raise FileNotFoundError(f"Analysis file not found: {analysis_json_path}")

        print(f"\nLoading: {os.path.basename(analysis_json_path)}")
        with open(analysis_json_path, 'r', encoding='utf-8') as f:
            analysis_results = json.load(f)

        # Set up output folder
        if output_folder is None:
            output_folder = os.path.join(
                os.path.dirname(analysis_json_path),
                "word_reports"
            )

        os.makedirs(output_folder, exist_ok=True)
        print(f"Output folder: {output_folder}")

        # Generate documents
        analyses = analysis_results.get('analyses', [])
        print(f"\n📊 Generating {len(analyses)} Word documents...")
        print("-" * 80)

        generated_docs = []

        for idx, analysis in enumerate(analyses, 1):
            sheet_name = analysis.get('sheet_name', f'Report_{idx}')

            print(f"\n[{idx}/{len(analyses)}] {sheet_name}")

            # Create safe filename
            safe_name = "".join(
                c if c.isalnum() or c in (' ', '-', '_') else '_'
                for c in sheet_name
            )

            output_path = os.path.join(output_folder, f"{safe_name}_Analysis.docx")

            # Generate document
            success = self.create_document_for_report(
                analysis_data=analysis,
                output_path=output_path,
                include_screenshot=include_screenshots
            )

            if success:
                generated_docs.append(output_path)

        print("\n" + "=" * 80)
        print(f"✓ GENERATION COMPLETE: {len(generated_docs)} documents created")
        print("=" * 80)
        print(f"\n📁 Documents location: {output_folder}")

        # List all generated documents
        if generated_docs:
            print(f"\n📋 Generated documents ({len(generated_docs)}):")
            for doc_path in generated_docs:
                file_size = os.path.getsize(doc_path) / 1024  # KB
                print(f"   • {os.path.basename(doc_path)} ({file_size:.1f} KB)")

        return generated_docs


def main():
    """Main execution function"""

    # Configuration
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    analysis_json = os.path.join(
        script_dir,
        excel_file.replace('.xlsx', '_claude_analysis.json')
    )

    # Check if analysis file exists
    if not os.path.exists(analysis_json):
        print(f"\n✗ Error: Analysis file not found at {analysis_json}")
        print("\n💡 Please run report_analysis_agent.py first to generate analysis!")
        return

    # Check dependencies
    try:
        from docx import Document
        print("\n✓ python-docx library installed")
    except ImportError:
        print("\n✗ Error: python-docx library not installed")
        print("Install it with: pip install python-docx")
        return

    print("\n" + "=" * 80)
    print("📝 WORD DOCUMENT GENERATOR")
    print("=" * 80)
    print(f"\nAnalysis file: {os.path.basename(analysis_json)}")

    input("\nPress Enter to generate Word documents...")

    try:
        # Create generator
        generator = WordDocumentGenerator()

        # Generate all documents
        docs = generator.generate_all_documents(
            analysis_json_path=analysis_json,
            include_screenshots=True
        )

        print(f"\n✅ SUCCESS! {len(docs)} Word documents generated.")

    except FileNotFoundError as e:
        print(f"\n✗ Error: {str(e)}")

    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
