"""
EPM Report Reverse Engineering Analyzer
Analyzes EPM Excel reports to extract structure, dimensions, formulas, and business logic
for report reconstruction purposes
"""

import os
import json
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import anthropic
import re


class EPMReportAnalyzer:
    """Analyzes EPM reports for reverse engineering and reconstruction"""

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the EPM report analyzer

        Args:
            api_key: Anthropic API key (if None, will look for ANTHROPIC_API_KEY env var)
        """
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Anthropic API key required. Set ANTHROPIC_API_KEY environment variable "
                "or pass api_key parameter."
            )

        self.client = anthropic.Anthropic(api_key=self.api_key)
        self.model = "claude-sonnet-4-5-20250929"

    def encode_image(self, image_path: str) -> Tuple[str, str]:
        """Encode image to base64"""
        with open(image_path, "rb") as image_file:
            image_data = base64.standard_b64encode(image_file.read()).decode("utf-8")

        ext = Path(image_path).suffix.lower()
        media_type_map = {
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.gif': 'image/gif',
            '.webp': 'image/webp'
        }
        media_type = media_type_map.get(ext, 'image/png')

        return image_data, media_type

    def extract_epm_formulas(self, excel_data: Dict) -> Dict:
        """Extract and categorize EPM-specific formulas"""
        formulas = excel_data.get('formulas', {})

        epm_functions = {
            'EPM_FUNCTIONS': [],
            'EPM_DIMENSION_OVERRIDES': [],
            'EPM_MEMBER_OFFSETS': [],
            'EPM_SELECT_POINTS': [],
            'EPM_LOCAL_MEMBERS': [],
            'CUSTOM_FORMULAS': [],
            'STANDARD_EXCEL': []
        }

        for cell_ref, formula in formulas.items():
            formula_upper = formula.upper()

            # EPM-specific functions
            if 'EPM' in formula_upper:
                epm_functions['EPM_FUNCTIONS'].append({
                    'cell': cell_ref,
                    'formula': formula
                })

                if 'EPMDIMENSIONOVERRIDE' in formula_upper:
                    epm_functions['EPM_DIMENSION_OVERRIDES'].append({
                        'cell': cell_ref,
                        'formula': formula
                    })
                elif 'EPMMEMBEROFFSET' in formula_upper:
                    epm_functions['EPM_MEMBER_OFFSETS'].append({
                        'cell': cell_ref,
                        'formula': formula
                    })
                elif 'EPMSELECTPOINT' in formula_upper:
                    epm_functions['EPM_SELECT_POINTS'].append({
                        'cell': cell_ref,
                        'formula': formula
                    })
                elif 'EPMLOCALMEMBER' in formula_upper or 'EPMMEMBERFORMULA' in formula_upper:
                    epm_functions['EPM_LOCAL_MEMBERS'].append({
                        'cell': cell_ref,
                        'formula': formula
                    })
            elif any(func in formula_upper for func in ['SUMIF', 'VLOOKUP', 'IF', 'SUMIFS', 'INDEX', 'MATCH']):
                epm_functions['CUSTOM_FORMULAS'].append({
                    'cell': cell_ref,
                    'formula': formula
                })
            else:
                epm_functions['STANDARD_EXCEL'].append({
                    'cell': cell_ref,
                    'formula': formula
                })

        return epm_functions

    def extract_vba_info(self, vba_data: Dict) -> str:
        """Extract VBA information summary"""
        if not vba_data.get('has_macros'):
            return "No VBA macros found in this workbook."

        vba_files = vba_data.get('vba_files', [])
        vba_size = vba_data.get('vba_project_size_bytes', 0)

        summary = f"VBA Project found with {len(vba_files)} files, total size: {vba_size:,} bytes\n"
        summary += "VBA analysis requires code extraction (not available in current extraction)"

        return summary

    def analyze_epm_report(
        self,
        sheet_name: str,
        excel_data: Dict,
        screenshot_path: Optional[str] = None,
        vba_data: Optional[Dict] = None
    ) -> Dict:
        """
        Analyze a single EPM report sheet for reverse engineering

        Args:
            sheet_name: Name of the sheet being analyzed
            excel_data: Extracted Excel data for this sheet
            screenshot_path: Path to screenshot image (optional)
            vba_data: VBA macro data from workbook

        Returns:
            Dictionary containing EPM analysis results
        """
        print(f"\n🔍 Analyzing EPM Report: '{sheet_name}'")

        # Extract EPM formulas
        epm_formulas = self.extract_epm_formulas(excel_data)

        # Prepare the EPM-specific analysis prompt
        prompt = self._create_epm_analysis_prompt(sheet_name, excel_data, epm_formulas, vba_data)

        # Build message content
        message_content = []

        # Add screenshot if available
        if screenshot_path and os.path.exists(screenshot_path):
            print(f"   📸 Including screenshot: {os.path.basename(screenshot_path)}")
            image_data, media_type = self.encode_image(screenshot_path)
            message_content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": image_data,
                }
            })

        # Add text prompt
        message_content.append({
            "type": "text",
            "text": prompt
        })

        # Call Claude API
        try:
            print(f"   🤖 Querying Claude 4.5 Sonnet for EPM analysis...")
            response = self.client.messages.create(
                model=self.model,
                max_tokens=8192,  # Increased for detailed analysis
                messages=[
                    {
                        "role": "user",
                        "content": message_content
                    }
                ]
            )

            analysis_text = response.content[0].text
            print(f"   ✓ Analysis complete ({len(analysis_text)} characters)")

            # Structure the response
            analysis_result = {
                "sheet_name": sheet_name,
                "analysis_timestamp": datetime.now().isoformat(),
                "claude_model": self.model,

                # Full Claude analysis
                "epm_analysis": analysis_text,

                # Technical extraction
                "epm_formulas_extracted": epm_formulas,
                "vba_summary": self.extract_vba_info(vba_data or {}),

                # Metadata
                "metadata": {
                    "dimensions": excel_data.get('dimensions'),
                    "cell_count": len(excel_data.get('cells', {})),
                    "formula_count": len(excel_data.get('formulas', {})),
                    "epm_function_count": len(epm_formulas['EPM_FUNCTIONS']),
                    "merged_cells_count": len(excel_data.get('merged_cells', [])),
                    "has_screenshot": screenshot_path is not None and os.path.exists(screenshot_path),
                    "screenshot_path": screenshot_path if screenshot_path and os.path.exists(screenshot_path) else None
                },

                # Raw data reference
                "excel_data": excel_data,
            }

            return analysis_result

        except Exception as e:
            print(f"   ✗ Error during analysis: {str(e)}")
            return {
                "sheet_name": sheet_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    def _create_epm_analysis_prompt(
        self,
        sheet_name: str,
        excel_data: Dict,
        epm_formulas: Dict,
        vba_data: Optional[Dict]
    ) -> str:
        """Create EPM-specific reverse engineering analysis prompt"""

        # Get basic info
        dimensions = excel_data.get('dimensions', 'Unknown')
        cell_count = len(excel_data.get('cells', {}))
        formula_count = len(excel_data.get('formulas', {}))
        merged_cells = len(excel_data.get('merged_cells', []))

        # Sample cells for analysis
        cells = excel_data.get('cells', {})
        sample_cells = dict(list(cells.items())[:100])

        # EPM formulas summary
        epm_count = len(epm_formulas['EPM_FUNCTIONS'])
        dimension_override_count = len(epm_formulas['EPM_DIMENSION_OVERRIDES'])
        member_offset_count = len(epm_formulas['EPM_MEMBER_OFFSETS'])
        local_member_count = len(epm_formulas['EPM_LOCAL_MEMBERS'])
        custom_formula_count = len(epm_formulas['CUSTOM_FORMULAS'])

        # Sample formulas
        sample_epm_formulas = epm_formulas['EPM_FUNCTIONS'][:20] if epm_formulas['EPM_FUNCTIONS'] else []
        sample_custom_formulas = epm_formulas['CUSTOM_FORMULAS'][:20] if epm_formulas['CUSTOM_FORMULAS'] else []

        prompt = f"""You are an expert EPM (Enterprise Performance Management) and SAP BPC consultant specializing in reverse engineering EPM Excel reports. Your task is to analyze this EPM report to extract ALL technical details needed to reconstruct it.

**REPORT INFORMATION:**
- Sheet Name: {sheet_name}
- Dimensions: {dimensions}
- Total Cells: {cell_count:,}
- Total Formulas: {formula_count}
- EPM Functions: {epm_count}
- Dimension Overrides: {dimension_override_count}
- Member Offsets: {member_offset_count}
- Local Members: {local_member_count}
- Custom Formulas: {custom_formula_count}
- Merged Cells: {merged_cells}

**SAMPLE CELL DATA (First 100 cells):**
{json.dumps(sample_cells, indent=2)}

**EPM FORMULAS FOUND (Sample):**
{json.dumps(sample_epm_formulas, indent=2)}

**CUSTOM FORMULAS (Sample):**
{json.dumps(sample_custom_formulas, indent=2)}

**VBA INFORMATION:**
{self.extract_vba_info(vba_data or {})}

---

**YOUR TASK: REVERSE ENGINEERING ANALYSIS**

Analyze the screenshot and data to provide a COMPLETE technical specification for reconstructing this EPM report. Answer ALL questions below in detail:

## 1. REPORT/WORKBOOK IDENTIFICATION
**Q: What is the Report/Workbook name and purpose?**
- Official report name
- Business purpose and use case
- Target audience
- Reporting frequency (monthly, quarterly, etc.)

## 2. DIMENSIONS ANALYSIS
**Q: What Dimensions (attributes, text, and hierarchies) are displayed in the report?**
- List ALL dimensions used (e.g., Time, Entity, Account, Category, etc.)
- For each dimension:
  * Position in report (Row/Column/Page/Context)
  * Hierarchy level displayed
  * Parent-child relationships
  * Attribute dimensions if any

**Q: Are dimensions displayed as Key ID or Text (Description)?**
- For each dimension, specify: ID, Text, or Both
- Examples from the screenshot

**Q: Are dimensions sorted in Ascending or Descending order?**
- For each dimension, specify sort order
- Any custom sort sequences

**Q: What are the Business rules for dimensions, if any?**
- Dimension member restrictions
- Valid member combinations
- Dynamic member selections
- Context settings
- EPMDimensionOverride usage and logic

## 3. MEASURES/KPIs ANALYSIS
**Q: What measures/KPIs are displayed in the report?**
- List ALL measures with their labels
- Base measures vs calculated measures
- Position in report layout

**Q: What are the Business rules/logic to calculate measures/KPIs?**
- For each calculated measure:
  * Formula/calculation logic
  * Source data/base measures
  * Time intelligence (YTD, QTD, variance, etc.)
  * Member formulas (if using EPM local members)
  * Any conditional logic

**Q: What is the format of the measures?**
- Number format (decimal places, thousands separator)
- Currency symbols
- Percentage formats
- Conditional formatting rules
- Color coding schemes
- Positive/negative value formatting

## 4. FORMULAS AND BUSINESS LOGIC
**Q: What Custom Formulas are used in the report?**
- Excel formulas (SUMIF, VLOOKUP, IF, etc.)
- Purpose and calculation logic
- Cell references and dependencies

**Q: What EPM Local Member Formulas are used?**
- EPMMemberFormula functions
- EPMLocalMember definitions
- Calculation scripts
- Business logic encoded

**Q: What VBA automations are used?**
- Macro names and purposes
- Automated refresh procedures
- Data validation routines
- Report formatting automation
- Event handlers (Worksheet_Change, etc.)

**Q: What other customizations/business logic exist?**
- Data validations and dropdowns
- Conditional formatting
- Named ranges
- Protected/locked cells
- Hidden rows/columns logic
- Print area settings
- Report parameters

## 5. EPM FUNCTIONS USAGE
Analyze and document:
- **EPMSelectPoint**: Context and member selections
- **EPMDimensionOverride**: Dynamic dimension changes
- **EPMMemberOffset**: Relative member references
- **EPMSelectDimension**: Dimension choices
- **Any other EPM functions**: Purpose and usage

## 6. REPORT STRUCTURE
- Row structure (headers, data rows, totals)
- Column structure (dimension headers, measure columns)
- Page layout and organization
- Section grouping
- Frozen panes/headers
- Repeating elements

## 7. DATA FLOW & DEPENDENCIES
- Data source (EPM connection details visible?)
- Refresh requirements
- Calculation sequence
- Cell dependencies
- Cross-sheet references

## 8. RECONSTRUCTION BLUEPRINT
Provide step-by-step instructions:
1. EPM connection setup
2. Dimension placement
3. Measure definitions
4. Formula implementation
5. Formatting application
6. VBA/macro setup
7. Testing checklist

---

**IMPORTANT**:
- Be EXTREMELY detailed and technical
- Include specific cell references when relevant
- Quote actual formulas and values from the data
- If you see patterns in the screenshot, describe them
- Provide enough detail that someone could recreate this report exactly
- For any EPM functions, explain their parameters and purpose

Please provide comprehensive, actionable analysis."""

        return prompt

    def analyze_all_epm_reports(
        self,
        excel_file_path: str,
        extraction_results_path: Optional[str] = None,
        screenshots_folder: Optional[str] = None
    ) -> List[Dict]:
        """
        Analyze all visible EPM report sheets

        Args:
            excel_file_path: Path to the Excel file
            extraction_results_path: Path to JSON extraction results
            screenshots_folder: Path to screenshots folder

        Returns:
            List of EPM analysis results
        """
        print("\n" + "=" * 80)
        print("📊 EPM REPORT REVERSE ENGINEERING ANALYZER")
        print("=" * 80)
        print(f"\nExcel File: {os.path.basename(excel_file_path)}")
        print(f"Model: Claude 4.5 Sonnet")

        # Load extraction results
        if extraction_results_path is None:
            extraction_results_path = excel_file_path.replace('.xlsx', '_extraction_results.json')

        if not os.path.exists(extraction_results_path):
            raise FileNotFoundError(
                f"Extraction results not found: {extraction_results_path}\n"
                f"Please run EPMReport_Extraction_Enhanced.py first."
            )

        print(f"Loading: {os.path.basename(extraction_results_path)}")
        with open(extraction_results_path, 'r', encoding='utf-8') as f:
            extraction_data = json.load(f)

        # Get VBA data
        vba_data = extraction_data.get('vba_macros', {})

        # Determine screenshots folder
        if screenshots_folder is None:
            screenshots_folder = os.path.join(
                os.path.dirname(excel_file_path),
                "sheet_screenshots"
            )

        # Get visible sheets only
        all_sheets = extraction_data.get('sheets', {})
        sheet_visibility = extraction_data.get('sheet_visibility', {})

        visible_sheets = [
            sheet_name for sheet_name in all_sheets.keys()
            if sheet_visibility.get(sheet_name, {}).get('is_visible', False)
        ]

        print(f"\n📋 Found {len(visible_sheets)} visible EPM reports to analyze")
        print(f"   (Skipping {len(all_sheets) - len(visible_sheets)} hidden sheets)")
        print("-" * 80)

        # Analyze each visible sheet
        all_analyses = []

        for idx, sheet_name in enumerate(visible_sheets, 1):
            print(f"\n[{idx}/{len(visible_sheets)}] Processing EPM Report: '{sheet_name}'")

            sheet_data = all_sheets[sheet_name]

            # Find screenshot
            screenshot_path = self._find_screenshot(sheet_name, screenshots_folder)

            # Analyze
            analysis = self.analyze_epm_report(
                sheet_name=sheet_name,
                excel_data=sheet_data,
                screenshot_path=screenshot_path,
                vba_data=vba_data
            )

            all_analyses.append(analysis)

        print("\n" + "=" * 80)
        print(f"✓ EPM ANALYSIS COMPLETE: {len(all_analyses)} reports analyzed")
        print("=" * 80)

        # Save results
        output_path = excel_file_path.replace('.xlsx', '_epm_analysis.json')
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                'file_name': os.path.basename(excel_file_path),
                'analysis_timestamp': datetime.now().isoformat(),
                'model': self.model,
                'total_reports': len(all_analyses),
                'analyses': all_analyses
            }, f, indent=2, default=str)

        print(f"\n💾 EPM Analysis saved: {os.path.basename(output_path)}")

        return all_analyses

    def _find_screenshot(self, sheet_name: str, screenshots_folder: str) -> Optional[str]:
        """Find screenshot file for a sheet"""
        if not os.path.exists(screenshots_folder):
            return None

        safe_name = "".join(
            c if c.isalnum() or c in (' ', '-', '_') else '_'
            for c in sheet_name
        )

        screenshot_path = os.path.join(screenshots_folder, f"{safe_name}.png")
        return screenshot_path if os.path.exists(screenshot_path) else None


def main():
    """Main execution"""
    excel_file = "Copy of Sample Report BPC EPM.xlsx"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(script_dir, excel_file)

    if not os.path.exists(excel_path):
        print(f"\n✗ Error: Excel file not found at {excel_path}")
        return

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("\n✗ Error: ANTHROPIC_API_KEY environment variable not set")
        print("\nSet your API key:")
        print("  export ANTHROPIC_API_KEY='your-api-key-here'")
        return

    print("\n" + "=" * 80)
    print("🤖 EPM REPORT REVERSE ENGINEERING ANALYZER")
    print("=" * 80)
    print(f"\nTarget: {excel_file}")
    print(f"Model: Claude 4.5 Sonnet")

    try:
        import anthropic
        print("✓ Anthropic SDK ready")
    except ImportError:
        print("\n✗ Error: Install with: pip install anthropic")
        return

    input("\nPress Enter to start EPM analysis...")

    try:
        analyzer = EPMReportAnalyzer(api_key=api_key)
        analyses = analyzer.analyze_all_epm_reports(excel_path)

        print(f"\n✅ SUCCESS! {len(analyses)} EPM reports analyzed")
        print("\nNext: Run epm_word_report_generator.py")

    except Exception as e:
        print(f"\n✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
