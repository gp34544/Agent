# EPM Report Reverse Engineering System

## 🎯 What This Does

Analyzes EPM/SAP BPC Excel reports using **Claude 4.5 Sonnet AI** to generate comprehensive reconstruction documentation that answers all your questions about report structure, dimensions, formulas, and business logic.

## ✨ Key Features

### Answers These Critical Questions:

1. ✅ **What is the Report/Workbook name?**
2. ✅ **What Dimensions are displayed?** (attributes, text, hierarchies)
3. ✅ **Dimensions displayed as Key ID or Text?**
4. ✅ **Dimensions sorted Ascending or Descending?**
5. ✅ **What are the Business rules for dimensions?**
6. ✅ **What Measures/KPIs are displayed?**
7. ✅ **What are the Business rules/logic to calculate measures?**
8. ✅ **What is the format of measures?**
9. ✅ **What Custom Formulas are used?**
10. ✅ **What EPM Local Member Formulas exist?**
11. ✅ **What VBA automations are present?**
12. ✅ **What other customizations/business logic?**

### Plus:
- 📸 **Includes report screenshots** in documentation
- 🔍 **Extracts EPM functions** (EPMDimensionOverride, EPMMemberOffset, etc.)
- 📊 **Analyzes business logic** and calculation methodologies
- 📝 **Generates step-by-step reconstruction blueprints**
- 📄 **Creates professional Word documents** for each report

## 🗂️ File Structure

```
Excel Code/
│
├── 📚 EXISTING FILES (You already have these)
│   ├── EPMReport_Extraction_Enhanced.py         # Extracts Excel data
│   ├── EPMReport_Screenshot_Visible.py          # Captures screenshots
│   └── Copy of Sample Report BPC EPM.xlsx       # Your Excel file
│
├── 🆕 NEW EPM ANALYSIS FILES (Just created)
│   ├── epm_report_analyzer.py                   # Claude AI EPM analyzer
│   ├── epm_word_report_generator.py             # Word doc generator
│   ├── run_epm_workflow.py                      # Automated workflow
│   │
│   ├── requirements.txt                         # Python dependencies
│   ├── EPM_USAGE_GUIDE.md                       # Detailed usage guide
│   └── README_EPM.md                            # This file
│
└── 📂 GENERATED OUTPUTS (Created when you run)
    ├── *_extraction_results.json                # Raw Excel data
    ├── *_epm_analysis.json                      # Claude analysis
    ├── *_report.html                            # HTML summary
    │
    ├── sheet_screenshots/                       # Report screenshots
    │   ├── Instructions.png
    │   ├── Validations.png
    │   └── ...
    │
    └── epm_reconstruction_docs/                 # 📄 FINAL WORD DOCUMENTS
        ├── Instructions_EPM_Reconstruction.docx
        ├── Validations_EPM_Reconstruction.docx
        └── ...
```

## 🚀 Quick Start (3 Steps)

### 1️⃣ Install Dependencies

```bash
pip install -r requirements.txt
```

### 2️⃣ Set API Key

```bash
export ANTHROPIC_API_KEY='your-api-key-here'
```

Get your key from: https://console.anthropic.com/

### 3️⃣ Run the Workflow

```bash
python run_epm_workflow.py
```

That's it! The system will:
1. Extract all data from your Excel file
2. Capture screenshots of visible sheets
3. Analyze each report with Claude AI
4. Generate professional Word documents

## 📄 Output Example

Each Word document contains:

```
┌─────────────────────────────────────────────────────────┐
│  EPM REPORT REVERSE ENGINEERING & RECONSTRUCTION GUIDE  │
│                                                         │
│  "Validations"                                          │
│                                                         │
│  Analyzed by Claude 4.5 Sonnet                          │
│  Purpose: EPM Report Reconstruction                     │
└─────────────────────────────────────────────────────────┘

TABLE OF CONTENTS
1. Report Screenshot
2. Report/Workbook Identification
3. Dimensions Analysis
   - Dimensions displayed (Row/Column/Page)
   - Key ID vs Text display
   - Sorting (Ascending/Descending)
   - Business rules
4. Measures/KPIs Analysis
   - List of all measures
   - Calculation logic
   - Number formats
5. Formulas and Business Logic
   - Custom Excel formulas
   - EPM Local Member formulas
   - VBA automations
   - Other customizations
6. EPM Functions Usage
   - EPMSelectPoint
   - EPMDimensionOverride
   - EPMMemberOffset
   - Others
7. Report Structure
8. Data Flow & Dependencies
9. Reconstruction Blueprint (Step-by-step)
10. Technical Appendix
    - Tables of all formulas
    - VBA summary
    - Metadata
```

## 🎓 Use Cases

### 1. Report Migration
Migrate EPM reports to new system using generated specifications

### 2. Documentation
Create official documentation for compliance and audit

### 3. Training
Train new team members on report structure and logic

### 4. Optimization
Identify performance bottlenecks and optimization opportunities

### 5. Troubleshooting
Understand complex reports for debugging

## 🔑 Key Technologies

- **Claude 4.5 Sonnet** - Advanced AI for EPM analysis
- **Anthropic API** - Official Claude API (NOT Google ADK)
- **Python 3.x** - Core programming language
- **openpyxl** - Excel file processing
- **xlwings** - Excel automation
- **python-docx** - Word document generation

## 📊 Example Analysis Output

```json
{
  "sheet_name": "Validations",
  "epm_formulas_extracted": {
    "EPM_FUNCTIONS": [
      {
        "cell": "B5",
        "formula": "=EPMDimensionOverride(A5,'ENTITY','US_EAST')"
      }
    ],
    "EPM_DIMENSION_OVERRIDES": [...],
    "EPM_LOCAL_MEMBERS": [...],
    "CUSTOM_FORMULAS": [...]
  },
  "epm_analysis": "Full Claude analysis with all answers...",
  "metadata": {
    "cell_count": 963,
    "formula_count": 143,
    "epm_function_count": 45
  }
}
```

## ⚡ Performance

- **Average analysis time**: 30-60 seconds per report
- **Claude API cost**: ~$0.10-0.30 per report (varies by complexity)
- **Output size**: 50-200 KB per Word document

## 🛠️ Architecture

```
┌─────────────────┐
│  Excel File     │
│  with EPM       │
│  Reports        │
└────────┬────────┘
         │
         ├─── Extract Data ──────────► JSON (cells, formulas, VBA)
         │
         ├─── Take Screenshots ─────► PNG images
         │
         ├─── Analyze with Claude ──► Detailed EPM analysis
         │                             - Dimensions
         │                             - Measures
         │                             - Business logic
         │                             - Formulas
         │                             - VBA
         │
         └─── Generate Word Docs ───► Professional documentation
                                       - Answers all questions
                                       - Reconstruction blueprint
                                       - Technical appendix
```

## 📞 Support

**For detailed usage**: See [EPM_USAGE_GUIDE.md](EPM_USAGE_GUIDE.md)

**Troubleshooting**:
- API key issues → Check environment variable
- Missing dependencies → Run `pip install -r requirements.txt`
- Excel errors → Ensure Microsoft Excel installed
- Screenshot fails → Check Excel permissions

## 🎯 Next Steps

1. ✅ Read [EPM_USAGE_GUIDE.md](EPM_USAGE_GUIDE.md) for detailed instructions
2. ✅ Get your Anthropic API key
3. ✅ Run `python run_epm_workflow.py`
4. ✅ Review generated Word documents in `epm_reconstruction_docs/`
5. ✅ Use documentation to reconstruct or understand reports

## 📝 License

This tool is for EPM report analysis and documentation purposes.

---

**Built with Claude 4.5 Sonnet** 🤖

For questions about EPM, BPC, or SAP reporting, consult your organization's documentation.
