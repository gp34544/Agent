
# EPM Report Reverse Engineering - Usage Guide

Complete guide for analyzing EPM Excel reports to extract structure, dimensions, business logic, and formulas for report reconstruction.

## 🎯 Purpose

This toolset analyzes EPM (Enterprise Performance Management) / SAP BPC Excel reports and generates comprehensive reconstruction documentation answering:

- ✅ What is the Report/Workbook name?
- ✅ What Dimensions are displayed (attributes, text, hierarchies)?
- ✅ Are dimensions shown as Key ID or Text?
- ✅ What is the dimension sorting (Ascending/Descending)?
- ✅ What are the Business rules for dimensions?
- ✅ What Measures/KPIs are displayed?
- ✅ What are the Business rules/logic to calculate measures?
- ✅ What is the format of measures?
- ✅ What Custom Formulas are used?
- ✅ What EPM Local Member Formulas exist?
- ✅ What VBA automations are present?
- ✅ What other customizations/business logic?

## 📋 Components

1. **EPMReport_Extraction_Enhanced.py** - Extracts raw data from Excel
2. **EPMReport_Screenshot_Visible.py** - Captures visual screenshots
3. **epm_report_analyzer.py** - Claude AI analysis for EPM reconstruction (NEW)
4. **epm_word_report_generator.py** - Creates reconstruction documents (NEW)
5. **run_epm_workflow.py** - Automated complete workflow (NEW)

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

Required packages:
- `openpyxl` - Excel file reading
- `xlwings` - Excel automation (requires Microsoft Excel installed)
- `Pillow` - Image processing
- `anthropic` - Claude 4.5 Sonnet API
- `python-docx` - Word document generation

### Step 2: Set Up API Key

Get your Anthropic API key from [https://console.anthropic.com/](https://console.anthropic.com/)

**macOS/Linux:**
```bash
export ANTHROPIC_API_KEY='your-api-key-here'
```

**Windows:**
```cmd
set ANTHROPIC_API_KEY=your-api-key-here
```

**Add to shell profile (recommended):**
```bash
echo 'export ANTHROPIC_API_KEY="sk-ant-..."' >> ~/.zshrc
source ~/.zshrc
```

### Step 3: Run the Complete Workflow

**Option A: Automated (Recommended)**
```bash
python run_epm_workflow.py
```

This runs all 4 steps automatically and generates complete reconstruction documentation.

**Option B: Step-by-Step**
```bash
# Step 1: Extract Excel data
python EPMReport_Extraction_Enhanced.py

# Step 2: Capture screenshots
python EPMReport_Screenshot_Visible.py

# Step 3: EPM analysis with Claude
python epm_report_analyzer.py

# Step 4: Generate Word documents
python epm_word_report_generator.py
```

## 📁 Output Structure

After running the workflow:

```
Excel Code/
├── Copy of Sample Report BPC EPM.xlsx                    # Source file
│
├── Copy of Sample Report BPC EPM_extraction_results.json # Raw extraction
├── Copy of Sample Report BPC EPM_epm_analysis.json      # Claude analysis
├── Copy of Sample Report BPC EPM_report.html            # HTML summary
├── Copy of Sample Report BPC EPM_summary_report.txt     # Text summary
│
├── sheet_screenshots/                                    # Screenshots
│   ├── Instructions.png
│   ├── Validations.png
│   ├── Missing Seller _.png
│   └── Missing Buyer _.png
│
└── epm_reconstruction_docs/                             # Final documents
    ├── Instructions_EPM_Reconstruction.docx
    ├── Validations_EPM_Reconstruction.docx
    ├── Missing_Seller___EPM_Reconstruction.docx
    └── Missing_Buyer___EPM_Reconstruction.docx
```

## 📄 What Each Word Document Contains

### Title Page
- Report name
- Analysis date
- Quick statistics

### Section 1: Report Screenshot
- Full visual representation of the EPM report
- Embedded PNG image

### Section 2: Report/Workbook Identification
- Official report name
- Business purpose and use case
- Target audience
- Reporting frequency

### Section 3: Dimensions Analysis
- **Dimensions Displayed**: All dimensions with position (Row/Column/Page)
- **Key ID vs Text**: How each dimension is displayed
- **Sorting**: Ascending/Descending for each dimension
- **Business Rules**: Dimension restrictions, EPMDimensionOverride logic

### Section 4: Measures/KPIs Analysis
- **Measures List**: All KPIs with labels and positions
- **Calculation Logic**: Formulas and business rules
- **Measure Formats**: Number formats, currency, decimals, conditional formatting

### Section 5: Formulas and Business Logic
- **Custom Excel Formulas**: SUMIF, VLOOKUP, IF statements, etc.
- **EPM Local Member Formulas**: EPMMemberFormula, EPMLocalMember
- **VBA Automations**: Macros, event handlers, procedures
- **Other Customizations**: Validations, dropdowns, protected cells

### Section 6: EPM Functions Usage
- EPMSelectPoint
- EPMDimensionOverride
- EPMMemberOffset
- EPMSelectDimension
- Other EPM functions

### Section 7: Report Structure
- Row and column structure
- Page layout
- Frozen panes
- Section grouping

### Section 8: Data Flow & Dependencies
- EPM connection details
- Refresh requirements
- Calculation sequence

### Section 9: Reconstruction Blueprint
- Step-by-step instructions to rebuild the report
- EPM setup
- Dimension placement
- Formula implementation
- Testing checklist

### Section 10: Technical Appendix
- **Tables of extracted formulas**:
  - All EPM Functions
  - Dimension Overrides
  - Member Offsets
  - Local Members
  - Custom Excel Formulas
- VBA Macros summary
- Technical metadata table

## 🔍 EPM-Specific Features

### EPM Function Detection

The analyzer automatically detects and categorizes:

- **EPMDimensionOverride** - Dynamic dimension member changes
- **EPMMemberOffset** - Relative member references
- **EPMSelectPoint** - Member selections and context
- **EPMSelectDimension** - Dimension drop-down selections
- **EPMMemberFormula** - Local calculated members
- **EPMLocalMember** - Custom member definitions

### Business Logic Extraction

Extracts and documents:
- Dimension hierarchies and relationships
- Calculation methodologies
- Time intelligence logic
- Variance calculations
- Data validation rules
- Conditional formatting logic

### VBA Analysis

Identifies and summarizes:
- Macro procedures
- Event handlers
- Automation scripts
- Refresh procedures

## 💡 Usage Tips

### For Best Results

1. **Clean Data First**
   - Ensure EPM connections are working
   - Refresh data before extraction
   - Verify formulas calculate correctly

2. **Meaningful Sheet Names**
   - Use descriptive names (e.g., "P&L Report", "Balance Sheet")
   - Avoid special characters
   - Keep under 31 characters

3. **Hide Sensitive Data**
   - Hide sheets with confidential information
   - Only visible sheets are analyzed
   - Screenshots capture what's visible

4. **Test with Single Sheet First**
   - Manually edit script to analyze one sheet
   - Review output quality
   - Then run full workbook

### Customization

#### Analyze Specific Sheets Only

Edit `epm_report_analyzer.py`:

```python
# Around line 330
visible_sheets = [
    sheet_name for sheet_name in all_sheets.keys()
    if sheet_visibility.get(sheet_name, {}).get('is_visible', False)
    and 'Dashboard' in sheet_name  # Add your filter
]
```

#### Change Output Folder

Edit `epm_word_report_generator.py`:

```python
# Around line 340
output_folder = "/path/to/your/custom/folder"
```

#### Adjust Claude Analysis Detail

Edit `_create_epm_analysis_prompt()` in `epm_report_analyzer.py` to customize questions.

## 🔧 Troubleshooting

### "ANTHROPIC_API_KEY not set"
- Verify: `echo $ANTHROPIC_API_KEY`
- Re-export the variable
- Add to your shell profile for persistence

### "Extraction results not found"
- Run `EPMReport_Extraction_Enhanced.py` first
- Check for JSON file in same folder as Excel file

### "Screenshot not found"
- Run `EPMReport_Screenshot_Visible.py` first
- Requires Microsoft Excel installed
- Check `sheet_screenshots/` folder exists

### "ModuleNotFoundError"
- Run `pip install -r requirements.txt`
- Use correct Python environment
- Try `pip3` instead of `pip`

### API Rate Limits
- Claude API has rate limits based on your plan
- Free tier: ~5 requests/minute
- If limited, wait and retry
- Consider upgrading for higher limits

### Screenshot Issues (Mac)
- Grant Excel permissions in System Preferences > Security & Privacy
- Close and reopen Excel
- Try running script again

## 📊 Example Use Cases

### Scenario 1: Report Migration
**Goal**: Migrate old BPC reports to new system

**Process**:
1. Run EPM workflow on old reports
2. Review generated reconstruction documents
3. Use documents as specification for new reports
4. Verify formulas and business logic match

### Scenario 2: Documentation
**Goal**: Document existing EPM reports for audit/compliance

**Process**:
1. Run EPM workflow on all production reports
2. Generated Word docs serve as official documentation
3. Store in SharePoint/document management system
4. Update when reports change

### Scenario 3: Training
**Goal**: Train new team members on EPM report structure

**Process**:
1. Generate reconstruction docs for key reports
2. Use as training materials
3. New team members understand dimension structure
4. Learn EPM functions and business logic

### Scenario 4: Report Optimization
**Goal**: Identify performance issues and optimization opportunities

**Process**:
1. Analyze reports with EPM workflow
2. Review formula complexity in Technical Appendix
3. Identify redundant calculations
4. Optimize based on insights

## 🤝 Support & Resources

### Getting Help
1. Review this guide
2. Check code comments in Python files
3. Review Claude API docs: https://docs.anthropic.com/
4. Check EPM/BPC documentation

### Useful Resources
- Anthropic Console: https://console.anthropic.com/
- Claude API Docs: https://docs.anthropic.com/
- SAP BPC Docs: (your organization's documentation)

## 📈 Advanced Usage

### Batch Processing Multiple Workbooks

Create `batch_epm_analysis.py`:

```python
import os
from epm_report_analyzer import EPMReportAnalyzer
from epm_word_report_generator import EPMWordReportGenerator

workbooks = [
    "P&L Report.xlsx",
    "Balance Sheet.xlsx",
    "Cash Flow.xlsx",
]

api_key = os.environ.get("ANTHROPIC_API_KEY")
analyzer = EPMReportAnalyzer(api_key)
generator = EPMWordReportGenerator()

for wb in workbooks:
    print(f"\n{'='*80}")
    print(f"Processing: {wb}")
    print('='*80)

    # Analyze
    analyses = analyzer.analyze_all_epm_reports(wb)

    # Generate docs
    analysis_json = wb.replace('.xlsx', '_epm_analysis.json')
    generator.generate_all_epm_docs(analysis_json)

print("\n✅ All workbooks processed!")
```

### Custom Analysis Prompts

Modify `_create_epm_analysis_prompt()` to add organization-specific questions:

```python
# Add after existing prompt
prompt += """

## ORGANIZATION-SPECIFIC REQUIREMENTS
- Compliance with SOX requirements?
- Alignment with corporate chart of accounts?
- Integration with SAP GL postings?
"""
```

## 📝 Changelog

### Version 2.0 (Current)
- ✨ EPM-specific analysis focus
- ✨ Reverse engineering capabilities
- ✨ Detailed reconstruction blueprints
- ✨ Enhanced formula extraction
- ✨ VBA analysis
- ✨ Comprehensive Word documentation

### Version 1.0
- Basic report analysis
- General business intelligence focus

---

**Generated for EPM Report Reverse Engineering** 🤖
