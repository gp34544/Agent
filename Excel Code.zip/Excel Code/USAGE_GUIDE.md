# Excel Report Analysis Agent - Usage Guide

Complete workflow for analyzing Excel reports using Claude 4.5 Sonnet and generating professional Word documents.

## 📋 Overview

This system consists of 4 main components:

1. **EPMReport_Extraction_Enhanced.py** - Extracts data from Excel files
2. **EPMReport_Screenshot_Visible.py** - Captures screenshots of visible sheets
3. **report_analysis_agent.py** - Uses Claude 4.5 Sonnet to analyze reports (NEW)
4. **word_document_generator.py** - Creates formatted Word documents (NEW)

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

Required packages:
- `openpyxl` - Excel file processing
- `xlwings` - Excel automation (requires Microsoft Excel)
- `Pillow` - Image processing
- `anthropic` - Claude API integration
- `python-docx` - Word document generation

### Step 2: Set Up Anthropic API Key

Get your API key from [https://console.anthropic.com/](https://console.anthropic.com/)

**macOS/Linux:**
```bash
export ANTHROPIC_API_KEY='your-api-key-here'
```

**Windows:**
```cmd
set ANTHROPIC_API_KEY=your-api-key-here
```

**Or add to your shell profile (~/.zshrc or ~/.bash_profile):**
```bash
echo 'export ANTHROPIC_API_KEY="your-api-key-here"' >> ~/.zshrc
source ~/.zshrc
```

### Step 3: Run the Complete Workflow

#### 3.1: Extract Excel Data
```bash
python EPMReport_Extraction_Enhanced.py
```

**Output:**
- `Copy of Sample Report BPC EPM_extraction_results.json` - Full data extraction
- `Copy of Sample Report BPC EPM_report.html` - HTML report
- `Copy of Sample Report BPC EPM_summary_report.txt` - Text summary

#### 3.2: Capture Screenshots
```bash
python EPMReport_Screenshot_Visible.py
```

**Output:**
- `sheet_screenshots/` folder containing PNG screenshots of each visible sheet

#### 3.3: Analyze with Claude AI
```bash
python report_analysis_agent.py
```

**What it does:**
- Loads Excel extraction results
- Finds corresponding screenshots
- Analyzes each visible (non-hidden) sheet using Claude 4.5 Sonnet
- Generates comprehensive business intelligence analysis

**Output:**
- `Copy of Sample Report BPC EPM_claude_analysis.json` - Claude's analysis for all sheets

#### 3.4: Generate Word Documents
```bash
python word_document_generator.py
```

**What it does:**
- Loads Claude analysis results
- Creates professional Word documents for each report
- Includes screenshots, analysis, and metadata

**Output:**
- `word_reports/` folder containing `.docx` files for each analyzed sheet

## 📁 File Structure

After running all scripts:

```
Excel Code/
├── Copy of Sample Report BPC EPM.xlsx
├── EPMReport_Extraction_Enhanced.py
├── EPMReport_Screenshot_Visible.py
├── report_analysis_agent.py                    (NEW)
├── word_document_generator.py                  (NEW)
├── requirements.txt                            (NEW)
├── USAGE_GUIDE.md                             (NEW)
│
├── Copy of Sample Report BPC EPM_extraction_results.json
├── Copy of Sample Report BPC EPM_claude_analysis.json
├── Copy of Sample Report BPC EPM_report.html
├── Copy of Sample Report BPC EPM_summary_report.txt
│
├── sheet_screenshots/
│   ├── Sheet1.png
│   ├── Sheet2.png
│   └── ...
│
└── word_reports/
    ├── Sheet1_Analysis.docx
    ├── Sheet2_Analysis.docx
    └── ...
```

## 🔧 Configuration

### Customize Analysis for Different Excel Files

Edit the `main()` function in each script:

```python
# report_analysis_agent.py
excel_file = "YourExcelFile.xlsx"  # Change this

# word_document_generator.py
excel_file = "YourExcelFile.xlsx"  # Change this
```

### Customize Analysis Prompt

Edit `_create_analysis_prompt()` in [report_analysis_agent.py](report_analysis_agent.py:177) to customize what Claude analyzes.

### Customize Word Document Styling

Edit the following methods in [word_document_generator.py](word_document_generator.py:1):
- `_setup_document_styles()` - Fonts and colors
- `_add_title_page()` - Title page layout
- `_add_detailed_analysis_section()` - Content structure

## 📊 What Each Document Contains

Each generated Word document includes:

1. **Title Page**
   - Sheet name
   - Analysis date and time
   - Model used (Claude 4.5 Sonnet)
   - Quick statistics

2. **Executive Summary**
   - High-level overview
   - Report purpose
   - Key timeframes

3. **Screenshot Section**
   - Visual representation of the Excel sheet
   - Embedded PNG image

4. **Detailed Analysis**
   - Data Structure Analysis
   - Key Metrics & Insights
   - Formulas & Calculations
   - Business Context
   - Recommendations

5. **Technical Details**
   - Sheet dimensions
   - Cell counts
   - Formula counts
   - Metadata table

## 🎯 Usage Examples

### Analyze Only Specific Sheets

Modify `analyze_all_reports()` to filter sheets:

```python
# In report_analysis_agent.py
visible_sheets = [
    sheet_name for sheet_name in all_sheets.keys()
    if sheet_visibility.get(sheet_name, {}).get('is_visible', False)
    and 'Dashboard' in sheet_name  # Add your filter here
]
```

### Generate Documents Without Screenshots

```python
# In word_document_generator.py main()
docs = generator.generate_all_documents(
    analysis_json_path=analysis_json,
    include_screenshots=False  # Set to False
)
```

### Process Multiple Excel Files

Create a batch script:

```python
# batch_process.py
import os
from report_analysis_agent import ReportAnalysisAgent
from word_document_generator import WordDocumentGenerator

excel_files = [
    "Report1.xlsx",
    "Report2.xlsx",
    "Report3.xlsx"
]

agent = ReportAnalysisAgent()
generator = WordDocumentGenerator()

for excel_file in excel_files:
    print(f"\n\n{'='*80}")
    print(f"Processing: {excel_file}")
    print('='*80)

    # Analyze
    agent.analyze_all_reports(excel_file)

    # Generate documents
    analysis_json = excel_file.replace('.xlsx', '_claude_analysis.json')
    generator.generate_all_documents(analysis_json)
```

## 🔍 Troubleshooting

### "ANTHROPIC_API_KEY not set"
- Make sure you've exported the environment variable
- Check with: `echo $ANTHROPIC_API_KEY` (macOS/Linux) or `echo %ANTHROPIC_API_KEY%` (Windows)

### "Extraction results not found"
- Run `EPMReport_Extraction_Enhanced.py` first
- Make sure the JSON file was created successfully

### "Screenshot not found"
- Run `EPMReport_Screenshot_Visible.py` first
- Check that `sheet_screenshots/` folder exists
- Microsoft Excel must be installed (xlwings requirement)

### "ModuleNotFoundError"
- Run `pip install -r requirements.txt`
- Make sure you're using the correct Python environment

### API Rate Limits
- Claude API has rate limits based on your plan
- If you hit limits, the script will show an error
- Wait a few minutes and retry

## 💡 Tips for Best Results

1. **Clean Your Excel Data First**
   - Remove unnecessary hidden sheets
   - Ensure formulas are working correctly
   - Verify data is properly formatted

2. **Sheet Names**
   - Use descriptive sheet names
   - Avoid special characters
   - Keep names under 31 characters

3. **Screenshots**
   - Make sure visible sheets display the most important data
   - Hide any confidential sheets before taking screenshots

4. **Analysis Quality**
   - More data = better analysis
   - Include relevant formulas and calculations
   - Use meaningful cell formatting

## 📚 API Reference

### ReportAnalysisAgent

```python
agent = ReportAnalysisAgent(api_key="your-key")

# Analyze single sheet
analysis = agent.analyze_single_report(
    sheet_name="Dashboard",
    excel_data=sheet_data,
    screenshot_path="dashboard.png"
)

# Analyze all visible sheets
analyses = agent.analyze_all_reports(
    excel_file_path="report.xlsx",
    extraction_results_path="report_extraction_results.json",
    screenshots_folder="sheet_screenshots"
)
```

### WordDocumentGenerator

```python
generator = WordDocumentGenerator()

# Generate single document
generator.create_document_for_report(
    analysis_data=analysis,
    output_path="output.docx",
    include_screenshot=True
)

# Generate all documents
docs = generator.generate_all_documents(
    analysis_json_path="report_claude_analysis.json",
    output_folder="word_reports",
    include_screenshots=True
)
```

## 🤝 Support

For issues or questions:
1. Check this guide first
2. Review the code comments in each Python file
3. Check Claude API documentation: https://docs.anthropic.com/

## 📄 License

This tool is provided as-is for business report analysis purposes.

---

**Generated with Claude 4.5 Sonnet** 🤖
