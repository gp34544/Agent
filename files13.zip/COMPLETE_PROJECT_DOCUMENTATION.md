# SAP EPM Report Analyzer - Complete Project Documentation

## Project Overview

This project provides a comprehensive solution for extracting and analyzing SAP EPM (Enterprise Performance Management) Excel reports. The system uses Claude 4.5 Sonnet as an intelligent SAP EPM expert agent to analyze report structure, formulas, dimensions, and business logic, then generates detailed documentation.

## Solution Architecture

### Component Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     Main Program                             │
│                  sap_epm_analyzer.py                         │
└───────────┬─────────────────────────────────────────────────┘
            │
            ├─────► 1. ExcelExtractor (Tool/Function)
            │       ├─ Load Excel workbook
            │       ├─ Extract formulas & values
            │       ├─ Identify EPM functions
            │       ├─ Detect VBA macros
            │       ├─ Capture validations
            │       └─ Generate screenshots
            │
            ├─────► 2. SAPEPMAgent (Agent with Claude 4.5)
            │       ├─ System Prompt: SAP EPM Expert
            │       ├─ Analyze dimensions
            │       ├─ Identify business rules
            │       ├─ Document KPIs/measures
            │       ├─ Analyze calculations
            │       └─ Provide recommendations
            │
            └─────► 3. ReportGenerator (Tool/Function)
                    ├─ Generate Word document
                    ├─ Structure analysis sections
                    ├─ Format professional output
                    └─ Include screenshots & data

```

### Technology Stack

- **Python 3.12**
- **openpyxl**: Excel file manipulation
- **Pillow (PIL)**: Image processing for screenshots
- **python-docx**: Word document generation
- **Claude 4.5 Sonnet**: LLM for intelligent analysis
- **JSON**: Data interchange and storage

## Key Features

### 1. Comprehensive Excel Extraction
✓ All formulas with calculated values
✓ EPM-specific functions (EVDRE, EVGET, EVPRF, EVGTS, EVSEN)
✓ VBA macros detection
✓ Data validations and conditional formatting
✓ Merged cells and comments
✓ Named ranges and defined names
✓ Visual layout screenshots

### 2. Intelligent SAP EPM Analysis
✓ Dimension identification (attributes, text, hierarchies)
✓ Dimension display format analysis (Key ID vs Text)
✓ Sorting logic detection (Ascending/Descending)
✓ Business rules extraction
✓ Measures and KPIs documentation
✓ Calculation logic mapping
✓ Custom formula identification
✓ EPM function analysis
✓ VBA automation detection

### 3. Professional Documentation
✓ Structured Word document report
✓ 10 comprehensive analysis sections
✓ Detailed formula listings
✓ Summary and recommendations
✓ Raw JSON data export
✓ Visual screenshots included

## Agent-Based Design

### Single Agent Architecture

As requested, the solution uses **ONE AGENT** with supporting tools/functions:

```python
# Agent: SAPEPMAgent
- Role: SAP EPM Expert
- LLM: Claude 4.5 Sonnet
- System Prompt: Deep EPM domain knowledge

# Tools/Functions:
1. ExcelExtractor.extract_all_details()
2. ExcelExtractor.create_visual_screenshot()
3. ReportGenerator.generate_word_report()
```

### Agent System Prompt

The SAPEPMAgent uses this expert system prompt:

```
You are an expert SAP EPM consultant with deep knowledge of:
- SAP BPC (Business Planning and Consolidation)
- EPM Add-in for Excel
- EPM formulas and functions (EVDRE, EVGET, EVPRF, etc.)
- Dimension modeling and hierarchies
- Business rules and calculation logic
- VBA automation in EPM context
- Data integration and reporting structures
```

## Usage Guide

### Quick Start

```bash
# 1. Install dependencies
pip install openpyxl pillow python-docx

# 2. Run the analyzer
python sap_epm_analyzer.py

# 3. Find outputs in /mnt/user-data/outputs/
```

### Input Requirements

Place your SAP EPM Excel file at:
```
/mnt/user-data/uploads/Copy_of_Sample_Report_BPC_EPM.xlsx
```

Or modify the `main()` function to specify custom path:
```python
input_file = "/path/to/your/report.xlsx"
```

### Output Files

1. **SAP_EPM_Report_Analysis.docx**
   - Comprehensive analysis report
   - 10 structured sections
   - Professional formatting

2. **extracted_data.json**
   - Raw extracted data
   - Complete formula listings
   - All metadata

3. **screenshot_*.png**
   - Visual layout representations
   - Up to 3 sheets captured

## Report Structure

### Section 1: Report/Workbook Name
Identifies the report being analyzed.

### Section 2: Dimensions
- Lists all dimensions found
- Shows EPM function usage
- Documents hierarchies

### Section 3: Dimension Display Format
- Key ID vs Text identification
- Formatting pattern analysis

### Section 4: Dimension Sorting
- Sort order documentation
- Ascending/Descending patterns

### Section 5: Business Rules
- Conditional logic listing
- IF statements and logical formulas
- Validation rules

### Section 6: Measures/KPIs
- All calculations identified
- Aggregation formulas shown
- Calculated values documented

### Section 7: Calculation Logic
- Formula dependencies
- Calculation flow documentation

### Section 8: Customizations
- **8.1** EPM Functions Analysis
- **8.2** EPM Local Member Formulas
- **8.3** Custom Excel Formulas
- **8.4** VBA Macros and Automation

### Section 9: Report Layout
- Sheet structure
- Merged cells documentation
- Comments and validations

### Section 10: Summary & Recommendations
- Key findings
- Optimization suggestions
- Best practice recommendations

## Analysis Capabilities

### EPM Function Detection

Recognizes and analyzes:
- **EVDRE**: EPM Report (dimension-based reporting)
- **EVGET**: Get single value from EPM
- **EVPRF**: EPM Refresh data
- **EVGTS**: Get text value from EPM
- **EVSEN**: Send data to EPM

### Business Rule Patterns

Identifies these Excel patterns:
- **Conditional**: IF, IFS, SWITCH
- **Lookup**: VLOOKUP, HLOOKUP, XLOOKUP
- **Array**: INDEX, MATCH, FILTER
- **Aggregation with conditions**: SUMIF, SUMIFS, COUNTIF, COUNTIFS

### Measure/KPI Recognition

Detects aggregation functions:
- **Sum**: SUM, SUMPRODUCT
- **Average**: AVERAGE, AVERAGEIF
- **Count**: COUNT, COUNTA
- **Statistical**: MAX, MIN, STDEV, VAR

## Integration Options

### Google ADK Framework

The design supports Google ADK integration:

```python
# Define tools
tools = [
    extract_excel_tool,
    create_screenshot_tool,
    generate_report_tool
]

# Define agent
agent = Agent(
    model="claude-4-5-sonnet",
    system_prompt=SAP_EPM_EXPERT_PROMPT,
    tools=tools
)

# Execute
result = agent.run(task="Analyze EPM report")
```

### Anthropic API

Direct Claude API usage:

```python
import anthropic

client = anthropic.Anthropic(api_key="...")

response = client.messages.create(
    model="claude-sonnet-4-5-20250929",
    system=SAP_EPM_EXPERT_PROMPT,
    messages=[{
        "role": "user",
        "content": extracted_data
    }]
)
```

## Technical Implementation

### Excel Extraction Process

```python
1. Load workbook (formulas preserved)
   workbook = openpyxl.load_workbook(path, data_only=False, keep_vba=True)

2. Load workbook (values only) 
   data_wb = openpyxl.load_workbook(path, data_only=True)

3. Extract per sheet:
   - Formulas from workbook (formula mode)
   - Values from data_wb (calculated values)
   - Metadata (merges, comments, validations)

4. Identify EPM functions:
   - Scan for 'EVDRE', 'EVGET', 'EVPRF', etc.
   - Capture full formula text
   - Record cell locations

5. Generate screenshots:
   - Create PIL Image
   - Draw grid representation
   - Highlight formula cells
   - Save as PNG
```

### Analysis Workflow

```python
1. Extract all Excel data
   extracted_data = extractor.extract_all_details()

2. Create visual screenshots
   screenshots = create_screenshots(sheets)

3. Analyze with SAP EPM Agent
   analysis = agent.analyze_excel_data(
       extracted_data, 
       screenshots
   )

4. Generate Word report
   report = generator.generate_word_report(analysis)
```

### Word Document Generation

```python
1. Create Document object
2. Set professional styling (Arial, 11pt)
3. Add title and header
4. Iterate through 10 sections:
   - Add heading
   - Add analyzed content
   - Format with bullets/paragraphs
5. Add summary and recommendations
6. Save to .docx format
```

## Advanced Features

### VBA Detection

```python
# Check for VBA presence
if workbook.vba_archive is not None:
    has_vba = True
    # VBA code is in binary format
    # Full extraction requires additional tools
```

### Formula Analysis

```python
# Extract with both formula and value
formula_info = {
    'cell': cell.coordinate,
    'formula': cell.value,  # From formula workbook
    'calculated_value': data_sheet[cell.coordinate].value  # From data workbook
}
```

### EPM Function Parsing

```python
# Identify EPM-specific functions
epm_functions = ['EVDRE', 'EVGET', 'EVPRF', 'EVGTS', 'EVSEN']

if any(func in cell.value.upper() for func in epm_functions):
    # This is an EPM function
    epm_function_list.append(formula_info)
```

## Performance Considerations

### Memory Management

- Load sheets on-demand for large workbooks
- Limit screenshot generation to first 3 sheets
- Stream JSON writing for large datasets

### Processing Optimization

- Parallel sheet processing (future enhancement)
- Cache extracted data
- Limit formula string length in reports

### File Size Management

- JSON files can be large (500KB - 5MB)
- Screenshots are optimized (15-45KB each)
- Word documents are compact (30-150KB)

## Error Handling

### Common Issues & Solutions

1. **File Not Found**
   ```python
   if not os.path.exists(input_file):
       print(f"Error: File not found: {input_file}")
       return
   ```

2. **Invalid Excel Format**
   ```python
   try:
       workbook = openpyxl.load_workbook(path)
   except Exception as e:
       print(f"Error loading workbook: {e}")
   ```

3. **Screenshot Generation Failure**
   ```python
   try:
       create_visual_screenshot(sheet_name, path)
   except Exception as e:
       print(f"Failed to create screenshot: {e}")
       # Continue with analysis
   ```

## Extending the System

### Adding New Analysis Methods

```python
class SAPEPMAgent:
    def _analyze_new_feature(self, data):
        """Analyze new feature"""
        results = []
        # Analysis logic here
        return results
```

### Adding New Report Sections

```python
class ReportGenerator:
    def generate_word_report(self, output_path):
        # ... existing sections ...
        
        # Add new section
        doc.add_heading('New Section', 1)
        doc.add_paragraph(self.analysis['new_feature'])
```

### Custom EPM Function Support

```python
# Add to EPM function list
epm_functions = [
    'EVDRE', 'EVGET', 'EVPRF', 'EVGTS', 'EVSEN',
    'CUSTOM_FUNC1', 'CUSTOM_FUNC2'  # Add custom functions
]
```

## Testing & Validation

### Test Checklist

- [ ] Load various Excel formats (.xlsx, .xlsm)
- [ ] Test with large workbooks (>10MB)
- [ ] Verify EPM function detection
- [ ] Check VBA macro detection
- [ ] Validate Word document formatting
- [ ] Test screenshot generation
- [ ] Verify JSON export integrity

### Sample Test Cases

```python
# Test 1: Basic extraction
def test_basic_extraction():
    extractor = ExcelExtractor("test.xlsx")
    data = extractor.extract_all_details()
    assert len(data['sheets']) > 0

# Test 2: EPM function detection
def test_epm_functions():
    # File with known EPM functions
    extractor = ExcelExtractor("epm_report.xlsx")
    data = extractor.extract_all_details()
    epm_count = sum(
        len(sheet['epm_functions']) 
        for sheet in data['sheets']
    )
    assert epm_count > 0

# Test 3: Report generation
def test_report_generation():
    analysis = {...}  # Sample analysis data
    generator = ReportGenerator(analysis)
    output = generator.generate_word_report("test.docx")
    assert os.path.exists(output)
```

## Deployment

### Prerequisites

```bash
# System requirements
Python 3.8+
pip package manager

# Python packages
openpyxl>=3.0.0
Pillow>=9.0.0
python-docx>=0.8.0
```

### Installation Steps

```bash
# 1. Clone or download the project
# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure input path (optional)
# Edit sap_epm_analyzer.py, line ~618

# 4. Run analyzer
python sap_epm_analyzer.py
```

### Requirements.txt

```txt
openpyxl>=3.1.0
Pillow>=10.0.0
python-docx>=1.0.0
```

## Future Enhancements

### Planned Features

- [ ] **PDF Output**: Generate PDF reports
- [ ] **HTML Dashboard**: Interactive web-based reports
- [ ] **Batch Processing**: Analyze multiple reports
- [ ] **Version Comparison**: Compare report versions
- [ ] **Data Lineage**: Visualize data flow
- [ ] **Formula Dependency Graph**: Show calculation chains
- [ ] **API Integration**: Real-time analysis endpoints
- [ ] **Enhanced VBA Extraction**: Full macro code analysis

### Advanced Analytics

- [ ] **ML-based Pattern Detection**: Identify unusual patterns
- [ ] **Anomaly Detection**: Flag suspicious calculations
- [ ] **Performance Profiling**: Identify slow formulas
- [ ] **Security Audit**: Check for external links

## Troubleshooting

### Debug Mode

Enable verbose logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# In extractor
logging.debug(f"Processing sheet: {sheet_name}")
logging.debug(f"Found {len(formulas)} formulas")
```

### Common Errors

1. **AttributeError in defined_names**
   - Fixed in current version
   - Uses items() method instead of definedName

2. **PIL/Pillow import issues**
   - Install: `pip install Pillow`
   - Import as: `from PIL import Image`

3. **Memory errors with large files**
   - Process sheets individually
   - Limit data_sample size
   - Skip screenshot generation

## Best Practices

### Code Quality

- Follow PEP 8 style guidelines
- Add docstrings to all methods
- Use type hints where appropriate
- Handle errors gracefully

### Documentation

- Keep README updated
- Document all configuration options
- Provide usage examples
- Include troubleshooting guides

### Performance

- Profile with cProfile for bottlenecks
- Cache repeated operations
- Use generators for large datasets
- Optimize screenshot generation

## Support & Contribution

### Getting Help

- Review this documentation
- Check README_SAP_EPM_Analyzer.md
- Examine extracted JSON data
- Review Python code comments

### Contributing

Guidelines for extending the system:
1. Follow existing code structure
2. Add tests for new features
3. Update documentation
4. Maintain backward compatibility

## License

Proprietary - For internal use only

## Version History

### v1.0 (2025-02-12)
- Initial release
- Basic extraction and analysis
- Word document generation
- Screenshot creation
- JSON export
- Single-agent architecture
- Claude 4.5 Sonnet integration

## Contact & Support

For questions or issues:
- Review this documentation
- Check the code comments
- Test with sample reports
- Consult SAP EPM documentation

## Acknowledgments

- **Claude 4.5 Sonnet**: Intelligent analysis capabilities
- **openpyxl**: Excellent Excel file handling
- **python-docx**: Professional document generation
- **Pillow**: Robust image processing

---

**End of Documentation**
