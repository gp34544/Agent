# SAP EPM Report Analyzer

## Overview

This program extracts detailed information from SAP EPM (Enterprise Performance Management) Excel reports and generates comprehensive analysis documentation. It uses Claude 4.5 Sonnet as an SAP EPM expert agent to analyze the report structure, formulas, dimensions, and business logic.

## Architecture

The solution consists of three main components:

### 1. **ExcelExtractor**
Extracts comprehensive details from Excel workbooks including:
- All formulas and their calculated values
- EPM-specific functions (EVDRE, EVGET, EVPRF, etc.)
- VBA macros and code
- Data validations and conditional formatting
- Merged cells and comments
- Named ranges and defined names
- Visual screenshots of sheet layouts

### 2. **SAPEPMAgent**
Acts as an SAP EPM expert with deep knowledge of:
- SAP BPC (Business Planning and Consolidation)
- EPM Add-in for Excel
- Dimension modeling and hierarchies
- Business rules and calculation logic
- VBA automation in EPM context

The agent analyzes:
- Dimensions (attributes, text, hierarchies)
- Dimension display formats (Key ID vs Text)
- Sorting and filtering logic
- Business rules for dimensions
- Measures and KPIs
- Calculation logic
- Custom formulas and EPM functions
- VBA automation
- Report layout and structure

### 3. **ReportGenerator**
Generates a comprehensive Word document (.docx) with:
- Report/Workbook identification
- Complete dimension analysis
- Business rules documentation
- Measures/KPIs listing
- Calculation logic explanation
- Custom formulas and EPM functions
- VBA automation details
- Report layout summary
- Recommendations

## Features

### Excel Analysis
- ✓ Extracts all formulas with calculated values
- ✓ Identifies EPM-specific functions
- ✓ Detects VBA macros
- ✓ Captures data validations
- ✓ Identifies conditional formatting
- ✓ Extracts comments and merged cells
- ✓ Creates visual layout screenshots

### EPM-Specific Analysis
- ✓ Dimension identification
- ✓ EPM function analysis (EVDRE, EVGET, EVPRF, etc.)
- ✓ Business rule detection
- ✓ KPI/Measure identification
- ✓ Calculation logic mapping

### Report Output
- ✓ Professional Word document format
- ✓ Structured sections covering all analysis areas
- ✓ Detailed formula documentation
- ✓ Summary and recommendations
- ✓ JSON export of raw extracted data

## Installation

### Prerequisites
```bash
pip install openpyxl pillow python-docx
```

### Required Libraries
- **openpyxl**: Excel file reading and analysis
- **PIL (Pillow)**: Screenshot generation
- **python-docx**: Word document generation

## Usage

### Basic Usage
```bash
python sap_epm_analyzer.py
```

The program expects the input file at:
```
/mnt/user-data/uploads/Copy_of_Sample_Report_BPC_EPM.xlsx
```

### Customizing Input File
Edit the `main()` function to specify a different input file:

```python
def main():
    input_file = "/path/to/your/epm_report.xlsx"
    # ... rest of the code
```

### Output Files

1. **Analysis Report**: `/mnt/user-data/outputs/SAP_EPM_Report_Analysis.docx`
   - Comprehensive Word document with all analysis results

2. **Extracted Data**: `/home/claude/extracted_data.json`
   - Raw JSON data with all extracted information
   - Useful for programmatic analysis or integration

3. **Screenshots**: `/home/claude/screenshot_*.png`
   - Visual representations of report layouts
   - One per sheet (up to 3 sheets)

## Report Structure

The generated Word document includes these sections:

1. **Report/Workbook Name**
   - Identifies the report being analyzed

2. **Dimensions Analysis**
   - Lists all dimensions found
   - Shows EPM function usage
   - Documents dimension hierarchies

3. **Dimension Display Format**
   - Identifies Key ID vs Text display
   - Shows formatting patterns

4. **Dimension Sorting**
   - Documents sort order
   - Identifies ascending/descending patterns

5. **Business Rules for Dimensions**
   - Lists all conditional logic
   - Documents IF statements and logical formulas
   - Shows validation rules

6. **Measures/KPIs**
   - Identifies all calculations
   - Shows aggregation formulas
   - Documents calculated values

7. **Calculation Logic**
   - Explains formula dependencies
   - Documents calculation flow

8. **Custom Formulas and Customizations**
   - EPM Functions (EVDRE, EVGET, etc.)
   - EPM Local Member Formulas
   - Custom Excel Formulas
   - VBA Macros and Automation

9. **Report Layout**
   - Sheet structure
   - Merged cells
   - Comments and validations

10. **Summary and Recommendations**
    - Key findings
    - Optimization suggestions

## Technical Details

### EPM Functions Supported

The analyzer recognizes these EPM functions:
- **EVDRE**: EPM Report
- **EVGET**: Get single value
- **EVPRF**: EPM Refresh
- **EVGTS**: Get text value
- **EVSEN**: Send data

### Business Rule Detection

Identifies these formula patterns:
- IF, SUMIF, SUMIFS
- VLOOKUP, HLOOKUP
- INDEX, MATCH
- COUNTIF, COUNTIFS

### Measure/KPI Detection

Recognizes these aggregation functions:
- SUM, AVERAGE
- COUNT, COUNTA
- MAX, MIN
- STDEV, VAR

## Integration with Claude API

The program is designed to work with Claude 4.5 Sonnet via the Anthropic API. The SAP EPM expert agent system prompt provides:

- Deep EPM domain knowledge
- Technical analysis capabilities
- Best practice recommendations
- Business logic interpretation

### Using as an Agent Framework

The design follows an agent-based architecture where:

1. **Tools**: ExcelExtractor and ReportGenerator are tools/functions
2. **Agent**: SAPEPMAgent acts as the intelligent agent
3. **LLM**: Claude 4.5 Sonnet provides the intelligence

To integrate with Google ADK or other frameworks:
- Use `ExcelExtractor.extract_all_details()` as a tool
- Use `SAPEPMAgent.analyze_excel_data()` as the agent function
- Use `ReportGenerator.generate_word_report()` as output tool

## Extending the Analyzer

### Adding New Analysis Functions

Add new methods to `SAPEPMAgent`:

```python
def _analyze_custom_feature(self, data):
    """Analyze custom feature"""
    # Your analysis logic
    return results
```

Then add to the analysis pipeline in `analyze_excel_data()`:

```python
analysis = {
    # ... existing analyses
    'custom_feature': self._analyze_custom_feature(extracted_data)
}
```

### Adding New Report Sections

In `ReportGenerator.generate_word_report()`, add new sections:

```python
doc.add_heading('New Section Title', 1)
doc.add_paragraph(self.analysis['custom_feature'])
```

## Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   pip install --break-system-packages openpyxl pillow python-docx
   ```

2. **File Not Found**
   - Check the input file path
   - Ensure file is uploaded to correct location

3. **VBA Extraction**
   - Load with `keep_vba=True`
   - VBA code is binary, full extraction requires additional tools

4. **Memory Issues**
   - Large files may need chunked processing
   - Limit screenshot generation to first few sheets

### Debug Mode

Enable verbose output by adding print statements:

```python
# In extract_sheet_details
print(f"Processing sheet: {sheet_name}")
print(f"Found {len(sheet_info['formulas'])} formulas")
```

## Best Practices

1. **Input Validation**
   - Verify file exists before processing
   - Check file format is .xlsx or .xlsm

2. **Error Handling**
   - Wrap critical sections in try-except
   - Log errors for debugging

3. **Performance**
   - Process sheets in parallel for large workbooks
   - Cache extracted data
   - Limit screenshot generation

4. **Output Quality**
   - Review generated reports
   - Validate formula extraction
   - Cross-reference with source workbook

## License

Proprietary - For internal use only

## Support

For issues or questions:
- Review this README
- Check the extracted JSON for raw data
- Examine the Python code comments
- Test with sample EPM reports

## Version History

- **v1.0** (2025-02-12)
  - Initial release
  - Basic extraction and analysis
  - Word document generation
  - Screenshot creation
  - JSON export

## Future Enhancements

- [ ] PDF output support
- [ ] Enhanced VBA code extraction
- [ ] Interactive HTML reports
- [ ] API integration for real-time analysis
- [ ] Batch processing multiple reports
- [ ] Comparison between report versions
- [ ] Data lineage visualization
- [ ] Formula dependency graphs
