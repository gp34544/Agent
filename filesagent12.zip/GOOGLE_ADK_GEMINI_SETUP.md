# SAP EPM Analyzer with Google ADK (Gemini) - Setup Guide

## ✅ CORRECT IMPLEMENTATION

This is the **correct implementation** using:
- **Google ADK (Genkit)** framework
- **Google Gemini** LLM (NOT Anthropic Claude)
- **No Anthropic API** required

## Architecture

```
┌────────────────────────────────────────────────────────┐
│                  Main Program                           │
│         sap_epm_analyzer_google_adk.py                  │
└──────────────┬─────────────────────────────────────────┘
               │
               ├──► Tool: ExcelExtractor
               │    └─ Extract formulas, EPM functions
               │
               ├──► AGENT: SAPEPMAgentGoogleADK
               │    ├─ Framework: Google ADK (Genkit)
               │    ├─ LLM: Google Gemini 1.5 Pro
               │    ├─ System Prompt: SAP EPM Expert
               │    ├─ INPUT 1: Excel extraction (JSON)
               │    └─ INPUT 2: Screenshot (base64 PNG)
               │
               └──► Tool: TemplateReportGenerator
                    └─ Generate Word document
```

## Key Features

✅ **Google ADK Framework** - Not Anthropic
✅ **Google Gemini LLM** - gemini-1.5-pro
✅ **Two Inputs to Agent**:
   - INPUT 1: Excel extraction data
   - INPUT 2: Report screenshot (visual context)
✅ **System Prompt** - SAP EPM expert knowledge
✅ **Structured JSON Output** - 8 dimensions, business rules, etc.
✅ **Separate Reports** - One per workbook
✅ **Template Format** - Matches your example

## Installation

### Step 1: Install Google ADK (Genkit)

```bash
pip install firebase-genkit
```

### Step 2: Install Google AI SDK

```bash
pip install google-generativeai
```

### Step 3: Install Other Dependencies

```bash
pip install openpyxl pillow python-docx
```

### Step 4: Get Google API Key

1. Go to: https://makersuite.google.com/app/apikey
2. Create new API key
3. Copy the key (starts with `AIza...`)

### Step 5: Set Environment Variable

```bash
# Linux/Mac
export GOOGLE_API_KEY='AIzaSy...'

# Windows
set GOOGLE_API_KEY=AIzaSy...
```

### Step 6: Verify Installation

```python
# Test imports
from genkit import Genkit
from genkit.models.gemini import GeminiPro
print("Google ADK with Gemini ready!")
```

## Usage

### Basic Usage

```bash
python sap_epm_analyzer_google_adk.py
```

### What Happens:

1. **Extraction**: Reads Excel file, extracts formulas/EPM functions
2. **Screenshot**: Creates visual representation of report layout
3. **Agent Initialization**: Sets up Google ADK with Gemini + SAP EPM system prompt
4. **Agent Analysis**: 
   - Sends INPUT 1 (extraction data) + INPUT 2 (screenshot) to Gemini
   - Gemini analyzes using SAP EPM expert knowledge
   - Returns structured JSON analysis
5. **Report Generation**: Creates Word document in template format

## Agent System Prompt

```
You are an expert SAP EPM consultant with deep knowledge of:
- SAP BPC (Business Planning and Consolidation)
- EPM Add-in for Excel
- EPM formulas (EVDRE, EVGET, EVPRF, EPMContextMember, etc.)
- Dimension modeling (MODEL, CATEGORY, ENTITY, TIME, ACCOUNT, BFLOW, TPARTNER, DATASRC)
- Business rules and validation logic
- EPMLocalMember virtual members

INPUT 1: Excel extraction data (formulas, EPM functions)
INPUT 2: Report screenshot (visual layout)

Output: Structured JSON with dimensions, business rules, measures, etc.
```

## Two Inputs to Agent

### INPUT 1: Excel Extraction Data (JSON)

```json
{
  "workbook_name": "Main Report",
  "sheets": ["Validations", "Validations Group"],
  "total_formulas": 1234,
  "total_epm_functions": 567,
  "total_local_members": 28,
  "formulas_sample": [
    {
      "sheet": "Validations",
      "cell": "D5",
      "formula": "=_xll.EPMContextMember($D$3, C5)",
      "value": "1090"
    }
  ],
  "epm_functions_sample": [...],
  "local_members_sample": [...]
}
```

### INPUT 2: Report Screenshot (Base64 PNG)

- Visual representation of Excel report
- Shows layout, dimensions, formulas
- Encoded as base64 string
- Sent to Gemini with vision capabilities

## Agent Output (Structured JSON)

```json
{
  "report_name": "BPC EPM Validations Report",
  "report_objective": "Data validation by entity...",
  "dimensions": [
    {
      "dimension_name": "ENTITY",
      "display_format": "ID_Description",
      "sort": "Ascending by ID",
      "hierarchies": "PARENTH1",
      "properties": "CALC, DIVISIONS",
      "context_formula": "EPMContextMember + EPMDimensionOverride",
      "business_rules": "Uses CALC property for base expansion..."
    }
    // ... 7 more dimensions
  ],
  "epm_local_members": [...],
  "epm_functions_summary": {...},
  "measures_kpis": [...],
  "business_rules": [...],
  "summary": "..."
}
```

## Code Structure

```python
# Agent class
class SAPEPMAgentGoogleADK:
    SYSTEM_PROMPT = """SAP EPM expert prompt..."""
    
    def __init__(self):
        # Initialize with Google Gemini (NOT Anthropic)
        self.model = GeminiPro(
            model_id="gemini-1.5-pro",
            api_key=os.environ.get("GOOGLE_API_KEY")
        )
    
    def analyze_with_agent(self, extraction_data, screenshot):
        # Create Genkit flow
        @flow
        def analyze_epm_report_flow(data, image):
            # Prepare messages with both inputs
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user", 
                    "content": [
                        {"type": "text", "text": data},
                        {"type": "image", "image": image}
                    ]
                }
            ]
            
            # Call Gemini via Google ADK
            response = self.model.generate(messages=messages)
            return json.loads(response.text)
        
        return analyze_epm_report_flow(extraction_data, screenshot)
```

## Mock Agent (Fallback)

If Google ADK is not installed, the code uses a **mock agent**:
- Provides template-based analysis
- Uses pattern matching on formulas
- Generates reasonable structured output
- **Does NOT use LLM reasoning**

To use the real agent, install Google ADK.

## Comparison

| Feature | Mock Agent | Real Google ADK Agent |
|---------|-----------|------------------------|
| Framework | None | Google ADK (Genkit) |
| LLM | None | Google Gemini 1.5 Pro |
| Intelligence | Pattern matching | AI reasoning |
| Vision | No | Yes (sees screenshot) |
| API Key | Not required | Required (free tier available) |
| Cost | Free | Pay per token (~$0.10/workbook) |

## Output Files

Generated per workbook:

1. **BPC_EPM_Analysis_{WorkbookName}.docx**
   - Professional Word document
   - Template format
   - Agent analysis embedded
   - Screenshot included

2. **screenshot_{WorkbookName}.png**
   - Report layout visualization
   - Temporary file

## Troubleshooting

### Error: "ModuleNotFoundError: No module named 'genkit'"

```bash
pip install firebase-genkit google-generativeai
```

### Error: "GOOGLE_API_KEY not set"

```bash
export GOOGLE_API_KEY='your-api-key'
```

### Warning: "Using mock agent"

**Meaning**: Google ADK not installed, using fallback

**Solution**: Install Google ADK and set API key

### Error: "Invalid API key"

**Solution**:
- Get new key from: https://makersuite.google.com/app/apikey
- Ensure key starts with `AIza`
- Check key permissions for Gemini API

## Google ADK Resources

- **Genkit Docs**: https://firebase.google.com/docs/genkit
- **Gemini API**: https://ai.google.dev/
- **API Keys**: https://makersuite.google.com/app/apikey
- **Pricing**: https://ai.google.dev/pricing

## Environment Variables

```bash
# Required
GOOGLE_API_KEY=AIzaSy...

# Optional (advanced)
GENKIT_MODEL=gemini-1.5-pro
GENKIT_MAX_TOKENS=8000
```

## Advanced Configuration

### Change LLM Model

```python
self.model = GeminiPro(
    model_id="gemini-1.5-flash",  # Faster, cheaper
    api_key=os.environ.get("GOOGLE_API_KEY")
)
```

Available models:
- `gemini-1.5-pro` - Most capable (recommended)
- `gemini-1.5-flash` - Faster, cheaper
- `gemini-pro-vision` - Legacy vision model

### Customize System Prompt

Edit the `SYSTEM_PROMPT` variable in `SAPEPMAgentGoogleADK` class.

### Adjust Response Format

Modify the JSON structure in the system prompt.

## Performance

- **Excel Extraction**: 2-5 seconds
- **Screenshot Generation**: 1-2 seconds
- **Agent Analysis with Gemini**: 10-30 seconds
- **Report Generation**: 1-2 seconds
- **Total per workbook**: 15-40 seconds

## Cost Estimation (Google Gemini)

- **Input**: ~10,000 tokens (extraction + screenshot)
- **Output**: ~3,000 tokens (JSON analysis)
- **Cost**: ~$0.10-0.20 per workbook with Gemini 1.5 Pro
- **Free Tier**: 60 requests/minute (generous limits)

## Production Best Practices

1. **Error Handling**: Wrap agent calls in try-except
2. **Logging**: Log agent requests/responses
3. **Caching**: Cache identical extraction data
4. **Rate Limiting**: Respect API rate limits
5. **Validation**: Validate JSON output structure
6. **Monitoring**: Track costs and performance

## Batch Processing

```python
# Process multiple files
files = ["report1.xlsx", "report2.xlsx", "report3.xlsx"]

for file in files:
    extractor = ExcelExtractor(file)
    sheets = extractor.get_workbook_sheets()
    # ... analyze each workbook
```

## Key Differences from Anthropic Version

| Aspect | This (Google ADK) | Previous (Anthropic) |
|--------|-------------------|----------------------|
| Framework | Google ADK (Genkit) | Anthropic SDK |
| LLM | Google Gemini | Claude 4.5 |
| API Key | GOOGLE_API_KEY | ANTHROPIC_API_KEY |
| Vision Support | Native in Gemini | Native in Claude |
| Cost | ~$0.10/workbook | ~$0.20/workbook |
| Free Tier | Yes | No |

## Support

For issues:
1. Verify Google ADK installation
2. Check GOOGLE_API_KEY is set
3. Test with mock agent first
4. Review agent system prompt
5. Validate JSON output structure

## License

Proprietary - For internal use only

## Version

- **Code Version**: 3.0 (Google ADK)
- **Framework**: Google ADK (Genkit)
- **LLM**: Google Gemini 1.5 Pro
- **Last Updated**: 2025-02-12

---

## Quick Start Commands

```bash
# 1. Install
pip install firebase-genkit google-generativeai openpyxl pillow python-docx

# 2. Set API key
export GOOGLE_API_KEY='your-key-here'

# 3. Run
python sap_epm_analyzer_google_adk.py

# 4. Check outputs
ls /mnt/user-data/outputs/BPC_EPM_Analysis_*.docx
```

✅ **This is the correct implementation using Google ADK with Google Gemini (NOT Anthropic)**
