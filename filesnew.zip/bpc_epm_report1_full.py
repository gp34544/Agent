#!/usr/bin/env python3
"""
BPC EPM Validations Report — Full Document Generator (v2)
Covers: Dimensions, Measures, EPMLocalMember, EPMOlapMemberO,
        EPMContextMember, EPMDimensionOverride, EPMMemberProperty,
        EPMMemberDesc, Division Grouping, all custom business logic.
"""

import os, re, sys, base64, subprocess
import openpyxl
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont


# ── colour palette ─────────────────────────────────────────────────────────────
C = dict(
    navy   =(0,   70, 127),
    blue   =(0,  112, 192),
    lblue  =(189,215, 238),
    row_a  =(235,243, 255),
    row_b  =(255,255, 255),
    yellow =(255,255, 204),
    red_bg =(255,121, 121),
    green  =(198,239, 206),
    purple =(112,  0, 255),
    gray   =(242,242, 242),
    grid   =(180,180, 180),
    text   =(30,  30,  30),
    white  =(255,255, 255),
    orange =(255,192,   0),
)


def _font(sz, bold=False):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold
            else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold
            else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, sz)
            except: pass
    return ImageFont.load_default()


# ── screenshot builder ──────────────────────────────────────────────────────────

def render_screenshot(out_path="/home/claude/ss_val_v2.png"):
    W, H = 1800, 1100
    img  = Image.new("RGB", (W, H), C["white"])
    d    = ImageDraw.Draw(img)

    fT  = _font(18, True)
    fB  = _font(13, True)
    fBs = _font(11, True)
    fR  = _font(11)
    fS  = _font(9)

    # ── title bar
    d.rectangle([0,0,W,50], fill=C["navy"])
    d.text((18,13), "BPC EPM  ·  Validations Report  ·  Model: BMAIN  ·  Local Currency",
           font=fT, fill=C["white"])

    # ── dynamic title formula strip
    d.rectangle([0,50,W,72], fill=(230,230,250))
    d.text((18,56), 'Title formula: =" Validation Local Currency for "&EPMMemberDesc($D$5)&" on "&EPMMemberDesc($D$6)&" . "',
           font=fS, fill=(60,0,120))

    # ── context bar
    d.rectangle([0,72,W,100], fill=C["lblue"])
    ctx = [("MODEL","BMAIN"),("CATEGORY","<EPMContextMember>"),
           ("ENTITY","<EPMContextMember>"),("TIME","<EPMContextMember>")]
    for i,(k,v) in enumerate(ctx):
        x = 18+i*270
        d.text((x,78), k+":", font=fBs, fill=C["text"])
        d.text((x+82,78), v, font=fR, fill=(0,80,160))

    # ── entity selection logic strip
    d.rectangle([0,100,W,136], fill=(245,245,245))
    d.text((18,104), "Entity Selection Logic:", font=fBs, fill=C["navy"])
    lines = [
        'A3: =IF(#REF!="All Entities","BASEMEMBERS",A5)      ← toggle between All Entities or single ENTITY',
        'A5: =IF(A7="N", D5, "BAS("&D5&")")                  ← if CALC=N use member directly; else wrap BAS()',
        'A6: =EPMDimensionOverride("000", C5, A5)             ← inject entity override into report',
        'A7: =EPMMemberProperty("BMAIN", D5, "CALC")          ← read CALC property to decide member type',
    ]
    for i,ln in enumerate(lines):
        d.text((18,116+i*12), ln, font=fS, fill=(60,60,60)) if i < 2 else None
    d.text((18,116), lines[0], font=fS, fill=(60,60,60))
    d.text((18,126), lines[1], font=fS, fill=(60,60,60))

    # ── objective / action
    d.rectangle([0,136,W,162], fill=C["yellow"])
    d.text((18,140), "Objective:", font=fBs, fill=(100,70,0))
    d.text((100,140), 'Data validation by entity — "Asset vs Liab", "P&L Net Income vs BS", Balance Movements, Error flows',
           font=fR, fill=(100,70,0))
    d.text((18,152), "User Action:", font=fBs, fill=(100,70,0))
    d.text((100,152), "Review and request the team to FIX any validation highlighted in RED",
           font=fR, fill=(160,0,0))

    # ── column headers
    cols = [
        ("Val #",80),("Description",300),("Check Formula",140),("Validation",130),
        ("FS Account",120),("FLOW",65),("TPARTNER / LocalMember",220),("Entity →",640),
    ]
    yh = 162
    d.rectangle([0,yh,W,yh+30], fill=C["blue"])
    x=10
    for lbl,w in cols:
        d.text((x+4,yh+8), lbl, font=fBs, fill=C["white"])
        d.line([(x+w,yh),(x+w,yh+30)], fill=C["white"])
        x+=w

    # ── Restrictive section header
    y = yh+30
    d.rectangle([0,y,W,y+22], fill=(210,228,255))
    d.text((10,y+4), "RESTRICTIVE VALIDATIONS  (Tolerance checked per entity — highlighted RED if breached)",
           font=fB, fill=C["navy"])
    y+=22

    # [val_id, description, formula, validation, account, flow, local_member_label / tpartner, tolerance_note]
    restrictive = [
        ("V11001","Asset = Liabilities + Equity",      "=SUM(J11:XX11)",    "IF OR(E>100)",
         "1001000001","B99",  "IC_TOTAL_THIRD",                      "±100"),
        ("V11002","OB Assets = OB Liabilities",         "=SUM(J12:XX12)",    "IF OR(E>10)",
         "1001000001","B10",  "IC_TOTAL_THIRD",                      "±10"),
        ("V11003","Net Income P&L = Net Income BS",     "=SUM(J13,J14)−J15","IF OR(E>10)",
         "2001000001","B99",  "LocalMember('',000)",                 "±10"),
        ("V11004","Balance Movements = End Balance",    "=J17−J11",          "IF OR(E>10)",
         "GCOA",      "ERR",  "LocalMember('Closing',001)",          "±10"),
        ("V11005","ERROR Movement Type Validation",     "=SUM(J20:XX20)",    "IF OR(E>10)",
         "GCOA",      "ERR",  "IC_TOTAL_THIRD",                      "±10"),
    ]
    for i,(code,desc,formula,val,acct,flow,tm,tol) in enumerate(restrictive):
        bg = C["row_a"] if i%2==0 else C["row_b"]
        d.rectangle([0,y,W,y+22],fill=bg)
        row_data=[code,desc,formula,val,acct,flow,tm,f"→ per entity  {tol}"]
        x=10
        for cell_val,(lbl,w) in zip(row_data,cols):
            color=(120,0,0) if "LocalMember" in str(cell_val) else C["text"]
            d.text((x+3,y+5),str(cell_val)[:32],font=fS,fill=color)
            d.line([(x+w,y),(x+w,y+22)],fill=C["grid"])
            x+=w
        d.line([(0,y+22),(W,y+22)],fill=C["grid"])
        y+=22

    # ── Exceptions section
    d.rectangle([0,y,W,y+22], fill=(210,228,255))
    d.text((10,y+4),"EXCEPTIONS / VALIDATION ERRORS  (EPMLocalMember used as virtual TPARTNER axis)",
           font=fB, fill=C["navy"])
    y+=22

    exceptions = [
        ("V11006","Missing Seller Margin %",           "COUNTIFS(Seller!$F,$M,'0')",   "IF >0",  "GCOA","ERR","LocalMember('Missing Seller',027)","0/1"),
        ("V11007","Missing Buyer Allocation %",        "COUNTIFS(Buyer!$H,$M,'0')",    "IF >0",  "GCOA","ERR","LocalMember('Missing Buyer',028)","0/1"),
        ("V11008","RP Payable – TP THIRD",             "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('RP Payable',003)","±100"),
        ("V11009","RP Receivable – TP THIRD",          "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('RP Receivable',004)","±100"),
        ("V110010","Capex Transfer (Flow-400)",        "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Capex Move',013)","±100"),
        ("V110010","Accum Dep BS vs P&L",              "VLOOKUP(EntityKey,#REF,17)",   "IF ABS>100","GCOA","ERR","LocalMember('Accum Dep',016)","±100"),
        ("V110011","Prov Inventory BS vs P&L",         "VLOOKUP(EntityKey,#REF,5)",    "IF ABS>100","GCOA","ERR","LocalMember('Prov Inv',017)","±100"),
        ("V110012","Prov Receivables BS vs P&L",       "VLOOKUP(EntityKey,#REF,12)",   "IF ABS>100","GCOA","ERR","LocalMember('Prov Rec',018)","±100"),
        ("V110013","Investment in Subs – TP THIRD",   "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Invest in Subs',019)","±100"),
        ("V110014","Prov Investment BS vs P&L",        "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Prov Invest vs P&L',020)","±100"),
        ("V110015","Negative Revenue",                 "VLOOKUP(EntityKey,#REF,2)",    "IF ABS>100","GCOA","ERR","LocalMember('Negative Rev',021)","±100"),
        ("V110016","Dividend Income – TP THIRD",       "VLOOKUP(EntityKey,#REF,2)",    "IF ABS>100","GCOA","ERR","LocalMember('Dividend Inc',022)","±100"),
        ("V110017","Capex Addition Negative",          "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Capex Addition',023)","±100"),
        ("V110018","Capex Disposal Positive",          "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Capex Disposal',002)","±100"),
        ("V110019","Receivable Reverse Balance",       "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Receivable Reverse',005)","±100"),
        ("V110020","Payable Reverse Balance",          "SUMIF(#REF,EntityKey,#REF)",   "IF ABS>100","GCOA","ERR","LocalMember('Payable Reverse',006)","±100"),
        ("V110021","Reserves Addition vs Transfer",    "VLOOKUP(EntityKey,#REF,23)",   "IF ABS>100","GCOA","ERR","LocalMember('Reserve',024)","±100"),
        ("V110022","Finance Cost/COE – TP THIRD",      "VLOOKUP(EntityKey,#REF,12)",   "IF ABS>100","GCOA","ERR","LocalMember('Finance & COE',007)","±100"),
    ]
    for i,(code,desc,formula,val,acct,flow,tm,tol) in enumerate(exceptions):
        if y>H-55: break
        bg = C["row_a"] if i%2==0 else C["row_b"]
        d.rectangle([0,y,W,y+21],fill=bg)
        row_data=[code,desc,formula,val,acct,flow,tm,f"→ {tol}"]
        x=10
        for cell_val,(lbl,w) in zip(row_data,cols):
            color=(120,0,150) if "LocalMember" in str(cell_val) else C["text"]
            d.text((x+3,y+5),str(cell_val)[:32],font=fS,fill=color)
            d.line([(x+w,y),(x+w,y+21)],fill=C["grid"])
            x+=w
        d.line([(0,y+21),(W,y+21)],fill=C["grid"])
        y+=21

    # ── total row
    if y<H-28:
        d.rectangle([0,y,W,y+28],fill=C["red_bg"])
        d.text((10,y+7),
               "TOTAL FAILED VALIDATIONS  =SUM(F23:F40)  ← horizontal aggregation across all entity columns (J … XX)",
               font=fBs, fill=C["white"])

    # ── Division grouping note at bottom
    note_y = H-42
    d.rectangle([0,note_y,W,H], fill=(248,240,255))
    d.text((10,note_y+4),
           "Division grouping (Validations Group sheet):  J40=EPMMemberProperty(\"BMAIN\",J10,\"DIVISIONS\")  →  "
           "SUMIF($40:$40, DivisionCode, ValidationRow)  →  Divisions: CORPORATE · AUTOMOTIVE · RETAIL · CONTRACTING · OTHER SERVICES · REAL ESTATE · HEALTHCARE · SCHOOL · SERVICES · FIN_SERVICES",
           font=fS, fill=(80,0,100))

    d.rectangle([0,0,W-1,H-1], outline=(80,80,80), width=2)
    img.save(out_path, "PNG")
    return out_path


# ── data extraction ─────────────────────────────────────────────────────────────

def extract_all(excel_path):
    wb = openpyxl.load_workbook(excel_path, data_only=False)
    ws = wb['Validations']

    # ── dimensions ──────────────────────────────────────────────────────────
    dimensions = [
        {
            "name":"MODEL","display":"Static — BMAIN","sorting":"N/A",
            "hierarchies":"—","properties":"—",
            "context_formula":"=BMAIN (hardcoded)",
            "business_rules":"Fixed reference to BPC model cube BMAIN",
        },
        {
            "name":"CATEGORY","display":"ID (context-driven)","sorting":"Ascending",
            "hierarchies":"—","properties":"—",
            "context_formula":"=_xll.EPMContextMember($D$3, C4)",
            "business_rules":"Reads active category from EPM context pane (e.g. Actual, Budget)",
        },
        {
            "name":"ENTITY","display":"ID_Description  (e.g. 1090_Al Futtaim)","sorting":"Ascending by ID",
            "hierarchies":"PARENTH1","properties":"CALC, DIVISIONS",
            "context_formula":"=_xll.EPMContextMember($D$3, C5)",
            "business_rules":(
                "1) EPMMemberProperty('BMAIN',D5,'CALC') → reads CALC flag.\n"
                "2) IF CALC='N' → use member directly; IF CALC='Y' → BAS(member) for base expansion.\n"
                "3) EPMDimensionOverride('000',C5,A5) → injects chosen entity into all report formulas.\n"
                "4) Toggle A3: IF(#REF!='All Entities','BASEMEMBERS',A5) allows multi-entity run."
            ),
        },
        {
            "name":"TIME","display":"ID (context-driven)","sorting":"Ascending",
            "hierarchies":"—","properties":"—",
            "context_formula":"=_xll.EPMContextMember($D$3, C6)",
            "business_rules":"Reads active period/year from EPM context",
        },
        {
            "name":"ACCOUNT","display":"ID - Description  (e.g. 1001000001 - Total Assets)","sorting":"Ascending by ID",
            "hierarchies":"PARENTH1, PARENTH2","properties":"—",
            "context_formula":"EPMOlapMemberO('[ACCOUNT].[PARENTH1].[member]','','displayText','','000')",
            "business_rules":(
                "GCOA = Group Chart of Accounts (aggregates all accounts).\n"
                "PARENTH1 = primary financial hierarchy.\n"
                "PARENTH2 = secondary/SME hierarchy (used in Seller % report).\n"
                "Specific accounts pinned per validation row via EPMOlapMemberO."
            ),
        },
        {
            "name":"BFLOW","display":"ID - Description  (e.g. B99 - Closing Bal.)","sorting":"Ascending by ID",
            "hierarchies":"PARENTH1","properties":"—",
            "context_formula":"EPMOlapMemberO('[BFLOW].[PARENTH1].[member]','','displayText','','000')",
            "business_rules":(
                "B10 = Opening Balance.  B99 = Closing Balance.  "
                "TOTB = Total (all flows).  ERR = Error capture flow.\n"
                "ERR flow is used exclusively for exceptions/validation-error rows — "
                "it accumulates any discrepancy found by SUMIF/VLOOKUP into BPC."
            ),
        },
        {
            "name":"TPARTNER (& LocalMember)","display":"ID-Description  OR  LocalMember label","sorting":"Ascending by ID",
            "hierarchies":"PARENTH1","properties":"—",
            "context_formula":"EPMOlapMemberO  OR  _xll.FPMXLClient.TechnicalCategory.EPMLocalMember(label,id,parent)",
            "business_rules":(
                "Two types used:\n"
                "  A) EPMOlapMemberO — real BPC dimension members (IC_TOTAL_THIRD, THIRD, etc.).\n"
                "  B) EPMLocalMember — virtual in-memory members created for calculation rows "
                "that have no natural TPARTNER (e.g. Net Income reconciliation, Balance Movements). "
                "Each LocalMember has a Label, a numeric ID (001–028), and parent 000. "
                "They are ephemeral: they only exist in the Excel session and are never written to BPC."
            ),
        },
        {
            "name":"DATASRC (cross-ref)","display":"ID - Description","sorting":"Ascending",
            "hierarchies":"PARENTH1","properties":"—",
            "context_formula":"EPMOlapMemberO('[DATASRC].[PARENTH1].[UPLOAD/AD_MLC]',...)",
            "business_rules":"UPLOAD = primary data; AD_MLC = manual adjustment load (used in Seller % sub-report).",
        },
    ]

    # ── EPM Local Members ────────────────────────────────────────────────────
    local_members = []
    for row_idx in range(11,45):
        cell = ws[f'I{row_idx}']
        if not cell.value or not isinstance(cell.value,str): continue
        m = re.search(r'EPMLocalMember\("([^"]*?)","([^"]*?)","([^"]*?)"\)', cell.value)
        if m:
            label,id_,parent = m.group(1),m.group(2),m.group(3)
            code  = ws[f'C{row_idx}'].value or ""
            desc  = ws[f'D{row_idx}'].value or ""
            local_members.append({
                "cell":f"I{row_idx}","code":str(code),"description":str(desc),
                "label":label,"id":id_,"parent":parent,
                "full_formula":cell.value.strip()[:120],
            })

    # ── EPMOlapMemberO — all unique per dimension ────────────────────────────
    olap_members = {}
    for row in ws.iter_rows(min_row=1,max_row=50):
        for cell in row:
            if not cell.value or not isinstance(cell.value,str): continue
            for m in re.finditer(
                r'EPMOlapMemberO\("(\[([A-Z]+)\]\.[A-Z0-9]+\.\[([A-Z0-9_]+)\])","","([^"]*)"',
                cell.value):
                dim,member,display = m.group(2),m.group(3),m.group(4)
                olap_members.setdefault(dim,{})[member]=display

    # ── measures ──────────────────────────────────────────────────────────────
    measures = []
    for row_idx in range(11,45):
        code  = ws[f'C{row_idx}'].value
        desc  = ws[f'D{row_idx}'].value
        check = ws[f'E{row_idx}'].value
        val_f = ws[f'F{row_idx}'].value
        acct  = ws[f'G{row_idx}'].value
        flow  = ws[f'H{row_idx}'].value
        tp    = ws[f'I{row_idx}'].value
        sub   = ws[f'J{row_idx}'].value   # entity-level override formula

        if not code or not isinstance(code,str) or not code.startswith('V'): continue

        # parse member IDs from OlapMemberO formulas
        def pid(f):
            if not f or not isinstance(f,str): return "—"
            m2 = re.search(r'\.\[([A-Z0-9_]+)\]","","([^"]+)"',f)
            return f"{m2.group(1)} ({m2.group(2)[:30]})" if m2 else str(f)[:40]

        # check if local member
        lm_match = re.search(r'EPMLocalMember\("([^"]*?)","([^"]*?)"',str(tp or ""))
        tpartner_str = (
            f"EPMLocalMember  label='{lm_match.group(1)}' id={lm_match.group(2)}"
            if lm_match else pid(str(tp or ""))
        )

        tolerance_match = re.search(r'>(\d+)',str(val_f or ""))
        tolerance = f"±{tolerance_match.group(1)}" if tolerance_match else "0/1 flag"

        # entity-level formula (overrides SUM for special rows)
        entity_formula = ""
        if sub and isinstance(sub,str) and sub.startswith('='):
            entity_formula = sub[:100]

        measures.append({
            "code":str(code),
            "description":str(desc or ""),
            "check_formula":str(check or "")[:80],
            "entity_formula":entity_formula,
            "validation_formula":str(val_f or "")[:80],
            "account":pid(str(acct or "")),
            "flow":pid(str(flow or "")),
            "tpartner":tpartner_str,
            "tolerance":tolerance,
        })

    wb.close()
    return dimensions, local_members, olap_members, measures


# ── JS escape ──────────────────────────────────────────────────────────────────
def _j(s):
    return (str(s)
            .replace("\\","\\\\").replace("`","\\`").replace("${","\\${")
            .replace("\n","  |  ").replace('"','\\"').replace("'","\\'"))


# ── docx builder ───────────────────────────────────────────────────────────────

def build_docx(out_path, screenshot_path, dimensions, local_members, olap_members, measures):
    with open(screenshot_path,"rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    with Image.open(screenshot_path) as im:
        iw,ih = im.size

    emu_w  = 9_200_000
    emu_h  = int(emu_w*ih/iw)
    px_w   = round(emu_w/9525)
    px_h   = round(emu_h/9525)

    bdr = '{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }'
    bdr_all = f'{{ top:{bdr}, bottom:{bdr}, left:{bdr}, right:{bdr} }}'
    marg = '{ top:60, bottom:60, left:100, right:100 }'

    # ── helper: header row cell
    def hdr_cell(txt, w, bg="0070C0"):
        return (f'new TableCell({{ width:{{size:{w},type:WidthType.DXA}}, '
                f'borders:{bdr_all}, margins:{marg}, '
                f'shading:{{fill:"{bg}",type:ShadingType.CLEAR}}, '
                f'children:[new Paragraph({{children:[new TextRun({{text:"{_j(txt)}",bold:true,'
                f'size:19,color:"FFFFFF",font:"Arial"}})]}})]}})')

    def data_cell(txt, w, shade="FFFFFF", bold=False, color="333333", font="Arial", size=18):
        return (f'new TableCell({{ width:{{size:{w},type:WidthType.DXA}}, '
                f'borders:{bdr_all}, margins:{marg}, '
                f'shading:{{fill:"{shade}",type:ShadingType.CLEAR}}, '
                f'children:[new Paragraph({{children:[new TextRun({{text:"{_j(txt)}", '
                f'bold:{"true" if bold else "false"},size:{size},color:"{color}",font:"{font}"}})]}})]}})')

    def section_hdr(txt):
        return (f'new Paragraph({{ heading: HeadingLevel.HEADING_2, '
                f'children:[new TextRun({{text:"{_j(txt)}",bold:true,font:"Arial"}})] }})')

    def sub_hdr(txt):
        return (f'new Paragraph({{ heading: HeadingLevel.HEADING_3, '
                f'children:[new TextRun({{text:"{_j(txt)}",bold:true,font:"Arial"}})] }})')

    def note_para(txt, color="444444"):
        return (f'new Paragraph({{spacing:{{before:40,after:40}},children:[new TextRun({{text:"{_j(txt)}",'
                f'size:19,color:"{color}",font:"Arial"}})]}})')

    # ── 1. Dimension table rows ───────────────────────────────────────────────
    dim_rows = []
    w_dim=[2100,2000,900,1300,1100,1200,5760]  # sums to 14360
    shade_a,shade_b="EAF2FB","FFFFFF"
    for i,dim in enumerate(dimensions):
        shade = shade_a if i%2==0 else shade_b
        def dc(v,w): return data_cell(v,w,shade)
        dim_rows.append(
            f'new TableRow({{ children:[ '
            f'{dc(dim["name"],w_dim[0])},'
            f'{dc(dim["display"],w_dim[1])},'
            f'{dc(dim["sorting"],w_dim[2])},'
            f'{dc(dim["hierarchies"],w_dim[3])},'
            f'{dc(dim["properties"],w_dim[4])},'
            f'{dc(dim["context_formula"],w_dim[5])},'
            f'{data_cell(dim["business_rules"],w_dim[6],shade,False,"555555")}'
            f'] }})'
        )

    # ── 2. EPMLocalMember table rows ─────────────────────────────────────────
    lm_rows = []
    w_lm=[700,1500,2400,700,600,1200,7260]
    for i,lm in enumerate(local_members):
        shade = shade_a if i%2==0 else shade_b
        def dc(v,w,**kw): return data_cell(v,w,shade,**kw)
        lm_rows.append(
            f'new TableRow({{ children:[ '
            f'{data_cell(lm["cell"],w_lm[0],shade,False,"666666")},'
            f'{data_cell(lm["code"],w_lm[1],shade,True,"0070C0")},'
            f'{dc(lm["description"],w_lm[2])},'
            f'{data_cell(lm["label"],w_lm[3],"E8D5F5",True,"5C0099")},'
            f'{data_cell(lm["id"],w_lm[4],"E8D5F5",False,"5C0099")},'
            f'{data_cell(lm["parent"],w_lm[5],"E8D5F5",False,"5C0099")},'
            f'{data_cell(lm["full_formula"],w_lm[6],shade,False,"333333","Courier New",16)}'
            f'] }})'
        )

    # ── 3. EPMOlapMemberO table rows ─────────────────────────────────────────
    olap_rows = []
    w_olap=[1200,1800,5000,6360]
    for dim,mems in sorted(olap_members.items()):
        for j,(mid,disp) in enumerate(sorted(mems.items())):
            shade = shade_a if j%2==0 else shade_b
            olap_rows.append(
                f'new TableRow({{ children:[ '
                f'{data_cell(dim if j==0 else "",w_olap[0],"D9EAF8" if j==0 else shade,j==0,"0070C0")},'
                f'{data_cell(mid,w_olap[1],shade,False,"0070C0")},'
                f'{data_cell(disp,w_olap[2],shade)},'
                f'{data_cell(f"[{dim}].[PARENTH1].[{mid}]",w_olap[3],shade,False,"555555","Courier New",16)}'
                f'] }})'
            )

    # ── 4. Measures table rows ────────────────────────────────────────────────
    meas_rows = []
    w_m=[750,2200,1700,1700,2200,2200,900,1100,600,3010]  # sums to 16360
    for i,m in enumerate(measures):
        shade = shade_a if i%2==0 else shade_b
        has_lm = "EPMLocalMember" in m["tpartner"]
        tp_color = "7B00CC" if has_lm else "444444"
        meas_rows.append(
            f'new TableRow({{ children:[ '
            f'{data_cell(m["code"],w_m[0],shade,True,"0070C0")},'
            f'{data_cell(m["description"],w_m[1],shade)},'
            f'{data_cell(m["check_formula"],w_m[2],shade,False,"333333","Courier New",15)},'
            f'{data_cell(m["entity_formula"],w_m[3],shade,False,"007700","Courier New",15)},'
            f'{data_cell(m["validation_formula"],w_m[4],shade,False,"333333","Courier New",15)},'
            f'{data_cell(m["account"],w_m[5],shade)},'
            f'{data_cell(m["flow"],w_m[6],shade)},'
            f'{data_cell(m["tpartner"],w_m[7],"EDE0F5" if has_lm else shade,False,tp_color)},'
            f'{data_cell(m["tolerance"],w_m[8],"FFF2CC")},'
            f'{data_cell(m["description"],w_m[9],shade,False,"555555")}'  # full desc
            f'] }})'
        )

    js = f"""
const {{ Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        ImageRun, Header, Footer, AlignmentType, HeadingLevel, BorderStyle,
        WidthType, ShadingType, VerticalAlign, PageNumber, PageBreak }} = require('docx');
const fs = require('fs');

const border  = {bdr};
const borders = {bdr_all};
const margins = {marg};
const img64   = Buffer.from("{b64}","base64");

const doc = new Document({{
  styles:{{
    default:{{ document:{{ run:{{ font:"Arial",size:20 }} }} }},
    paragraphStyles:[
      {{ id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,
         run:{{size:38,bold:true,color:"00467F",font:"Arial"}},
         paragraph:{{spacing:{{before:240,after:120}},outlineLevel:0}} }},
      {{ id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,
         run:{{size:28,bold:true,color:"0070C0",font:"Arial"}},
         paragraph:{{spacing:{{before:200,after:80}},outlineLevel:1}} }},
      {{ id:"Heading3",name:"Heading 3",basedOn:"Normal",next:"Normal",quickFormat:true,
         run:{{size:24,bold:true,color:"404040",font:"Arial"}},
         paragraph:{{spacing:{{before:160,after:60}},outlineLevel:2}} }},
    ]
  }},
  sections:[{{
    properties:{{
      page:{{
        size:{{width:16840,height:11906}},
        margin:{{top:700,right:700,bottom:700,left:700}}
      }}
    }},
    headers:{{ default: new Header({{ children:[
      new Paragraph({{ alignment:AlignmentType.RIGHT, children:[
        new TextRun({{text:"BPC EPM — Validations Report  |  Model: BMAIN  |  Page ",size:17,color:"888888",font:"Arial"}}),
        new TextRun({{children:[PageNumber.CURRENT],size:17,color:"888888",font:"Arial"}}),
        new TextRun({{text:" of ",size:17,color:"888888",font:"Arial"}}),
        new TextRun({{children:[PageNumber.TOTAL_PAGES],size:17,color:"888888",font:"Arial"}}),
      ]}})
    ]}}) }},
    children:[

      // ════════════════════════════════
      // TITLE
      // ════════════════════════════════
      new Paragraph({{ heading:HeadingLevel.HEADING_1,
        children:[new TextRun({{text:"Report 1: BPC EPM Validations Report",bold:true,font:"Arial"}})] }}),
      new Paragraph({{ children:[new TextRun({{text:"SAP BPC / EPM  ·  Model: BMAIN  ·  Local Currency Validation  ·  Version 1.1",size:22,color:"555555",font:"Arial"}})] }}),
      new Paragraph({{ spacing:{{before:60,after:60}}, children:[new TextRun({{text:"",size:4}})] }}),

      new Table({{
        width:{{size:15440,type:WidthType.DXA}}, columnWidths:[1800,13640],
        rows:[
          new TableRow({{ children:[
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"00467F",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"Report Title",bold:true,size:19,color:"FFFFFF",font:"Arial"}})]}})] }}),
            new TableCell({{ width:{{size:13640,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"FFFFCC",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:'= " Validation Local Currency for " & EPMMemberDesc($D$5) & " on " & EPMMemberDesc($D$6) & " . "',size:18,font:"Courier New",color:"7B00CC"}})]}})] }}),
          ]}}),
          new TableRow({{ children:[
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"00467F",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"Objective",bold:true,size:19,color:"FFFFFF",font:"Arial"}})]}})] }}),
            new TableCell({{ width:{{size:13640,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"FFFFCC",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:'Data validation by entity — "Asset vs Liabilities+Equity", "P&L Net Income vs BS Net Income", Balance Movement reconciliation, ERROR flow validation.',size:19,font:"Arial"}})]}})] }}),
          ]}}),
          new TableRow({{ children:[
            new TableCell({{ width:{{size:1800,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"00467F",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"User Action",bold:true,size:19,color:"FFFFFF",font:"Arial"}})]}})] }}),
            new TableCell({{ width:{{size:13640,type:WidthType.DXA}},borders,margins,
              shading:{{fill:"FFF2CC",type:ShadingType.CLEAR}},
              children:[new Paragraph({{children:[new TextRun({{text:"Review and request the team to fix any validation highlighted in RED.",size:19,font:"Arial",color:"C00000"}})]}})] }}),
          ]}}),
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 1. SCREENSHOT
      // ════════════════════════════════
      {section_hdr("1.  Report Layout Screenshot")},
      {note_para("Full report structure as rendered in BPC EPM Excel add-in, showing dimension context, entity columns (J–XX), validation rows, LocalMember virtual TPARTNER axis, and total aggregation.")},
      new Paragraph({{ spacing:{{before:80,after:80}}, children:[
        new ImageRun({{ data:img64, transformation:{{width:{px_w},height:{px_h}}}, type:"png" }})
      ]}}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 2. DIMENSIONS
      // ════════════════════════════════
      {section_hdr("2.  Dimensions — Display Format · Sorting · Hierarchies · Business Rules")},
      {note_para("All 8 dimensions used in this report. Context dimensions (CATEGORY, ENTITY, TIME) are driven by EPMContextMember. ENTITY additionally uses EPMDimensionOverride and EPMMemberProperty for dynamic selection.")},
      new Paragraph({{ spacing:{{before:60}}, children:[new TextRun({{text:"",size:4}})] }}),

      new Table({{
        width:{{size:15440,type:WidthType.DXA}},
        columnWidths:{w_dim},
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Dimension",w_dim[0])},
            {hdr_cell("Display Format (Key ID / Text)",w_dim[1])},
            {hdr_cell("Sort",w_dim[2])},
            {hdr_cell("Hierarchies",w_dim[3])},
            {hdr_cell("Properties",w_dim[4])},
            {hdr_cell("Context Formula",w_dim[5])},
            {hdr_cell("Business Rules",w_dim[6])},
          ]}}),
          {",".join(dim_rows)}
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 3. EPMLocalMember
      // ════════════════════════════════
      {section_hdr("3.  EPMLocalMember — Custom Virtual Members (TPARTNER axis)")},
      {note_para("EPMLocalMember creates ephemeral, in-memory members on the TPARTNER axis for validation rows that have no natural trading partner. They are never written to BPC. Each has a human-readable Label, a numeric ID (001–028), and parent 000.")},
      {note_para("Full function signature:   _xll.FPMXLClient.TechnicalCategory.EPMLocalMember( Label, ID, ParentID )","5C0099")},
      new Paragraph({{ spacing:{{before:60}}, children:[new TextRun({{text:"",size:4}})] }}),

      new Table({{
        width:{{size:15440,type:WidthType.DXA}},
        columnWidths:{w_lm},
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Cell",w_lm[0])},
            {hdr_cell("Validation Code",w_lm[1])},
            {hdr_cell("Validation Description",w_lm[2])},
            {hdr_cell("Label",w_lm[3],"5C0099")},
            {hdr_cell("ID",w_lm[4],"5C0099")},
            {hdr_cell("Parent",w_lm[5],"5C0099")},
            {hdr_cell("Full Formula",w_lm[6])},
          ]}}),
          {",".join(lm_rows)}
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 4. EPMOlapMemberO
      // ════════════════════════════════
      {section_hdr("4.  EPMOlapMemberO — Pinned Dimension Members")},
      {note_para("EPMOlapMemberO pins a specific BPC dimension member to a cell so the data retrieval uses that member regardless of context. Syntax: EPMOlapMemberO( MemberPath, AltHierarchy, DisplayText, Description, ReportID )")},
      new Paragraph({{ spacing:{{before:60}}, children:[new TextRun({{text:"",size:4}})] }}),

      new Table({{
        width:{{size:15440,type:WidthType.DXA}},
        columnWidths:{w_olap},
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Dimension",w_olap[0])},
            {hdr_cell("Member ID",w_olap[1])},
            {hdr_cell("Display Text",w_olap[2])},
            {hdr_cell("Full MDX Path",w_olap[3])},
          ]}}),
          {",".join(olap_rows) if olap_rows else
            'new TableRow({children:[' +
            data_cell("(No pinned OLAP members detected — OlapMemberO refs are dynamic)",15440) +
            ']})'}
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 5. OTHER EPM FUNCTIONS
      // ════════════════════════════════
      {section_hdr("5.  Other EPM Custom Functions & Customisations")},

      new Table({{
        width:{{size:15440,type:WidthType.DXA}}, columnWidths:[2200,2200,5640,5400],
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Function",2200)},{hdr_cell("Signature",2200)},
            {hdr_cell("Where Used",5640)},{hdr_cell("Business Logic",5400)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMContextMember",2200,"D9EAF8",True,"0070C0")},
            {data_cell("(ModelID, DimLabel)",2200,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("D4 (CATEGORY), D5 (ENTITY), D6 (TIME)",5640,"D9EAF8")},
            {data_cell("Reads the currently active member from the EPM context pane. Allows the report to run for any period/entity without changing formulas.",5400,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMDimensionOverride",2200,"FFFFFF",True,"0070C0")},
            {data_cell("(ReportID, DimName, Member)",2200,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("A6: EPMDimensionOverride('000', C5, A5)",5640)},
            {data_cell("Injects the entity selection (single entity or BASEMEMBERS) into ALL retrieve formulas with ReportID=000. Enables toggling between single-entity and all-entities mode.",5400)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMMemberProperty",2200,"D9EAF8",True,"0070C0")},
            {data_cell("(ModelID, Member, PropName)",2200,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("A7: ...('BMAIN',D5,'CALC')  |  J40: ...('BMAIN',J10,'DIVISIONS')",5640,"D9EAF8")},
            {data_cell("A7 reads CALC flag to decide BAS() wrapping. J40 reads DIVISIONS property to group validation results by business division (AUTOMOTIVE, RETAIL, etc.).",5400,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMMemberDesc",2200,"FFFFFF",True,"0070C0")},
            {data_cell("(Member)",2200,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("Report title: EPMMemberDesc($D$5)&EPMMemberDesc($D$6)  |  Validation rows: EntityID & ' - ' & EPMMemberDesc(J10)",5640)},
            {data_cell("Returns the text description of a member ID. Used to build: (1) dynamic report title showing entity+period names; (2) entity lookup keys in SUMIF/VLOOKUP/COUNTIFS ('1090 - Al Futtaim').",5400)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMModelCubeID",2200,"D9EAF8",True,"0070C0")},
            {data_cell("(ModelName)",2200,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("I15 in Seller%, I3 in Buyer%: EPMModelCubeID('BMAIN')",5640,"D9EAF8")},
            {data_cell("Returns the runtime cube identifier for model BMAIN, used as the ModelID parameter in EPMRetrieveData and EPMReadOnlyData calls.",5400,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMRetrieveData",2200,"FFFFFF",True,"0070C0")},
            {data_cell("(ModelID, Ent, TP, Acct, Flow)",2200,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("M17 in Buyer%: EPMRetrieveData($I$3, H17, I17, 'GCOA', EPMMemberProperty($I$3,K17,'PARENTH1'))",5640)},
            {data_cell("Fetches a single data point from BPC cube for a specified entity/trading-partner/account/flow combination. Used in Buyer% to retrieve the allocation percentage per entity-seller pair.",5400)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("EPMReadOnlyData",2200,"D9EAF8",True,"0070C0")},
            {data_cell("(ReportID, Range)",2200,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("A4 in Buyer%: EPMReadOnlyData('000', $L$18:$L$10484)",5640,"D9EAF8")},
            {data_cell("Marks a range as read-only output data (prevents inadvertent edits). Used to lock the retrieved Buyer% values column.",5400,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("BAS() / BASEMEMBERS",2200,"FFFFFF",True,"0070C0")},
            {data_cell("BAS(ParentMember)",2200,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("A5: BAS(entity)  |  Buyer% B26: BAS(6701000100)  |  Buyer% B27: BAS(SM_TOT)",5640)},
            {data_cell("BAS(member) expands to all base/leaf members below a parent. BAS(entity) → all entities in hierarchy. BAS(6701000100) → all 10 TP Purchase accounts. BAS(SM_TOT) → all stock-margin flow types.",5400)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("Array Formulas",2200,"D9EAF8",True,"0070C0")},
            {data_cell("{{=formula}} (Ctrl+Shift+Enter)",2200,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("Instructions sheet: dimension selection. Seller% I16-I19: Time/Currency/Entity. Buyer% B2, D6-D15: account expansion.",5640,"D9EAF8")},
            {data_cell("Array formulas execute across multiple cells simultaneously. Used for EPM dimension-list population in context headers, enabling dynamic selection of Category, Time, and Entity from BPC metadata.",5400,"D9EAF8")},
          ]}}),
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 6. DIVISION GROUPING
      // ════════════════════════════════
      {section_hdr("6.  Division Grouping Logic  (Validations Group sheet)")},
      {note_para("The Validations Group sheet aggregates entity-level results into business division totals using EPMMemberProperty and SUMIF.")},

      new Table({{
        width:{{size:15440,type:WidthType.DXA}}, columnWidths:[2000,3440,10000],
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Step",2000)},{hdr_cell("Cell / Formula",3440)},{hdr_cell("Logic",10000)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("1. Read Division",2000,"D9EAF8",True)},
            {data_cell("J40: EPMMemberProperty('BMAIN', J10, 'DIVISIONS')",3440,"D9EAF8",False,"333333","Courier New",16)},
            {data_cell("For each entity column (J→XX), reads the DIVISIONS property from BPC master data. Returns codes like AUTOMOTIVE, RETAIL, CORPORATE, etc.",10000,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("2. Aggregate by Division",2000,"FFFFFF",True)},
            {data_cell("=SUMIF($40:$40, DivCode, ValidationRow)",3440,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("For each division code in row 54, SUMIF scans row 40 (division labels) and sums the corresponding validation values. Produces one aggregated score per division per validation rule.",10000)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("3. Division Codes",2000,"D9EAF8",True)},
            {data_cell("Rows 55–84 in Validations Group",3440,"D9EAF8")},
            {data_cell("Divisions: CORPORATE · AUTOMOTIVE · RETAIL · CONTRACTING · OTHER SERVICES · REAL ESTATE · HEALTHCARE · SCHOOL · SERVICES · FIN_SERVICES",10000,"D9EAF8")},
          ]}}),
          new TableRow({{ children:[
            {data_cell("4. Total per Division",2000,"FFFFFF",True)},
            {data_cell("F84: =SUM(F65:F82)",3440,"FFFFFF",False,"333333","Courier New",16)},
            {data_cell("Final roll-up: total failed validations across all validation rules for each division block.",10000)},
          ]}}),
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 7. MEASURES & KPIs
      // ════════════════════════════════
      {section_hdr("7.  Measures / KPIs — Formulas · EPMLocalMember · Business Logic")},
      {note_para("22 validation measures. The 'Entity Formula' column shows the per-entity override formula (col J) for special rows; others use the horizontal SUM(J:XX). Purple cells indicate EPMLocalMember virtual TPARTNER.")},
      new Paragraph({{ spacing:{{before:60}}, children:[new TextRun({{text:"",size:4}})] }}),

      new Table({{
        width:{{size:16360,type:WidthType.DXA}},
        columnWidths:{w_m},
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Code",w_m[0])},
            {hdr_cell("Description",w_m[1])},
            {hdr_cell("Check Formula (SUM)",w_m[2])},
            {hdr_cell("Entity Formula (col J)",w_m[3],"007700")},
            {hdr_cell("Validation Formula",w_m[4])},
            {hdr_cell("Account",w_m[5])},
            {hdr_cell("Flow",w_m[6])},
            {hdr_cell("TPARTNER / LocalMember",w_m[7],"5C0099")},
            {hdr_cell("Tolerance",w_m[8],"C07000")},
            {hdr_cell("Full Description",w_m[9])},
          ]}}),
          {",".join(meas_rows)}
        ]
      }}),

      new Paragraph({{ spacing:{{before:200}}, children:[new TextRun({{text:"",size:4}})] }}),

      // ════════════════════════════════
      // 8. COMPLETE FORMULA REFERENCE
      // ════════════════════════════════
      {section_hdr("8.  Complete Formula Reference — All Key Cells")},

      new Table({{
        width:{{size:15440,type:WidthType.DXA}}, columnWidths:[800,1200,2200,11240],
        rows:[
          new TableRow({{ tableHeader:true, children:[
            {hdr_cell("Cell",800)},{hdr_cell("Sheet",1200)},{hdr_cell("Purpose",2200)},{hdr_cell("Formula",11240)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("C1",800,"EEF6FF")},{data_cell("Val Group",1200,"EEF6FF")},
            {data_cell("Dynamic Title",2200,"EEF6FF")},
            {data_cell('= " Validation Local Currency for " & EPMMemberDesc($D$5) & " on " & EPMMemberDesc($D$6) & " . "',11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("A3",800)},{data_cell("Validations",1200)},
            {data_cell("Entity Toggle",2200)},
            {data_cell('=IF(#REF!="All Entities","BASEMEMBERS",A5)',11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("A4",800,"EEF6FF")},{data_cell("Validations",1200,"EEF6FF")},
            {data_cell("BASEMEMBERS constant",2200,"EEF6FF")},
            {data_cell("BASEMEMBERS",11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("A5",800)},{data_cell("Validations",1200)},
            {data_cell("BAS() decision",2200)},
            {data_cell('=IF(A7="N", D5, "BAS("&D5&")")  →  if CALC=N use member directly; if CALC=Y wrap in BAS()',11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("A6",800,"EEF6FF")},{data_cell("Validations",1200,"EEF6FF")},
            {data_cell("Dimension Override",2200,"EEF6FF")},
            {data_cell("=_xll.EPMDimensionOverride('000', C5, A5)  →  inject entity into report ID 000",11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("A7",800)},{data_cell("Validations",1200)},
            {data_cell("CALC property read",2200)},
            {data_cell("=_xll.EPMMemberProperty('BMAIN', D5, 'CALC')  →  returns Y or N",11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("D4-D6",800,"EEF6FF")},{data_cell("Validations",1200,"EEF6FF")},
            {data_cell("Context members",2200,"EEF6FF")},
            {data_cell("=_xll.EPMContextMember($D$3, C4/C5/C6)  →  reads active CATEGORY / ENTITY / TIME from EPM pane",11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J10",800)},{data_cell("Validations",1200)},
            {data_cell("Entity column header",2200)},
            {data_cell("=_xll.EPMOlapMemberO('[ENTITY].[PARENTH1].[1090]','','1090','','000')  →  pins entity 1090 to column J",11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J16",800,"EEF6FF")},{data_cell("Validations",1200,"EEF6FF")},
            {data_cell("Net Income calc",2200,"EEF6FF")},
            {data_cell("=SUM(J13, J14) - J15  →  Retained Earnings (J13) + Current Year P&L (J14) minus Equity Net Income (J15)",11240,"EEF6FF",False,"007700","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J19",800)},{data_cell("Validations",1200)},
            {data_cell("Balance movement",2200)},
            {data_cell("=J17 - J11  →  TOTB (total balance) minus Closing Balance B99; result flows to ERR",11240,"FFFFFF",False,"007700","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J24",800,"EEF6FF")},{data_cell("Validations",1200,"EEF6FF")},
            {data_cell("Missing Buyer %",2200,"EEF6FF")},
            {data_cell("=COUNTIFS('Missing Buyer %'!$H:$H, J10&' - '&EPMMemberDesc(J10), 'Missing Buyer %'!$M:$M, '0') > 0",11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J28-J40",800)},{data_cell("Validations",1200)},
            {data_cell("Cross-sheet VLOOKUP",2200)},
            {data_cell("=IFERROR(VLOOKUP(J10&' - '&EPMMemberDesc(J10), #REF!, ColIndex, FALSE), 0)  →  EntityKey built as ID+Desc",11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("J40",800,"EEF6FF")},{data_cell("Val Group",1200,"EEF6FF")},
            {data_cell("Division property",2200,"EEF6FF")},
            {data_cell("=_xll.EPMMemberProperty('BMAIN', J10, 'DIVISIONS')  →  returns division code for entity in col J",11240,"EEF6FF",False,"333333","Courier New",16)},
          ]}}),
          new TableRow({{ children:[
            {data_cell("F42/F43",800)},{data_cell("Both",1200)},
            {data_cell("Total failed",2200)},
            {data_cell("=SUM(F23:F40)  →  total count of failed validations for selected entity",11240,"FFFFFF",False,"333333","Courier New",16)},
          ]}}),
        ]
      }}),

      new Paragraph({{ spacing:{{before:100}}, children:[new TextRun({{text:"",size:4}})] }}),
      new Paragraph({{ children:[new TextRun({{text:"— End of Report 1: BPC EPM Validations Report —",size:20,color:"888888",font:"Arial",italics:true}})] }}),

    ]
  }}]
}});

Packer.toBuffer(doc)
  .then(buf => {{ fs.writeFileSync("{_j(out_path)}", buf); console.log("Created: {_j(out_path)}"); }})
  .catch(err => {{ console.error(err); process.exit(1); }});
"""
    return js


# ── main ───────────────────────────────────────────────────────────────────────

def main():
    excel   = sys.argv[1] if len(sys.argv)>1 else "/mnt/user-data/uploads/Copy_of_Sample_Report_BPC_EPM.xlsx"
    out_dir = sys.argv[2] if len(sys.argv)>2 else "/mnt/user-data/outputs"
    os.makedirs(out_dir, exist_ok=True)
    out_doc = os.path.join(out_dir, "Report1_Validations_Full.docx")

    print("Rendering screenshot …")
    ss = render_screenshot()
    print(f"  ✓ {ss}")

    print("Extracting Excel data …")
    dims, lm, olap, meas = extract_all(excel)
    print(f"  Dimensions: {len(dims)}  LocalMembers: {len(lm)}  OlapMembers: {sum(len(v) for v in olap.values())}  Measures: {len(meas)}")

    print("Building Word document …")
    js_code = build_docx(out_doc, ss, dims, lm, olap, meas)
    js_path = "/home/claude/gen_report1_full.js"
    with open(js_path,"w") as f:
        f.write(js_code)

    result = subprocess.run(["node", js_path], capture_output=True, text=True)
    if result.returncode != 0:
        print("Node.js error:")
        print(result.stderr[:800])
        sys.exit(1)
    print(f"  ✓ {result.stdout.strip()}")
    size = os.path.getsize(out_doc)//1024
    print(f"\n══ Done: {out_doc}  ({size} KB)")


if __name__ == "__main__":
    main()
