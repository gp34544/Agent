# SAP S/4HANA Group Reporting — Test Case Generator

An AI-powered UAT test case generator for **SAP S/4HANA Group Reporting (WP3)**.  
Upload test scenarios → get structured, executable test cases in the UAT 29-column template format, ready for Jira / Zephyr Scale import.

---

## Project Structure

```
Desktop/
├── Testing Agent/                  ← Reference files (this folder)
│   ├── UAT Test Scenarios_WP3_SAP Group Reporting.xlsx   ← Input: 80 test scenarios
│   ├── UAT Test Case Template.xlsx                        ← Output template (29 columns)
│   └── ashishFile_edit.xlsx                               ← SAP GR step-by-step playbook
│
└── claude_agent/                   ← The application (run this)
    ├── app.py                      ← Streamlit UI entry point
    ├── requirements.txt
    ├── .env.example                ← Copy to .env, add AWS credentials
    └── src/
        ├── agent.py                ← AWS Bedrock agent (Claude Sonnet 4.5)
        ├── knowledge_base.py       ← Loads & searches ashishFile step library
        ├── brd_index.py            ← FAISS semantic search over BRD documents
        ├── tools.py                ← Tool functions the agent calls
        ├── config.py               ← Settings, template columns, credential placeholders
        └── models.py               ← Data models
```

---

## How It Works — Simple English

You give the agent **up to three inputs**:

| Input | What it is | Required |
|---|---|---|
| Test Scenario file | Excel / CSV with rows like "Run Currency Translation for December 2025" | Yes |
| ashishFile | SAP GR step-by-step execution playbook | Recommended |
| BRD Document | Business requirements document with acceptance criteria | Optional |

The agent reads the scenarios, looks up the real SAP UI execution steps, retrieves relevant BRD rules, and writes complete test cases — the same way a knowledgeable human tester would, but automated.

### What Happens Step by Step

```
1.  Parse scenario file (Python)
        ↓
2.  Build BRD FAISS index if BRD uploaded (sentence-transformers + FAISS)
        ↓
3.  Agent starts (Claude Sonnet 4.5 on AWS Bedrock)
        ↓
4.  Agent calls get_sap_process_steps("Currency Translation", ...)
        → Python looks up ashishFile → returns 19 real SAP UI steps
        ↓
5.  Agent calls query_brd_knowledge_base("currency translation Dec 2025")
        → FAISS returns top-3 most relevant BRD paragraphs
        ↓
6.  Agent writes the test case combining:
        Layer 1 — Scenario data        (period, year, company code, version)
        Layer 2 — SAP steps from file  (exact Fiori UI click sequence)
        Layer 3 — BRD business rules   (acceptance criteria, compliance notes)
        Layer 4 — Model's SAP knowledge (terminology, validation logic)
        ↓
7.  Output: up to 5 test cases, all 29 columns filled
        ↓
8.  Download as Excel or CSV — ready for Jira / Zephyr bulk import
```

---

## The Three Reference Files

### 1. `UAT Test Scenarios_WP3_SAP Group Reporting.xlsx`
**The input.** 80 business-level test scenarios across:
- Management Consolidation (C100/C200/FC100 — Actuals & Budget/Forecast)
- Legal Consolidation groups
- Real Estate Consolidation (DFC Group, entities 2085/2037/2090)
- SEA Consolidation (entity 2250)

Each row contains: Sub Process, Division, Company Code, Period, Year, Scenario Description, Expected Outcome, Report name.

### 2. `UAT Test Case Template.xlsx`
**The output format.** 29-column template matching Jira / Zephyr Scale import schema:

| Key Columns | Purpose |
|---|---|
| Summary | Short test case title |
| Description | What the test verifies |
| Precondition | System state required before execution |
| Step Summary | Numbered SAP Fiori click-sequence steps |
| Test Data | Company Code, Year, Period, Version, Entity |
| Expected Result | Business outcome + report name for validation |
| Folder | Hierarchy path: WP3 / Process / Sub Process / Division |

### 3. `ashishFile_edit.xlsx`
**The step library.** Two-column format — 20 sections, 610 steps total:

```
Col A (section header)        Col B (step text)
─────────────────────────────────────────────────
Currency Translation    │  Set Global Parameter (Version, Period, CoA)
(empty)                 │  Open Data Monitor App
(empty)                 │  Select Entity / Group
(empty)                 │  Run Currency Translation Task
(empty)                 │  Validate Exchange Rates (Average, Closing, Historical)
(empty)                 │  Validate CTA postings
(empty)                 │  Error Handling: correct rate settings, re-run
```

**How it's used:** The agent calls `get_sap_process_steps("Currency Translation")` → Python parses this file → returns all 19 real steps → agent puts them in the test case `Step Summary` column.  
The file is parsed live at runtime — not hardcoded. Upload it in the sidebar to activate.

---

## Architecture

### One Agent, Three Tools

```
┌─────────────────────────────────────────────────────────┐
│           AGENT — Claude Sonnet 4.5 (Bedrock)           │
│                                                         │
│  Receives: scenario rows + instructions                  │
│  Calls tools, combines context, writes test cases        │
└────────────────────┬────────────────────────────────────┘
                     │ tool calls
         ┌───────────┼───────────────────┐
         ▼           ▼                   ▼
 get_sap_          query_brd_        parse_scenarios_
 process_steps     knowledge_base    file
         │           │                   │
 ashishFile      FAISS index         pandas Excel/CSV
 parsed live     (sentence-          parser
 at runtime      transformers)
```

| Tool | What it does | Technology |
|---|---|---|
| `get_sap_process_steps` | Looks up SAP Fiori execution steps for a process | Direct parse of ashishFile + fuzzy name matching |
| `query_brd_knowledge_base` | Retrieves relevant BRD paragraphs for a scenario | FAISS cosine-similarity search (`all-MiniLM-L6-v2`) |
| `parse_scenarios_file` | Parses uploaded Excel / CSV into structured rows | pandas / openpyxl |

### Why not FAISS for ashishFile?

ashishFile has **named sections** (process name → steps). That structure lets you look up the exact right section by name — no guessing needed. FAISS is best for unstructured prose (like a BRD) where you don't know which paragraph is relevant. Using the right tool for each data shape:

| File | Structure | Right retrieval |
|---|---|---|
| ashishFile | Named sections → step lists | Exact section-name matching |
| BRD | Free-form prose paragraphs | FAISS semantic similarity |

### Abbreviation Expansion

Common SAP abbreviations are expanded before lookup so the agent can say "ICMR" and get the right section:

| Abbreviation | Expands to |
|---|---|
| ICMR | Intercompany matching and reconciliation |
| COI | Consolidation of investments |
| SME | Stock Margin Elimination |
| BCF | Balance carry forward |
| FX | Currency Translation |

---

## Setup

### 1. Install dependencies
```bash
cd claude_agent
pip install -r requirements.txt
```

> **First run:** `sentence-transformers` downloads the `all-MiniLM-L6-v2` model (~80 MB) once and caches it locally.

### 2. Configure AWS credentials
```bash
cp .env.example .env
```
Edit `.env`:
```
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID_HERE
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY_HERE
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=us.anthropic.claude-sonnet-4-5-20251001:0
```

Required IAM permissions: `bedrock:InvokeModel`, `bedrock:Converse`

Alternatively, enter credentials directly in the app sidebar — they are session-only and never stored to disk.

### 3. Run
```bash
streamlit run app.py
```

---

## Using the App

### Tab: Generate

**Step 1 — Upload scenario file** (left panel)  
Upload `UAT Test Scenarios_WP3_SAP Group Reporting.xlsx` or any `.csv`.  
A preview of the rows appears immediately.

**Step 2 — Upload ashishFile** (sidebar → SAP Step Library)  
Upload `ashishFile_edit.xlsx`.  
The app parses it and confirms: *"Step library loaded — 20 sections, 610 steps"*.  
If skipped, the built-in fallback library is used (condensed version).

**Step 3 — Upload BRD** (right panel, optional)  
Upload your BRD as `.pdf`, `.docx`, or `.txt`.  
The app builds a FAISS index and confirms the chunk count.  
Use the **Test BRD retrieval** expander to verify relevant sections are found.

**Step 4 — Click Generate Test Cases**  
Watch the live tool-call log:
```
Tools called: get_sap_process_steps → query_brd_knowledge_base → get_sap_process_steps → ...
```

### Tab: Results

- View all generated test cases in a full-width table
- See agent tool call log and raw JSON response
- Download as **CSV** or **29-column XLSX** (Jira/Zephyr import ready)

---

## SAP GR Processes Covered

| Process | Steps in ashishFile |
|---|---|
| Balance carry forward | 14 |
| Data Collection | 16 |
| Data Validation Task | 22 |
| Currency Translation | 19 |
| Stock Margin Elimination | 31 |
| Intercompany matching and reconciliation | 38 |
| Intercompany eliminations | 41 |
| Consolidation of investments | 45 |
| Cash Flow calculations | 15 |
| Reclassification | 13 |
| Data Locking, Journal posting | 34 |
| SEA Consolidation - Actual | 19 |
| Real Estate Consolidation - Actual and Plan | 21 |
| Management Consolidation - Actual | 22 |
| Equity Elimination | 47 |
| Manual Posting of Consolidation Adjustments | 43 |
| Consolidation Process Scenarios (C10–L30) | 47 |
| Master Data Scenarios | 52 |
| Consolidation Group & Hierarchy | 57 |
| Business Process Flow and Tracking | 14 |

**Total: 20 sections, 610 steps**

---

## Configuration Reference

| Setting | Default | Where to set |
|---|---|---|
| `AWS_ACCESS_KEY_ID` | placeholder | `.env` or sidebar |
| `AWS_SECRET_ACCESS_KEY` | placeholder | `.env` or sidebar |
| `AWS_SESSION_TOKEN` | empty | `.env` or sidebar (temp creds only) |
| `AWS_REGION` | `us-east-1` | `.env` or sidebar |
| `BEDROCK_MODEL_ID` | `us.anthropic.claude-sonnet-4-5-20251001:0` | `.env` or sidebar |
| Max test cases | 5 (hard cap) | Sidebar slider |

---

## Key Design Decisions

**Max 5 test cases** — enforced twice: in the agent system prompt and in Python post-processing. Both must agree for a row to appear in the output.

**One agent, multiple tools** — Claude is the single agent. File parsing, step lookup, and BRD retrieval are Python functions (tools), not separate LLM agents. Cheaper, faster, and easier to debug.

**ashishFile parsed live** — the step library is read from the Excel file at runtime, not baked into code. Update the file → the agent uses updated steps automatically.

**BRD via FAISS** — large BRDs can't be injected wholesale into the prompt (truncation, noise). FAISS retrieves only the 3 most relevant paragraphs per scenario query, keeping context focused.

**29-column output** — matches `UAT Test Case Template.xlsx` column-for-column. The downloaded XLSX can be imported directly into Jira via Zephyr Scale bulk import.
