from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

import pandas as pd
from docx import Document
from PyPDF2 import PdfReader

from .models import REQUIRED_OUTPUT_COLUMNS


def read_scenarios(file_name: str, data: bytes) -> pd.DataFrame:
    ext = Path(file_name).suffix.lower()
    if ext == ".csv":
        df = pd.read_csv(io.BytesIO(data))
    elif ext in {".xlsx", ".xlsm", ".xls"}:
        df = pd.read_excel(io.BytesIO(data), sheet_name=0)
    else:
        raise ValueError("Scenario input must be .xlsx or .csv")

    df.columns = [str(c).strip() for c in df.columns]
    df = df.dropna(how="all")
    return df


def extract_brd_text(file_name: str, data: bytes) -> str:
    ext = Path(file_name).suffix.lower()
    if ext == ".txt":
        return data.decode("utf-8", errors="ignore")

    if ext == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        pages = [p.extract_text() or "" for p in reader.pages]
        return "\n".join(pages)

    if ext == ".docx":
        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)

    raise ValueError("BRD input must be .pdf, .txt, or .docx")


def scenario_rows_for_prompt(df: pd.DataFrame, limit: int = 20) -> list[dict[str, Any]]:
    rows = df.fillna("").to_dict(orient="records")
    return rows[:limit]


def normalize_and_validate(rows: list[dict[str, Any]], max_cases: int = 5) -> tuple[list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    trimmed = rows[:max_cases]
    if len(rows) > max_cases:
        warnings.append(f"Model returned {len(rows)} rows; truncated to {max_cases}.")

    normalized: list[dict[str, Any]] = []
    for i, row in enumerate(trimmed, start=1):
        out: dict[str, Any] = {}
        for col in REQUIRED_OUTPUT_COLUMNS:
            out[col] = str(row.get(col, "")).strip()
        missing = [c for c in REQUIRED_OUTPUT_COLUMNS if not out[c]]
        if missing:
            warnings.append(f"Row {i} missing columns: {', '.join(missing)}")
        normalized.append(out)

    return normalized, warnings


def parse_json_rows(response_text: str) -> list[dict[str, Any]]:
    text = response_text.strip()
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1 or end < start:
        raise ValueError("Model response did not contain a JSON array.")
    payload = text[start : end + 1]
    parsed = json.loads(payload)
    if not isinstance(parsed, list):
        raise ValueError("Model response JSON is not a list.")
    return parsed
