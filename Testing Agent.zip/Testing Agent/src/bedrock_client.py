from __future__ import annotations

import json

import boto3

from .config import settings


def _bedrock_runtime_client():
    kwargs = {
        "service_name": "bedrock-runtime",
        "region_name": settings.aws_region,
    }

    if settings.aws_access_key_id and settings.aws_secret_access_key:
        kwargs.update(
            {
                "aws_access_key_id": settings.aws_access_key_id,
                "aws_secret_access_key": settings.aws_secret_access_key,
            }
        )
        if settings.aws_session_token:
            kwargs["aws_session_token"] = settings.aws_session_token

    return boto3.client(**kwargs)


def invoke_sonnet(system_prompt: str, user_prompt: str, max_tokens: int = 2500) -> str:
    client = _bedrock_runtime_client()
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [
            {
                "role": "user",
                "content": [{"type": "text", "text": user_prompt}],
            }
        ],
        "temperature": 0.2,
    }

    response = client.invoke_model(
        modelId=settings.bedrock_model_id,
        contentType="application/json",
        accept="application/json",
        body=json.dumps(body),
    )

    payload = json.loads(response["body"].read())
    parts = payload.get("content", [])
    text_parts = [p.get("text", "") for p in parts if p.get("type") == "text"]
    return "\n".join(text_parts).strip()
