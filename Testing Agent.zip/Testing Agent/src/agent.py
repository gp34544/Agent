from __future__ import annotations

import json
from typing import Any

from .bedrock_client import invoke_sonnet
from .models import GenerationResult, REQUIRED_OUTPUT_COLUMNS
from .tools import normalize_and_validate, parse_json_rows


SYSTEM_PROMPT = """
You are SAP GR Testing Agent.
You generate UAT test cases for SAP S/4HANA Group Reporting.
You must return ONLY a JSON array (no markdown, no explanation).

Rules:
- Use scenario input and optional BRD context only.
- Do not invent business facts.
- Generate at most 5 test cases.
- Keep terminology aligned with SAP Group Reporting.
- Required output keys in each object:
  Workpackage, Process, Sub Process, Division, Summary, Description,
  Precondition, Step Summary, Test Data, Expected Result
- Every key must exist; use empty string only if truly unavailable.
""".strip()


def _build_user_prompt(
    scenario_rows: list[dict[str, Any]],
    brd_text: str | None,
    max_cases: int,
) -> str:
    brd_snippet = (brd_text or "").strip()
    if len(brd_snippet) > 8000:
        brd_snippet = brd_snippet[:8000] + "\n[TRUNCATED]"

    prompt = {
        "task": "Generate test case rows from scenario rows.",
        "max_cases": max_cases,
        "required_columns": REQUIRED_OUTPUT_COLUMNS,
        "scenario_rows": scenario_rows,
        "brd_context": brd_snippet,
        "notes": [
            "Prefer one row per executable test case step.",
            "If period/year has multiple values, split into clear executable cases.",
            "Expected Result should include outcome and report reference when present.",
        ],
    }
    return json.dumps(prompt, ensure_ascii=True)


def generate_test_cases(
    scenario_rows: list[dict[str, Any]],
    brd_text: str | None = None,
    max_cases: int = 5,
) -> GenerationResult:
    user_prompt = _build_user_prompt(
        scenario_rows=scenario_rows,
        brd_text=brd_text,
        max_cases=max_cases,
    )

    raw = invoke_sonnet(SYSTEM_PROMPT, user_prompt)
    parsed = parse_json_rows(raw)
    normalized, warnings = normalize_and_validate(parsed, max_cases=max_cases)

    return GenerationResult(rows=normalized, warnings=warnings, raw_response=raw)
