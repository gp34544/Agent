from __future__ import annotations

from dataclasses import dataclass
from typing import Any


REQUIRED_OUTPUT_COLUMNS = [
    "Workpackage",
    "Process",
    "Sub Process",
    "Division",
    "Summary",
    "Description",
    "Precondition",
    "Step Summary",
    "Test Data",
    "Expected Result",
]


@dataclass
class GenerationResult:
    rows: list[dict[str, Any]]
    warnings: list[str]
    raw_response: str
