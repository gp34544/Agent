from __future__ import annotations

import io

import pandas as pd
import streamlit as st

from src.agent import generate_test_cases
from src.config import settings
from src.tools import extract_brd_text, read_scenarios, scenario_rows_for_prompt


st.set_page_config(page_title="SAP GR Testing Agent", layout="wide")
st.title("SAP S/4HANA Group Reporting - Testing Agent")
st.caption("Single-agent generator with Bedrock Claude Sonnet and tool/function pipeline")

with st.expander("Runtime Configuration", expanded=False):
    st.write(
        {
            "AWS_REGION": settings.aws_region,
            "BEDROCK_MODEL_ID": settings.bedrock_model_id,
            "AWS_ACCESS_KEY_ID_set": bool(settings.aws_access_key_id),
            "AWS_SECRET_ACCESS_KEY_set": bool(settings.aws_secret_access_key),
        }
    )

scenario_file = st.file_uploader(
    "Upload Test Scenario File (.xlsx or .csv)",
    type=["xlsx", "csv"],
    accept_multiple_files=False,
)

brd_file = st.file_uploader(
    "Optional: Upload BRD File (.pdf, .txt, .docx)",
    type=["pdf", "txt", "docx"],
    accept_multiple_files=False,
)

max_cases = st.number_input(
    "Maximum test cases to generate",
    min_value=1,
    max_value=5,
    value=5,
    step=1,
    help="Hard-capped at 5 by design.",
)

if st.button("Generate Test Cases", type="primary"):
    if scenario_file is None:
        st.error("Please upload a scenario file.")
        st.stop()

    try:
        scenario_bytes = scenario_file.getvalue()
        df = read_scenarios(scenario_file.name, scenario_bytes)

        if df.empty:
            st.error("Scenario file has no usable rows.")
            st.stop()

        st.subheader("Scenario Preview")
        st.dataframe(df.head(20), use_container_width=True)

        brd_text = None
        if brd_file is not None:
            brd_text = extract_brd_text(brd_file.name, brd_file.getvalue())
            st.info(f"Loaded BRD context ({len(brd_text)} characters).")

        rows_for_agent = scenario_rows_for_prompt(df, limit=20)
        result = generate_test_cases(
            scenario_rows=rows_for_agent,
            brd_text=brd_text,
            max_cases=int(max_cases),
        )

        out_df = pd.DataFrame(result.rows)

        st.subheader("Generated Test Cases")
        st.dataframe(out_df, use_container_width=True)

        if result.warnings:
            st.warning("\n".join(result.warnings))

        csv_bytes = out_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download CSV",
            data=csv_bytes,
            file_name="generated_test_cases.csv",
            mime="text/csv",
        )

        xlsx_buffer = io.BytesIO()
        with pd.ExcelWriter(xlsx_buffer, engine="openpyxl") as writer:
            out_df.to_excel(writer, index=False, sheet_name="WP3_TestCases")
        st.download_button(
            "Download XLSX",
            data=xlsx_buffer.getvalue(),
            file_name="generated_test_cases.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    except Exception as exc:
        st.error(f"Generation failed: {exc}")
